# STATUS.md 归档（2026-11-25）

按 `AGENTS.md`「只保留最近 3 轮」移入的旧段：C9 题目集 P0、M6、0.99.0 发版、
FTC 补证（PR #107）的完整正文。原文逐字未动。

## 当前快照（2026-11-24 · C9 P0）
C9 题目集数据集 P0 落盘：`courses/exercise-dataset/` 从三门课程教材抽出 **2008 道代码练习**（296 单元、解答 2008/2008、4988 条 `soko:hint`，JSON 4.61 MB，生成物进 git 但由 `build.py` 唯一生成）；大计划 issue **#96**。判据：`build.py --check` 判源文件漂移，`check.py` 判结构/来源映射/解答，`check.py --selftest` 对 6 类坏数据必须判红；抽样 `compose.py` → 真内核判卷（模板有 `exercise.open`、解答 0 open、0 diagnostic）。

## C9 题目集数据集 P0（2026-11-24 · issue #96）
- 结构：`model.py` 唯一解析器（课程清单 v1/v2、画布、解答）；`build.py` / `check.py` / `compose.py` 共用。记录带稳定 ID `<course>/[<chapter>/]<unit-stem>/<name>`、`prompt`/`hints`/`template`/`solution`/`source` 映射；匿名 `example` 用 `example-N`。
- 读数：quick-start 66 / 11 单元；set-theory 910 / 112；analysis 1032 / 173；190 道旧练习无 hint 照实记录；`build.py --json` 给出每门课计数与字节数。
- 边界：不改课程源与 kernel/front 判定；选择题层（P2）与插件接线（P3）未做，见 #96 阶段表。

## M6：QA / 文档 / 站点 / 发布（2026-11-21 · issue #22）
M1–M5 完成、分析课 171/171 单元；全量课程门禁 457 目标 / 4512 checked / 0 rejected；站点 `check-site.py` 10/10（`--browser` 12/12）；Arena 门禁经 PR #92 修复后在 `8d4167f5` PASS。书页 v3 与双语范围待用户拍板。

## 发版 0.99.0（2026-11-23 · M6 收口）
`scripts/bump.py 0.99.0` 写四处版本 + 3 个课程清单 + 站点数据；发布内容 = M1–M6 加 LKA 门禁修复；书页 v3/双语仍留 #22 后续。

## FTC 补证（2026-11-24 · issue #21 后续）
通用原函数版在 `ratRep` 层不成立（√2 两侧 0/1 反例：F′=0 但 F(b)−F(a)=1≠∫f=0）。用户拍板 B：加 `Exists.choose` 与倒数/商库，做面积函数这一半。已证 `lib/IntegralFTC.integral_hasDerivAt`（52 条 checked，含无除法差界与斜率极限）；单元172（9/9）与单元173（4/4）进课程。边界：通用原函数版仍不成立；见 PR #107。

## 追加：C9.5 调度、复盘与学习地图（2026-11-27，移出 STATUS 保持最近 3 轮）

## 当前快照（2026-11-27 · C9.5 调度、复盘与学习地图）
C9.5（#103）：`engine.py` 校准阶梯改由题库推导（不再硬编码 I.1–I.3），`next` 加
`--chapter/--level/--kp` 钻取；`map` 增加 KP **已解/待做/薄弱**（结构计数，阈值进
`params.map`）、按章汇总与 **C9.4 代码题进度**，聊天与插件 progress 卡读同一份快照；
每题耗时进 history（`--elapsed-ms` 优先，否则发出→作答间隔；只汇总、不作判据）；
`state` 加 `metrics`（正确率/byLevel/耗时/KP 覆盖/代码），知识卡阈值改读
`params.wrong_card_threshold`。`review.py` 读同一份状态出薄弱 tag/KP、错题、代码进度、
内容缺口与下一批建议，报告落 gitignore 的 `reports/`。
判据：engine selftest 47、simulate 50、review selftest、validate、插件 host 24 /
client 22 全绿；coverage 99 红是 C9.2 预期欠账。

## 当前快照（2026-11-27 · C9.6 发布与文档包）
C9.6：把 C9 产物做成可安装、可发现的发布。插件 README 补干净安装、
题库/代码题入口与基数、代码题提交、排障表与隐私边界；`dsh/README`、根 README、
`site/llms.txt` 加入口；技能同步题库/代码题。bump 到 0.100.0，CHANGELOG 列 C9 范围
与已知限制。判据：docs-lint / status-lint / check-site / skill+dsh / 插件测试 /
preflight --fast

## 当前快照（2026-11-27 · DSH 源码预览光标 + goal 面板）

#115：`.sokonanoda` 右侧预览加只读光标：`↑/↓`/点击移动活动行并高亮；下方面板显示声明名、
status、`step/total`、假设、`⊢ goal`（`goal_runs`/`ty_runs` 上色，不重新分词），区分
「不在声明内 / 源码错误 / 超时 / 后端不可用 / 已无目标」。Host 新增 owner-only
`GET /sokonanoda-state`：只读、路径限工作区/仓库（拒 `..`、绝对路径、符号链接逃逸）、
参数数组调 `scripts/soko query state`、3 s 超时杀进程组；client 120 ms 去抖 + 单飞 + seq。
判据：插件 host 29 / client 28；真 DSH Web + 真内核 e2e；docs/status lint。
