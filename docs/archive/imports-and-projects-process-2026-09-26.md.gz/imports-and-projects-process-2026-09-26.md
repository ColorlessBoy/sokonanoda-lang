## 1. 触发与目标

### 1.1 用户要什么

| 用户的问题 | 本文的回答 |
|---|---|
| 其他语言怎么**分别**处理单文件与项目？ | §2.1–§2.4：10 个系统的横向调研（Lean/Lake、Coq、Agda、Isabelle、Idris、Rust、Go、Python、JS/TS、Haskell/OCaml）+ 语言服务器与缓存的做法 |
| 项目如何维护？ | §2.5 模式总结 + §4.4/§4.8/§4.9：清单文件、根发现、模块图、缓存的键与失效、`build`/`query`/LSP/`watch` 各自怎么接 |
| sokonanoda 如何实现？ | §3 现状审计（含实测与代码接缝）+ §4 设计（D1–D10，每条带取舍与被否方案） |
| 具体执行方案？ | §5 分阶段计划（P0–P6，每阶段独立可验收）+ §6 验收 A1–A8 |

### 1.2 为什么值得做（本项目特有的三条理由）

不是"别的语言都有所以要有"。用本仓库语料**量出来**的理由（数字与命令见本轮调研
底稿，`docs/STATUS-ARCHIVE.md` 之外的原始测量由 `course/`+`crates/cli/tests/` 复算）：

1. **正确性：同名不同义今天无法表达，只能靠"每个文件各自闭合"回避。**
   45 个语料文件里 **71 个名字有 ≥2 种定义**，其中 **20 个变体从未在同一单元共现**
   ——它们是真正的跨文件歧义，不是练习 vs 答案：
   - `Or`：单元①/④ 与 `examples/` 是 `axiom Or : Prop -> Prop -> Prop`，
     单元⑨/⑩ 是 `inductive Or (A B : Prop)`（真归纳 + `Or.rec`）；
   - `Iff`：单元⑨/⑩ 是 `def Iff (A B : Prop) := And (A -> B) (B -> A)`，
     `examples/` 是 `axiom Iff`；
   - `And.intro/.left/.right`：15 处 `(a : Prop) -> ...`，`fol-basics` 用
     `forall (a : Prop), ...`，`py-fol-core` 用 `{a : Prop} -> ...`——**内核里是不同的类型**。
   > **模块边界是唯一能让"哪个 `Or`？"可回答的机制。** 没有 import，agent 与用户
   > 只能靠文件路径这个隐式约定来区分，而任何一次"把两个例子拼起来看"都会踩雷。
2. **复用：`solutions/` 与 `examples/` 的整段重抄。** 单元1/6/9 的解答文件与画布
   声明骨架**逐一对应**（19/19、19/19、27/27），只有证明体不同；`examples/py-fol-core`
   的 26 个声明里有 18 个是把 `examples/fol-basics` 重写一遍（还换了 binder 风格）。
   最直白的一处：`course/unit6:21-36` 与 `course/unit7:16-31` 是**逐字节相同的 16 行
   `inductive Nat` 块**（diff IDENTICAL），英文镜像再复制两份 = **同一段代码 4 份拷贝**，
   而 unit7 的注释自己写着"same as the previous unit"。
   全语料 **1217/3851 行（31.6%）** 落在"名字在 ≥2 个文件里出现过"的声明块内——
   注意：**这一条只是收益，不是理由**（最大 5 组重复一共只省 122 行，纯为省行数
   不值得动缓存与 LSP），真正值钱的是第 1 条与第 3 条。
3. **教学闭环：老师 agent 的"教材库"可以被 45 个画布复用。**
   教学主循环是"agent 把逻辑连接词从零讲一遍 → 出题 → 用户作答"。今天每开一个新
   画布，agent 都要**重新口述/重写** `And`/`Or`/`Iff` 的骨架（22 个文件里都有
   `And` 家族）——这既是 token 成本，也是"同一概念在不同画布里定义不一致"的根源。
   有了 import，agent 可以维护 `Lesson/Logic.sokonanoda`，每个学生的画布只写
   `import Lesson.Logic` + 本轮练习；而**判卷路径不变**（仍是
   `scripts/soko grade playground.sokonanoda`）。

### 1.3 非目标（v1 明确不做）

- **不做包管理**：没有 registry、没有 `require`/git 依赖、没有版本求解。项目内
  只有"本仓库的模块"；跨项目依赖留 `[deps]` 扩展点（§4.11）。
- **不做 `namespace`/`open`/`section`/`private`/`import all`**：它们是真实 Lean 语法，
  但要各自走"课程 + 测试 + 白名单"三件套；v1 只做 `import Foo.Bar` 一条，
  扁平全局名字 + 冲突教学错误（§4.7 说明为什么这仍然够用）。
- **不重构课程语料**：45 个文件的 golden 计数是硬门禁（`crates/cli/tests/course.rs`），
  v1 只保证"不改它们也能用 import"，语料重构单独一轮（§4.10 / Q5）。
- **不做 decl 级编译产物（`.olean` 等价物）**：v1 用"闭包哈希 + 报告缓存"拿到
  "没变就不重编"；跨进程复用**已检查声明**留 P4（可选"信任台账"，且启用前必须换强哈希）
  与 P7（真正的 decl 级产物，需先推翻内核冻结边界）。
- **不改内核**：任何需要动 `crates/kernel` 的方案直接否掉（§9）。

---

## 2. 调研：其他语言/证明助手怎么分「单文件」与「项目」

> 调研由 3 个并行 subagent 完成（Lean 4/Lake；其他语言与证明助手；语言服务器与缓存），
> 每条结论带官方文档/源码出处（§10）。本节只保留**对设计有约束力**的部分，
> 结论列在 §2.5（采纳 / 不采纳）。

### 2.1 Lean 4 + Lake（教学语法的母体，规则必须对齐）

**单文件模式**（`lean foo.lean`）
- 只做：解析 header → 加载 import 的 `.olean` → elaborate 命令 → 产出环境则 exit 0；
  **默认不写任何产物**（`oleanFileName? := none`，要 `-o Foo.olean` 才写）。`main` 不运行
  （那是 `--run`）。⇒ **"单文件 = 零配置、零产物"是 Lean 的原生行为**，我们的单文件
  路径与它同形（写出 `.sokonanoda` 报告缓存属于我们的扩展，不进用户目录树）。
- **隐式 prelude**：没有 `prelude` token 时自动 `import Init`（外加 meta 版 Init）。
  `prelude` 关键字是 Lean 自己源码用的，官方明确"不供用户使用" ⇒ **我们不做
  `prelude` 关键字**（与现有 `-- sokonanoda:prelude none` 指令不冲突：那是我们的
  注释指令，不是 Lean 语法）。
- **模块名来自路径**：`moduleNameOfFileName fileName opts.rootDir?`；`-R/--root=dir` 的
  官方说明是"set package root directory from which the module name of the input file is
  calculated (**default: current working directory**)"；文件不在 root 下直接报
  `input file '<f>' must be contained in root directory (<root>)`。
  ⇒ 我们的"**无 manifest 时模块根 = 入口文件目录**"（§4.4）与 Lean 的默认
  （cwd）**同构但不完全相同**：我们的更局部、更可预测（编辑器里打开深目录文件
  不会因为 cwd 不同而改变语义）。**这是刻意 divergence，写进 Q2。**
- **缺模块的报错**（可照抄的体验）：`unknown module prefix 'Foo'` +
  `No directory 'Foo' or file 'Foo.olean' in the search path entries: …`（root 分量
  缺失），以及 root 存在但产物不在时的 `object file '<path>' of module Foo.Bar does not exist`。
  ⇒ 我们的 `import-not-found` 也要**列出搜过的根**（§4.2）。
- 搜索路径 = 调用方 roots ++ `LEAN_PATH` ++ 内置 `<sysroot>/lib/lean`。

**模块名 ↔ 路径**
- `import A.B.C` ↔ 某个 root 下的 `A/B/C.lean`（去掉扩展名、`.` 变目录）；**第一个命中的
  root 胜出**，后面的 root 不再看，也**没有**重复模块诊断。
- 分量合法性 = **层级标识符**规则（`import Foo-Bar` 是语法错误）；`«Foo-Bar»` 虽可解析
  但会触发可移植性检查：保留文件名（`CON/PRN/AUX/NUL/COM1-9/LPT1-9`）与
  某些 OS 禁用字符（`< > " | ? * !`）。⇒ 我们的 D2 采纳同一套：**`-` 直接拒绝**
  （教学 hint 指路），`! ?` 等给出可移植性提示（注意：本仓库 lexer **允许** `! ?`
  出现在标识符里，所以这条要在模块名层单独判）。
- **`import` 置顶**是硬规则，官方报错逐字：
  `invalid 'import' command, it must be used in the beginning of the file`。
  ⇒ 我们的 `import-must-precede-declarations` 语义与它一致（文案中文，语义同款）。
- **环**：Lean 核心假定 import 是 DAG（注释 "As imports are a DAG…"），但**专门的自导入
  诊断在 Lake 里**：`module imports itself` 与 `bad import '<M>'`
  （`src/lake/Lake/Build/Module.lean:413/:88`）；裸 `lean foo.lean` 下自 import 只能退化成
  `unknown module prefix`（还没有 olean）或陈旧的
  `import <M> failed, environment already contains '<c>' from <N>`。
  ⇒ 我们做**显式 `import-cycle` + 环路径**（纯前端可判、教学价值高），语义上与
  Lake 的诊断同向、比裸 `lean` 友好。
- **⚠️ 文件自己的目录不在 Lean 的搜索路径里（本设计最重要的一条外部事实）**：
  `initSearchPath` 在 C++ driver 里、**命令行解析之前**只跑一次
  （`src/Lean/Util/Path.lean:113-114`、`src/util/shell.cpp:224-227`），此后只有 LSP
  服务端会再动它；**cwd 只影响"模块名怎么算"，不参与 import 解析**。后果：
  `lean foo.lean` 旁边放着 `Bar.lean`、文件里写 `import Bar`，**会失败**，除非
  `LEAN_PATH` 覆盖该目录。⇒ 我们"无清单时模块根 = 入口文件目录"（§4.4）**是对真实
  Lean 的刻意 divergence**，换来的正是"两文件 demo 零配置"与"编辑器/agent 不依赖
  服务端 cwd"；它是硬规则 3（教学**语法**是 Lean 子集）之外的**语义偏离**，
  必须写进文档、并由 **Q2** 明确拍板。
- `import` vs `import all`：**没有 `module` 头的文件里，普通 import 就是传递可见**
  （`isExported := publicTk.isSome || moduleTk.isNone`）——教学文件正是这种情形。
  ⇒ 我们只做普通 import 的传递可见（§4.7），`public`/`meta`/`import all` 都不做。

**Lake 项目形态**（我们要"小一号"地抄）
- 官方工作区布局：`lean-toolchain`（工具链钉版本，elan 按需装）+ `lakefile.toml` 或
  `lakefile.lean` + `lake-manifest.json`（依赖的精确 revision，"应视为代码的一部分
  并入库"）+ `.lake/`（`lakefile.olean` 缓存、`packages/` 依赖副本、
  `build/{bin,lib,ir}`）。
- `lake new foo` 生成：`lakefile.toml`（TOML 是默认配置语言）+ `Foo.lean` +
  `Foo/Basic.lean` + `Main.lean` + `lean-toolchain` + `.gitignore` + `.lake/`。
- **源码默认就在包根**：`srcDir : FilePath := "."`，官方注释说明它会作为 `lean` 的
  `-R` 参数传下去；`src/` 不是必须的。⇒ 我们默认模块根 = manifest 所在目录，
  `src = "src"` 只是可选（§4.4 一致）。
- `lean_lib` 的 `roots`/`globs` 决定"库名 = 模块前缀、glob 圈定子模块"；`lake build`
  的产物落在 `.lake/build/lib/lean/Foo/Basic.olean`（+`.ilean`/`.trace`），
  C 在 `.lake/build/ir/`，可执行在 `.lake/build/bin/`。
- **Lake 不向上找包（已定论）**：`rootDir : FilePath := "."`（`CLI/Main.lean:48`），
  只由 `-d/--dir` 改（`:234,:362`），`mkLoadConfig` 只做 `resolvePath? opts.rootDir`（`:135`），
  整条 `loadWorkspace → loadWorkspaceRoot → resolveConfigFile` **从不碰父目录**
  ⇒ `lake build` 在包的子目录里**会失败**（除非 `--dir`）；官方文档同口径
  （`--dir=DIR` "Use the provided directory as location of the package instead of the
  current working directory"）。包身份**只看文件名**：优先 `lakefile.lean`，
  两个都在就打日志说用哪个，都没有就报
  `[name]: no configuration file with a supported extension:`（源码逐字，`Load/Package.lean:93-119`）。
- **同一个生态里两条不同的"向上"规则（很有启发）**：**Lake 不向上找包，但 elan 向上找
  `lean-toolchain`**（"walking up through parent directories until a toolchain version is
  found"）——**工具链是继承的，包根不是**。⇒ 我们把这两件事分开（WO-001 定稿）：
  **根** = 最近祖先的 `sokonanoda.toml`（§4.4，会向上找）；**版本钉** = 仓根的
  `sokonanoda-version.txt`（`SOKONANODA_VERSION` → `sokonanoda-version.txt` →
  `requires`（完整 `x.y.z`）→ `Cargo.toml`），**只在启动器自己所在的仓库根，不沿
  父目录找**——是"同目录的自述文件"，不是 elan 式继承。`sokonanoda.toml` 的
  `requires` 仍是**项目清单契约**（front 侧对二进制版本 warn-only、v1 不改语义），
  启动器只是在没有更硬的钉时把完整 `x.y.z` 当下载锚点用。
  manifest 版本错误也可以照抄它的语气（`invalid version '{ver}'; you may need to update
  your 'lean-toolchain'`）——**"告诉用户改哪个文件"** 是这些文案的共同点。

**编辑器（vscode-lean4）的项目根发现——我们 LSP 的直接参照**
- `findLeanProjectRootInfo`：先从 `.lake/packages` 里"退出来"（依赖自己的 toolchain
  不算项目根），然后**向上走**：见 `lean-toolchain` ⇒ 项目根（带工具链）；见
  `lakefile.lean|toml` ⇒ "有 lakefile 但没 toolchain"的独立状态；一路上到文件系统根，
  再退回 VS Code workspace folder，最后退回**文件自己的目录**。
- ⇒ **"孤立文件也有根、以单文件模式服务"** 是 Lean 编辑器的既有行为，
  我们的三层发现（manifest → workspace → 文件目录）与它同形（§4.9）。
  差异：我们**不引入** `lean-toolchain`-式"根但无工具链"的中间状态，
  而是把版本钉在仓根的 `sokonanoda-version.txt`（启动器读它，见上；`requires` 保留
  为清单契约，Q6，v1 只警告）。
- **服务端怎么起（对 DSH/VSCode 接线有参考价值）**：有 lakefile 时
  `lake serve --`，否则 `lean --server`（`leanclient.ts:834-840`）；**cwd = 项目根**；
  扩展**不设** `LEAN_PATH`、**不传** `--root`，只把 `~/.elan/bin` 前置进 PATH
  （设置项是 `lean4.envPathExtensions`/`lean4.serverArgs`，**没有** `lean4.serverEnv`）。
- **"没有项目"的官方 UX 文案（可直接照抄语气）**：`Lean 4 server is operating in
  restricted single file mode.`、`Opened folder does not contain a valid Lean 4 project.`、
  以及"父目录里有合法项目，要不要打开它？"的提示；`有 lakefile 但没有 lean-toolchain`
  是**硬错**。**负向事实**（别张冠李戴）：`No Lean project found` 与 `missing manifest`
  这两个字符串**在 vscode-lean4 里不存在**。
- **设计结论（两个工具链对"我的项目是什么"看法不一致）**：Lake 认为根 = cwd（或 `--dir`），
  elan 与编辑器认为根 = **最近祖先**。我们的选择与**编辑器/elan 同侧**
  （§4.4 的最近祖先 + 硬边界）：只有这条规则能让"在子目录里打开任意文件"工作，
  而判卷/agent 场景的 cwd 恰恰不可控。



### 2.2 其他证明助手（同一问题的不同答案）

| 系统 | 单文件 | 项目标记 / 发现 | 模块身份 | 产物 |
|---|---|---|---|---|
| **Coq/Rocq** | `rocq c foo.v` 可以 | `_RocqProject`（**IDE 向上找最近祖先**），扩展名故意为空；`-Q dir dirpath` 把逻辑路径映射到物理目录，用 `-Q` 时必须 `From X Require Import Y` | 路径 + `-Q`/`-R` 映射推出（**文件名必须是合法标识符**：`to-to.v` 非法） | `.vo` 在源旁边；`rocqchk` 可对产物独立复检 |
| **Agda** | `agda Foo.agda` 可以 | `.agda-lib`（`name/depend/include/flags` **全可选**）；**从模块名推出 root 再向上找**，同一层多于一个库 = 错误，且 root 之下不许再有库文件 | 严格路径推导：`A.B.C` 必须住在 `root/A/B` | 有库时 `_build/VERSION/`，否则 `.agdai` 在源旁边（改名留孤儿） |
| **Isabelle** | **没有单文件模式** | `ROOT` 会话 + `ROOTS` 目录清单 + `-d DIR`；没有"向上找" | 声明式理论名（文件名只是惯例） | heap 镜像/日志在 `ISABELLE_HEAPS`；`imports` 必须无环 |
| **Idris 2** | `idris2 f.idr` 可以（`--check` 也能只做检查） | `.ipkg`（`modules` **必须逐一列出**、`depends`、`sourcedir`）；不向上找 | **声明** `module Foo.Bar` **且**必须与 `sourcedir` 下路径一致 | `build/exec`、`build/ttc/*.ttc`（源变即重生成）；切模式要手删 `build` |

**要点**：证明助手普遍把"逻辑名 ↔ 物理路径"当成**一等公民**（Coq 的映射、Agda 的严格一致、
Lean 的路径推导），而"强制清单"（Isabelle/Dune）会让**第一次运行**变重；Idris 的
"声明 + 校验"是最贵的身份模型（两处要同步）。

### 2.3 通用语言（零配置是默认，清单只为主语料服务）

| 系统 | 裸文件 | 清单 | 模块身份 | 产物位置 / 失效 |
|---|---|---|---|---|
| **Rust** | `rustc single.rs` → `./single` | `Cargo.toml`（`cargo new` 只给 `src/main.rs` + `.gitignore`）；workspace 共享 `target/`+`Cargo.lock` | 声明 `mod` + 固定文件规则（`foo.rs` 或 `foo/mod.rs`，**两者都在 = 错误**） | `target/{debug,release}`；重编**主要看 mtime**（内容哈希 freshness 仅 nightly） |
| **Go** | `go run single.go`（无 `go.mod`） | `go.mod`（`module` 路径即包路径前缀）+ `go.sum` | 目录即包：包路径 = module 路径 + 子目录 | `GOCACHE`；自导入非法、两模块提供一个包 = 错误 |
| **Python** | `python script.py` | **没有清单**；`pyproject.toml` 只在构建/安装时读（恰三个表） | 文件名推导，**从不声明**；`__init__.py` 区分包 | `__pycache__` 在源旁边，按 mtime；循环导入被容忍、**首个命中静默胜出** |
| **Node/TS** | `node script.js` | `package.json`（**最近的祖先**决定 CJS/ESM）；`tsconfig.json` 是 TS 的项目清单（`include/exclude/rootDir/paths/references`） | CJS 无模块身份；ESM 说明符就是路径 | 向上走 `node_modules`；`.tsbuildinfo` 用**内容哈希 + mtime** |
| **Haskell / OCaml** | `ghc hello.hs` / `ocaml foo.ml` | `.cabal`（**必须逐一列出模块**，否则"陈旧的成功"）/ `dune-project`（没有就不干活） | GHC：声明且必须 `A/B/C.hs`；OCaml：**从不声明**，取文件名首字母大写 | `.o/.hi` 在源旁边（GHC）/ `_build/default`（dune）；GHC 用**接口指纹**、OCaml 用 **`.cmi` 摘要** |
| **JVM** | `java Hello.java` 可以 | Maven `pom.xml`（GAV 三元组） | 声明 `package` + 类型名，目录规则**由宿主决定是否强制** | `.class` 在源旁边或 `target/`；Maven 约定 `src/main/java` |

**要点**：**初学者最先遇到的语言，都是"裸文件先跑起来"的语言**（Python/Node/`rustc f.rs`/
`go run f.go`/`java Hello.java`/`ghc hello.hs`/`ocaml foo.ml`）；而文档里抱怨最多的
摩擦点恰好是"必须先有清单/映射"（Dune 没有 `dune-project` 就不干活、Cabal 必须列全模块、
Coq 的 `-Q`+`From`、TS 的配置矩阵）。这直接支持 **Q2 的建议（无清单也允许 import）**。

### 2.4 语言服务器与增量缓存（工程线；决定 §4.4/§4.8/§4.9 的形状）

**LSP 契约（我们必须遵守的部分）**
- `InitializeParams.rootUri` **可以是 null**（"Is null if no folder is open"），
  `workspace/workspaceFolders` 在"只开一个文件"时返回 `null`——**单文件是常态不是错误**，
  协议里**没有** single-file-mode 开关：服务器自己降级。⇒ 我们三层根发现合法且有先例。
- `workspace/didChangeWatchedFiles` + `FileSystemWatcher{globPattern, kind}` 是标准通道；
  编辑器侧已经在 watch `**/*.sokonanoda`，**是我们服务端没接**（§4.9）。
- 诊断由服务器"拥有"、必须自己清理；**"新推送的诊断总是替换旧的，客户端不做合并"**；
  官方明说打开项目时可以"recomputed (**or read from a cache**)"——**LSP 明文允许缓存读诊断**，
  我们 §4.8 的做法有协议背书。

**根发现的各家做法与共同坑**
- rust-analyzer：`rust-project.json` → `.rust-project.json` → `Cargo.toml`，逐级向上；
  都不在则向下看一层；不在任何项目的文件是 **detached file**（只能用 sysroot）；`linkedProjects` 覆盖。
- clangd：`compile_commands.json` 在**源文件的每个祖先目录里找，并且每层还看 `build/` 子目录**；
  找不到就退化成 `clang $FILENAME`——于是出现"一堆假的 `#include` 找不到"；
  覆盖手段 `--compile-commands-dir` / `CompilationDatabase: Ancestors|None|<path>`。
- TypeScript：`configured > external > inferred`；孤立文件拿到 InferredProject；
  在 `node_modules` 里**不向外找**（怕把整个世界拉进来）。
- pyright：**服务端不向上找**（CLI 找），而"流浪的 pyrightconfig/pyproject 会静默胜出"。
- gopls：`go.work` → `go.mod` 向上；都没有则 `AdHocView`（官方原话"no better choice"）。
- ocaml-lsp：`dune-project`/`dune-workspace` 向上；Lean 4 的 VS Code 扩展见 §2.1。
- **共同的坑（我们就按这些设计）**：① 它们**都一路走到文件系统根** ⇒ `$HOME` 里的
  流浪 marker 会捕获无关文件——所以我们的向上搜索必须有**硬边界**（最近 `.git` 或
  workspace 根，§4.4）；② 两个根发布同一个 URI **没有去重**（后发布者胜）⇒
  我们只允许**一个模块根**；③ 错根的典型症状是"假错误 + 什么都不工作"，
  缓解手段是**显式 pin 根**（我们的 `--root` + 编辑器设置镜像）与"报告用了哪个 manifest"。

**失效与产物（我们要抄的部分）**
- Lean/Lake：每个产物旁边一份 `BuildTrace{caption, inputs, hash, mtime}`，`Hash` 是
  **内容哈希**、`mixHash` 链式混入**每个 import 的产物 trace**、`-D` 选项、模块名、包 id；
  trace 不存在时才退回 mtime。**而 `.olean` 自身的版本检查默认关闭**
  （`LEAN_CHECK_OLEAN_VERSION` 默认 OFF）——**正确性其实由 Lake 的 trace 承担**，
  这是"产物头不可信、要另做键"的绝佳反例。
- GHC：接口文件里存**每个声明的 MD5 指纹**，并且记录"编译它时用到的所有指纹"；
  复用条件是源 MD5 未变 + `.o` 比 `.hi` 新，否则**逐指纹比较**（mtime 只是三项条件之一）。
- OCaml：`.cmi` 存**接口摘要**（BLAKE128），一致性按摘要而不是 mtime；
  缺接口报 `Cannot find file mod.cmi`。Coq：`.vo` 里**两个 digest**（前一个覆盖半份文件、
  后一个覆盖全部），import 时 `digest_match` 失败就拒绝加载并报
  "makes inconsistent assumptions over library Y"。
- **64 位哈希被上游自己标为不够**：Lake 的 `Hash = UInt64` 带 TODO
  "Use a secure hash rather than the builtin Lean hash function"——**我们今天的缓存也是
  FNV-1a 64**。⇒ 设计规则：报告缓存沿用 64 位（与现状同一条信任线），
  但**任何"跳过内核重查"的信任台账必须先换强哈希**（§4.8）。
- 原子写：Lean 写 `<name>.tmp.<pid>` 再 `rename`（理由逐字是"neither expose
  partially-written files nor modify possibly memory-mapped files"）——与本仓库现有缓存
  同款；并发方面 **Lake 没有锁文件**（lean4#2445 删掉了），两个 `lake build` 可以竞争，
  这是要避开的（我们：缓存写 best-effort + 原子 rename，不加锁）。

### 2.5 结论：我们采纳什么、明确不采纳什么

| 维度 | 其他系统的做法 | 我们的决定 | 理由 |
|---|---|---|---|
| 单文件默认 | 除 Isabelle 外都能裸文件跑 | **采纳**（不变式 1：无 `import` 逐字节不变） | 初学者路径最短；我们已经是这样 |
| 项目标记与发现 | Agda/Rocq-IDE/Cargo 向上找；Dune/Isabelle 强制清单；**Lean 的搜索路径里没有文件自己的目录**（§2.1） | **采纳"向上找 + 硬边界"**（§4.4）：最近 `sokonanoda.toml`，止于 `.git`/workspace 根，`--root` 覆盖，无清单退化到入口文件目录（**对 Lean 的刻意 divergence，Q2 拍板**） | 编辑器里"打开任意文件就能用"；硬边界避免 `$HOME` 流浪 marker（§2.4 的共同坑）；不用 cwd 做语义 → 判卷/agent 的 cwd 不可控 |
| 模块身份 | 路径推导（OCaml/Python/Coq+映射）vs 声明+校验（Haskell/Idris/Isabelle） | **采纳路径推导**（= Lean 同款） | 一个文件一个规范名，零漂移；声明式要两处同步（Idris 的代价） |
| 清单形态 | Lake 三件套（`lakefile` + `lean-toolchain` + `lake-manifest.json`） | **一个文件 + 可选元数据**（`sokonanoda.toml`；`requires` 对应 `lean-toolchain` 的**意图**，v1 只警告），工具链**钉**另放仓根 `sokonanoda-version.txt`（启动器读；WO-001） | 无外部依赖 ⇒ 不需要 manifest/lock 那套；教学只要"标记 + 少量元数据" |
| 产物位置 | 源旁边（Coq/OCaml/GHC）／中央构建目录（Lake/Cargo/dune）／用户缓存（clangd/本仓库） | **保持用户缓存目录**，不引入 `.soko/build/` | 零仓库污染、只读源码树可用、`git status` 干净；代价是不跨机器共享（我们不需要） |
| 缓存键 | GHC/Coq/Lake 都是"内容 + **每个依赖的接口哈希** + 选项/版本" | **采纳**（§4.8 的 iface 链） | 这是"缓存判定结果"安全的三条件之一（§2.4），也是唯一能防"改了依赖却命中"的形状 |
| 哈希强度 | Lake 的 UInt64 被官方标 TODO；Coq/GHC/OCaml 用强摘要 | 报告缓存沿用 FNV-1a 64；**信任台账必须先换强哈希** | 与现状同一信任线；碰撞在"跳过内核重查"下等于判定漏洞 |
| mtime | 几乎所有人都有 mtime 快路径 | **不引入**（键就是内容） | 已有 tmp+rename 原子写与内容键；少一条"时钟/checkout 还原时间"的坑 |
| 环 / 重名 | Go/Rust/Isabelle 硬错；Python 容忍；Node/Python 首命中静默 | **都硬错**，且给环路径 / 两个来源 | 教学价值最高；静默首命中是最坏失败（§2.3 反模式） |
| 包管理 | Rocq `-Q` 双名、Go module path、Cabal 必须列全、`NODE_PATH`/`GHC_PACKAGE_PATH` 式环境根 | **都不做** | v1 没有 registry 需求；环境变量式根是"隐形全局状态"反模式 |
| LSP 侧 | 三层根发现（lean4/gopls/pyright…）；一个文件一个诊断发布者 | **采纳**（§4.9），并接上 `didChangeWatchedFiles` | 与 lean4 扩展同形；避免"两个根抢同一个 URI" |

## 3. 现状审计（今天到底是怎么运作的）

### 3.1 单文件自足：不是口号，是四处代码级假设

| 位置 | 事实（实测/path:line） |
|---|---|
| 语法 | `import Foo.Bar` **今天是语法错误**：`error[parse]: expected a .sokonanoda command, found Token { kind: Ident("import"), … }`（`import` 被 lex 成普通标识符；命令分派在 `crates/front/src/parser.rs:73` `parse_command`） |
| 编译 | `compile_fol` / `check_document` **一个文件 = 一个 `Arena` + 一个 `EnvBuilder`**；prelude 在文件级安装：`crates/front/src/compile/check.rs:429-459`（`PreludeMode::Bare` 什么都不装；`Full` 装 Nat/Eq，且**文件自己有顶层 `inductive Nat`/`Bool` 时让位**） |
| prelude 模式 | 来源是**文件自己**：`-- sokonanoda:prelude none`（`crates/front/src/compile/prelude.rs:36`，`prelude_mode_from_source`）或 CLI `--bare`；45 个语料文件 **0 个**用指令，全部 Full；**9 个文件**自带 `inductive Nat` 显式覆盖 prelude（`course/{unit6,unit7}`、两语镜像、对应解答、`examples/py-nat`） |
| 缓存 | key = `format \| version \| bare? \| text`（`crates/front/src/compile/cache.rs:93`），**只含文件自身**；设计文档原话：「无跨文件依赖（教学文件自给自足，无 import），故 key 只需文件自身」（`docs/design/compile-cache.md:53`），v1 边界明确写「不做与内核 `.olean` 等价的『已编译环境导入』」（同文 §6） |
| Session / 增量 | `front::session` 的 TrustPlan 只在**本文件**内信任已检查前缀（`docs/design/i8-i9.md`）；`DocumentReport`/`DeclState` 没有"声明来自哪个文件"的概念 |
| LSP | 一个文档一个 `Session`、一个 `DocumentReport`；诊断/hover/codeLens/holes 全部按**单文档**下发 |
| 服务 | `sokonanoda watch --workspace <dir>` 已经会递归发现 `*.sokonanoda`，但**每文件一个独立 session、跨文件无全序**，且明文写着「服务是否转播留给后续，v1 不做」（`docs/design/compiler-service-events.md:51-60`；as-built `§8`） |
| 真相层 | `front::query`（I15）的 `QueryDoc` 也是单文件；六个 MCP 工具全部按 `--file` 定位 |
| 团队结论（当时） | `docs/notes/lsp-notes.md:128`：「触发引入 salsa 的条件是：多文件项目、需要交叉文件失效……**到那时再评估**」；`:191`「对我们现阶段是过度设计（单文件课程）」 |

### 3.2 已有种子（这次不用从零造）

- **清单先例**：`course/course.json`（10 个单元的**有序**清单）+ `crates/cli/tests/course.rs`
  已经在遍历四个语料目录——"项目清单"这个概念在仓库里已经存在，只是没有通用化。
- **名字体系**：`Name` 本来就是层级名（`And.intro`、`Nat.rec`），模块名天然可以
  映射成前缀；`PRELUDE_NAMES`（`crates/front/src/compile/mod.rs:25`）已经列出了
  prelude 占用的名字，闭包级冲突检查直接复用。
- **前端已有重复声明错误**：同文件重复 `def x` 报
  `error[elab-duplicate-declaration]: duplicate declaration x`（实测），
  跨模块只需要把"来源文件"带进这条消息。
- **跨文件引用基建**：`crates/front/src/references.rs`（rename/find-references 的种子）
  已经有"从 AST 位置找声明"的形状，跨模块只需让结果带 `ModuleId`。
- **arena 与 builder 的现成能力**：`EnvBuilder` 的 `add_declar`/`declaration_count`/
  `finish`（`crates/kernel/src/builder.rs:238/234/301`）本来就是"按序把声明放进同一个环境"，
  这正是多模块需要的语义——**所以内核不用动**。

### 3.3 一次改造会波及哪里（影响面清单）

| 面 | 现状 | import 之后必须回答的问题 |
|---|---|---|
| parser/AST | `Command` 枚举无 import | 新 `Command::Import`；只能出现在声明之前；错误要教学化 |
| 编译驱动 | 单文件入口 | 谁解析先后顺序？谁决定 prelude 形状？失败模块如何阻断下游？ |
| 报告 | `DocumentReport { decls, events, … }` 单文件 | 报告要按模块分组，且**每个 decl/diagnostic 带 `ModuleId`**（否则诊断指错文件） |
| 缓存 | key 只含自身文本 | 依赖变了必须 miss；依赖没变必须 hit；键怎么算（§4.8） |
| LSP | 单文档 | 项目根从哪来？改动一个库文件后**谁**重编？跨文件跳转/引用/重命名 |
| `query`/MCP | `--file` 单文件 | 查询环境要包含闭包（否则 `state` 看不到 import 来的名字） |
| `watch`/`build`/`course` | 每文件独立 | `build` 要按 DAG 顺序；`course` 的 golden 不能动（**as-built，WO-007**：`course` 认 `import`——有 `import` 的单元走同一份闭包，无 `import` 的单元仍走单文件 ⇒ `course/course.json` 的 golden 依旧不动） |
| 教学面 | 单画布 | 第 11 单元 + 新错误码 hint + `docs/protocol.md` 契约 |

---

## 5. 分阶段计划（每阶段独立可交付、可验收）

> 原则与 I15（`agent-query-channel.md`）一致：**先定契约与真相层，再上传输与表面**；
> 每阶段先写"修复前红"的测试；每阶段的验收命令必须能直接粘贴执行。

### P0 —— 设计定稿与契约（本轮，只出文档）
- **交付**：本文（含 §2 调研、§4 设计、§5 计划、§6 验收、§8 待拍板）+ `ROADMAP.md` I16 +
  `REQUIREMENTS.md` §9 + `STATUS.md` 本轮 + `docs/README.md` 设计索引。
- **不做**：一行代码、一次 bump（沿用第八十八轮"设计轮不 bump"先例）。
- **验收**：文档自洽；Q1–Q6 有明确推荐；每条设计决策都能指回一条事实（path:line 或实测）。

### P1 —— 语法与解析（不动编译驱动）
- **交付**：`Command::Import`（AST）+ parser 置顶校验 + 模块名合法性校验 +
  `import-not-a-valid-module-name` / `import-must-precede-declarations` /
  `import-malformed` 三个错误码与 hint；`crates/front/src/project/resolve.rs`
  （模块名 ↔ 相对路径、大小写提示、单根查找，**纯函数**，不读项目）。
- **测试**：front 单测（合法/非法模块名矩阵、置顶规则、`import` 在表达式位的行为）
  + CLI e2e（`import` 报错文案与退出码 1）。
- **硬约束**：**无 import 的文件逐字节不变**（用 `--json` 快照对拍 HEAD）。
- **验收**：`cargo test -p sokonanoda-front -p sokonanoda-cli --locked` 全绿；
  新增测试 ≥12 条；golden 计数零漂移。

### P2 —— 闭包编译（核心）
- **交付**：`project/{manifest,graph,report}.rs` + `compile_project()`：
  清单解析（TOML/JSON 按 Q1 定）、祖先发现、DFS 拓扑序、环检测、闭包预扫描、
  **一次 prelude 安装**、逐模块 check-then-add、`ModuleReport`/`ProjectReport`；
  CLI `sokonanoda <file>` 走闭包入口（无 import 时走原入口）。
- **测试**：两文件/三文件/菱形依赖/环/自环/重复 import/依赖失败阻断/
  开放练习不入环境/闭包 prelude 四种形状（Full、Bare、显式 `inductive Nat`、
  冲突）；每条都同时写 front 单测与 CLI e2e。
- **验收**：`--root` 与零配置退路都能编译 `import`；诊断文件归因正确（A4）；
  `cargo test --workspace --locked` 全绿、45 个语料文件行为不变。

### P3 —— CLI 与协议表面
- **交付**：`--root` / `--no-project`；`build` 项目化（DAG 顺序 + 新 `--json` 字段）；
  `query <op>` 在闭包环境下求值；`docs/protocol.md` 增补模块字段与全部新错误码；
  `docs/TESTING.md` 增补项目层的跑法。
- **测试**：`crates/cli/tests/{query,build,protocol}.rs` 扩展（**只增不改**既有断言）；
  `query check` 计数 ≡ `--json` 事件计数在**多文件项目**下依然成立。
- **验收**：A5/A6 的命令全部通过；六工具 MCP 输出信封不变（`soko.query/1`）。

### P4 —— 缓存与失效
- **交付**：`project/iface.rs`（闭包哈希）+ 缓存键升级（无 import 时与今天同键）
  + per-module 报告落盘 + `build --clean` 覆盖项目条目。
- **测试**：依赖变更必 miss / 无关文件变更不 miss / 版本变化必 miss /
  warm cache `--json` 逐字节一致 / 缓存损坏 best-effort 不失败。
- **可选**：信任台账（跳过内核重查）——**先测收益**（`stats.kernel_checks`），
  收益不显著就不做（避免无谓的信任面）。
- **验收**：A6；`docs/design/compile-cache.md` §2/§4/§6 同步为"闭包键"版本。

### P5 —— LSP 与编辑器
- **交付**：项目根发现（`initialize` 捕获 `rootUri`/`workspaceFolders`）；`Doc` 单槽 →
  `HashMap<Url, Doc>` + `did_close` 清理 + 按 URI publish；反向后继图与重编调度
  （防抖、只 publish 已打开文档）+ `didChangeWatchedFiles` handler；跨文件
  `goToDefinition`/`findReferences`/`rename`（结论带文件身份）；`code_action` 的
  judge 上下文；`soko/*` 开始真正解析 `textDocument.uri`；`soko/project`（可选）；
  VS Code 侧只做必要同步（README/CHANGELOG/package.json 版本；若加状态展示，
  走 `docs/vscode-dev-guide.md` 的测试三层）。
- **测试**：`crates/lsp/src/tests/` 新增 `project.rs`（真实 LSP 会话：跨文件跳转、
  改库刷新下游诊断、环/缺失模块的诊断不崩、`soko/project` 形状）；
  **夹具必须一起改**：`testutil.rs:81` 的 `initialize` 要能带 rootUri、
  `testutil.rs:32/218` 的诊断屏障要按 URI 过滤（今天开第二个文档会**挂起**而不是
  明确失败）、`tests/perf.rs:87-102` 的"URI 盲"断言按新语义改写。
- **验收**：A7；`cargo test -p sokonanoda-lsp --locked` 全绿（117 条里除上述
  URI 盲断言按新语义改写外，其余不动）。

### P6 —— 教学面与发布
- **交付**：第 11 单元（CN/EN + 解答 + `course.json` + 两处 golden 表）+
  `skills/sokonanoda-{teacher,dev}` 的 import/项目章节 + `AGENTS.md` 速记 +
  `dsh/README.md` 一句 + `site/`（如涉及用户可见文案）+ 版本 0.57.0 +
  `docs/HANDOVER.md`/`STATUS.md`/`REQUIREMENTS.md` §9 收尾。
- **验收**：A8 + `scripts/soko gate` PASS + 全量 `cargo test --workspace --locked` 全绿。

### P7 —— 后续（不在本轮承诺范围，登记为 backlog）
- decl 级编译产物（跨进程复用已检查环境，`.olean` 等价物）；
- `namespace`/`open`（真实 Lean 子集，需各自三件套）；`import all`；
- 跨项目依赖（`[deps]` 的 path/git 形态）与 `sokonanoda new` 脚手架；
- ~~课程语料重构（`solutions/` 改为复用 + golden 重钉）~~ → **2026-09-18 只做了安全
  的那一半**：画布**保持自给自足**（教学属性 + golden/镜像/课程树契约都不动），
  但把逐字重复的块提取成 `course/shared/` 子项目（And / Or / Nat 三个规范模块 +
  `Demo.sokonanoda` 入口 + `sokonanoda.toml`），并用双向漂移守护
  （`crates/cli/tests/course_shared.rs`）钉住 24/12/8 份副本。整包 import 化仍然不做
  ——收益（约 8% 行数）远小于代价（可独立性、golden 重钉、学习者要追模块）。
- ~~项目入口里的 quick-fix~~ ✅ 2026-09-18 完成（闭包判据前缀 + 闭包级建议材料表，
  见 `docs/TESTING.md` §7b）；
- `watch` 的项目模式（协议要不要带 DAG 顺序，见 Q6）；
- ~~`didChangeWatchedFiles`（编辑器外改文件不触发刷新）~~ ✅ 2026-09-18 完成
  （只重编译"闭包里含该路径"的已打开文档；缓冲优先）；
- ~~`soko/project`（P5 剩下的那项）~~ ✅ **2026-09-18（0.58.0 批次 4）落地**：
  只读项目状态视图 = `QueryDoc::project_view()`，三个传输（CLI `query project` /
  MCP `project` / LSP `soko/project`）+ VS Code 项目树；设计 =
  `docs/design/project-view.md`。
- ~~**`crates/front/src/compile/check.rs` 的结构债（本轮加剧）**：1717 → **1918** 行，
  其中 `run_pass` 一个函数占 553–1726 行（≈1174 行）~~ ✅ **2026-09-18（第九十五轮）
  已拆完**：`compile/units.rs`（闭包装配）+ `check/{mod,walk,kernel_phase}.rs`
  （791/951/413 行），事件流与增量语义逐字节不变（862 条测试 + 二进制对拍，
  方法见 `docs/TESTING.md`）。

---

## 7. 风险与缓解

| 风险 | 影响 | 缓解 |
|---|---|---|
| **单文件路径被改坏**（最致命） | 教学主循环与 45 个 golden 全红 | §4.1 不变式 1 写成契约测试：无 import 走**原入口**，`--json` 逐字节对拍（A1）；PR 门禁 = `scripts/soko gate` |
| 闭包 prelude 装错（重复安装/漏装） | 内核 panic（重复声明）或"未定义标识符"雪崩 | 闭包预扫描先定形状（§4.6）；四种形状的判别性测试；9 个自带 `inductive Nat` 的语料文件当活样本 |
| 诊断指错文件 | 教学体验崩坏（最容易被忽略的正确性 bug） | `ModuleReport` 携带 `path`，所有渲染只从 `(module, span)` 生成；A4 + U8 的"穷举对拍"方法（I15 教训：**新测试通过 ≠ 新语义被测试**） |
| 缓存给出**错误结论**（改了依赖却命中） | 违反"内核唯一判定者"的信任边界 | iface 递归包含依赖源文本（§4.8）；专门写"改依赖必 miss"的判别性测试（A6）；信任台账默认不做 |
| LSP 每次编辑重编整个闭包导致卡顿 | 编辑器体验退化 | 报告缓存 + 只重编受影响后缀 + 反向后继只 publish 已打开文档；P5 带 perf 冒烟（`docs/PERF.md` 阈值纪律） |
| 前端巨石再长 | 违反 REQUIREMENTS §4 | 新代码全部落在 `crates/front/src/project/` 新文件；`elab.rs`/`check.rs`/`session.rs` 只加挂接点，不加实现；收尾 `wc -l` 记账 |
| 模块名规则与 Lean 不完全一致（`-`、大小写、非 ASCII） | 破坏"教学语法 = 真实 Lean 4 子集"的承诺 | 规则逐条对齐 Lean 并在 `docs/notes/` 留出处；非法名给**可操作**的 hint；Windows/macOS 大小写不敏感专门测 |
| `requires` 版本钉太松/太严 | 要么形同虚设、要么把用户挡在门外 | v1：不匹配 = **warning + 继续**（`doctor` 里可见）；严格模式留 Q6 |
| 依赖 TOML 解析引入新 crate | 构建时间/供应链面增加 | 先按 Q1 拍板；若选 TOML 则锁 `Cargo.lock`、CI `--locked` 验证；备选 = 纯标记文件（零解析） |
| **跨模块重名没有任何测试经验** | `elab-duplicate-declaration`（`compile/error.rs:32/110`）在测试里被枚举过 4 次，但**从未有测试真正触发它**——而"同名声明到达两次"正是天真 import 实现的第一症状 | P2 第一组测试就要打这条：同名两模块 → 一条 `import-name-collision`（带两个来源），并断言**内核不被惊动**（`kernel_checks` 计数不因此增长） |
| 「静默错误」比测试变红更危险 | 三道门（`front/tests/perf.rs:108` 的 `kernel_checks<=1`、`watch.rs:292-298` 的独立性契约、judge/suggest 的静默无建议）不会报错，只会让结论悄悄错 | 见 §4.12 的专门表；每道门在对应阶段显式重写语义或显式声明边界，不靠调阈值 |
| 导入使每次 update 重新 elaborate 整个闭包 | 编辑器里改一行 → 依赖链上所有模块的 elaborate 重跑（内核重查可用信任台账省，elaborate 省不掉） | 闭包小（教学项目 <20 模块、单文件 <200 行）；P4 加 perf 冒烟与阈值；若实测超标，优先级提到 P7 的 decl 级产物（需内核决策） |
| **CI/Pages 不会发现"画布不再自包含"** | 画布与站点的守卫都不在 CI（anchor 只在本地 `soko gate`；`gen-site-demos.py` 只守产物新鲜） | A1 的逐字节对拍必须真落地成测试（P1 就加）；不要依赖既有流水线报警 |
| **fuzz 面扩大但 CI 不跑 fuzz** | 新顶层 `import` 命令的解析/编译 panic 只在本机 fuzz 时才可能暴露 | P1 在验收清单里显式跑一次 `cargo fuzz`（或把 fuzz 目标纳入 CI 作为独立工作项，另立 ticket） |
| 内核只能表达"扁平前缀环境" | 跨文件互递归／菱形遮蔽／并列命名空间**不可表达**；天真实现会在内核 panic 或静默错 | §4.5 第 11 条把策略写死（重名即错、环即错）；这些形状在 P7 之前不做，遇到就给教学化错误 |

---

## 8. 待拍板（建议已给出，等用户确认）

| # | 决策 | 候选 | 建议 |
|---|---|---|---|
| **Q1** | 清单格式 | (a) `sokonanoda.toml` + `toml` crate (b) `sokonanoda.json` + 已有 `serde_json` (c) 纯标记文件（空文件即项目根，零解析；元数据以后再说） | **(a)**：与 Lake 同风格、可注释、教学友好；代价是 +1 crate。若想零新依赖选 (c)，元数据推迟 |
| **Q2** | 无 manifest 时的 `import` | (a) 允许：模块根 = **入口文件目录**（零配置两文件 demo）(b) 报错，必须建 manifest (c) 严格对齐真实 Lean：模块根 = **进程 cwd**（但官方 Lean 连"文件自己的目录"都不在搜索路径里，见 §2.1） | **(a)**：与"单文件是默认、项目是 opt-in"一致；`--no-project` 可强制单文件语义。**(a) 是刻意 divergence**：(c) 会让"同一个文件在不同 cwd 下结果不同"，而教学 agent/DSH 的 cwd 不可控；代价只是"搬进官方 Lake 项目要按 Lake 规则摆文件" |
| **Q3** | prelude 模式的决策者 | (a) 入口文件 (b) manifest 字段 (c) 每个模块各自 | **(a)** + 冲突报错；将来若要更明确可让 manifest 覆盖（向后兼容地加字段） |
| **Q4** | 依赖库的"已检查"复用 | (a) v1 只做报告缓存（每次重查内核）(b) 同时做信任台账（跳过重查） | **(a)**，并留好观测点；(b) 必须先量收益（I8 先例） |
| **Q5** | 课程语料是否重构（`solutions/` 复用、单元共享库） | (a) 本轮不动 (b) 同轮重构并重钉 golden | **(a)**：golden 重钉应独立一轮，混在一起会让"import 本身有没有回归"无法归因 |
| **Q6** | `watch --workspace` 是否项目化 / `soko/project` 是否 v1 就做 | (a) 都不做（CLI watch 保持"每文件独立"）(b) 都做 | **(a)**：LSP 已覆盖编辑器场景；协议震动留到有真实消费者时（沿用 `compiler-service-events.md` 的节奏） |
| **Q7** | 产物/缓存位置 | (a) 保持**用户缓存目录**（现状：`~/Library/Caches/sokonanoda` 等，内容寻址）(b) 项目内 `.soko/build/`（§2.4 调研推荐的形状，模块路径为键）(c) 两者并存（项目内主、用户缓存辅） | **(a)**：零仓库污染、只读源码树可用、`git status` 干净；代价是不跨机器共享（我们不需要）。若将来要"团队共享已编译产物"，再按 (b)/(c) 走一次设计（`--cache-dir` 已存在，扩展点已留） |

---

## 10. 参考（外部调研底稿与出处）

**本轮调研底稿（仓库内，逐条带 `path:line` 或官方文档 URL）**
- `docs/notes/multifile-prior-art.md` —— 10 个系统（Coq/Rocq、Agda、Isabelle、Idris 2、
  Rust、Go、Python、JS/TS、Haskell/OCaml、JVM）的"单文件 vs 项目"逐系统记录 +
  5 问横向表 + "值得抄的模式/反模式"（每个 URL 都实际抓取核对过）。
- `docs/notes/project-roots-and-incremental-caches.md` —— LSP 契约（`rootUri` 可为 null、
  `didChangeWatchedFiles`、诊断"替换不合并"与"可读缓存"）、方言服务器根发现
  （rust-analyzer/clangd/tsserver/pyright/gopls/ocaml-lsp/Agda/lean4/HLS）与错根症状、
  失效与产物（Lake trace / GHC 指纹 / OCaml `.cmi` 摘要 / Coq `.vo` digest / `.tsbuildinfo`）、
  原子写与并发、以及"缓存判定结果安全吗"的三条规则。
- 代码接缝的全部 `path:line` 依据在本文 §4.12（同轮 subagent 只读勘察，未改动任何文件）。

**关键外部锚点（正文引用的原文）**
- Lean 4 语言参考 §5 Source Files and Modules、§24 Build Tools and Distribution：
  <https://lean-lang.org/doc/reference/latest/>
- Lean 4 源码：`src/Lean/Shell.lean`、`src/Lean/Util/Path.lean`、`src/Lean/Elab/Import.lean`、
  `src/Lean/Parser/Command.lean`、`src/lake/Lake/**`（`github.com/leanprover/lean4`）
- vscode-lean4 项目根发现：`vscode-lean4/src/utils/projectInfo.ts`
  （<https://github.com/leanprover/vscode-lean4>）
- LSP 规范 3.17/3.18：`general/initialize`、`workspace/*`、`language/publishDiagnostics`
  （<https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/>）
- clangd：<https://clangd.llvm.org/design/compile-commands>、<https://clangd.llvm.org/config>
- Coq/Rocq 命令与工具、Agda 包系统与接口文件、Isabelle system/Isar 手册、Idris 2 包与模块文档
  （逐条 URL 见 `docs/notes/multifile-prior-art.md`）

