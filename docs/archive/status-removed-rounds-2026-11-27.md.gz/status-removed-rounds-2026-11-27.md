# STATUS.md 归档（2026-11-27）

按 `AGENTS.md`「只保留最近 3 轮」移入的旧段：C9.3 卷 II.1 分析课的完整正文。原文逐字未动。

## 当前快照（2026-11-26 · C9.3 卷 II.1 分析课）
C9.3（#101）：同一份题库承载卷 II.1 分析课（单元①–⑲）——新增 34 KP / 143 题
（L1 23 / L2 77 / L3 43，综合 31）、19 lesson、3 知识卡、13 术语；II.1 34 绿 / 0 红，
全库 KP 96 绿 / 99 红、题库 409 道（可服务 400）、综合 70。跨课程 source
（`courses/analysis/…`）解析补进 `source_check.py`；validate / selftest / simulate /
notation-lint 绿，coverage 的 99 红是 C9.2 的 I.4–I.13 预期欠账。下一批见
`knowledge/CONTENT-PLAN.md`。
# STATUS.md 追加归档（2026-11-27 · C9.6）

按「只保留最近 3 轮」把 C9.6 快照移入；原文逐字未动。

## 当前快照（2026-11-27 · C9.6 发布与文档包）
C9.6：把 C9 产物做成可安装、可发现的发布。插件 README 补干净安装、
题库/代码题入口与基数、代码题提交、排障表与隐私边界；`dsh/README`、根 README、
`site/llms.txt` 加入口；技能同步题库/代码题。bump 到 0.100.0，CHANGELOG 列 C9 范围
与已知限制。判据：docs-lint / status-lint / check-site / skill+dsh / 插件测试 /
preflight --fast
