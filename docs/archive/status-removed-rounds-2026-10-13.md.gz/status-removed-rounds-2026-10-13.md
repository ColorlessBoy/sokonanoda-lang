# STATUS 归档（逐轮过程记录）

> **本文件是"旧轮的去处"** ✓（`AGENTS.md` §收尾义务 / `scripts/status-lint.py` 的口径 ✓）：
> `STATUS.md` 只留**最近 ≤3 轮**，更早的轮次进这里 ✓；这里再更早的进
> `docs/archive/`（gzip ✓，**归档 ≠ 销毁** ✓）。
>
> **已删（不归档，2026-09-30 激进删档）**：**第 1–104 轮**（2026-09-06 → 09-19）与更早的散段
> —— 原文 ⇒ `git log --all -- docs/STATUS-ARCHIVE.md` ✓。
> **本文件保留**：**最近 14 段**（第 494–520 轮，按**写入顺序**排，别当时间线读；**最老的段压缩成
> 结论 + git 指针** ⇒ 它是"合法的堆积"，但 **L1 层预算只许减不许增** ✓）。

## 第 520 轮（2026-09-30）：**E19 刀 0 —— 基线冻结（甲案开工）**

- **用户拍板**：**不走乙案**，直接甲案（元变量）；三刀 = 刀0 基线 → 刀1 **只给记法操作数位**引入
  待定参数（`SOKO_NOTATION_METAVAR=1`，**默认关**）→ 刀2 推广到 `solve_prefix` 一般路径
  （`by` 块 / `apply`，那时才碰 `ElabImplicitArgumentUnsolved` 既有判据）。**接受「课程计数 +N」**（非红线）✓。
- **冻结读数**（HEAD `2c20be09` · 二进制 `7ae7782e…`；命令/口径 ⇒ **`docs/design/e19-baseline.md`**）：
  `--json` 摘要 sha256 非课程 `43581e06…` · 课程 `d0375577…` · 全语料 `0231dcc4…` · 非课程对拍
  **172 组 0 差异** · 门禁 **43/377/99/0** · front **769/0** · notation **49/0** · G-48 复现件 **exit 1** ✓。
- **量具 + 性能基线**：`kernel-diff.sh` 新增 **`--non-course`**（⚠ 画布 **不算非课程** —— 算进去是
  174 ≠ 台账的 172 ✗）与 **`--digest`**；冷 `build` **56.67s** · `JUDGE_PREFIX runs=905` · `passes=1362` ·
  front 1.53s · notation 6.46s · 门禁 69.70s · 172 组 19.27s（⚠ 与 §1 的 47.8s/791 不同 = 语料变过）✓。
- **刀1（下一步）判据**：G-48 **exit 0** **且** 172 组 **0 差异**；开关关态 = 刀0 四个指纹逐字节相同 ✓。

## 第 519 轮（2026-09-30）：**T-N15 C 收尾 —— 「看得见的变化」索引 + 四处同步（批次 N 66/66）**

- **新增活文档 `docs/visible-changes.md`**（判据面）：每条 = **用户报的什么 → 屏幕上多/少什么 →
  哪一层的哪条断言咬住它**。覆盖用户报的 **6 条**（`build.tick` 刷屏 · Rebuild 恒 `0%` · Infoview
  版本戳陈旧 · Q1 `build.timeoutMs` · Q2 `installCli` · K1 改一行等很久）+ **隐式参数**（B2/B3）+
  记法铺面 A1–A5；⚠ **够不到的面不假装**（终端 stdout / 状态栏 / webview DOM 钉「载荷到达」那一层）。
- **登记与同步**：`REQUIREMENTS.md` §9.5 的 B3 行升级为 **B2/B3（T-N13/T-N14 收口）** + 指向新清单 ·
  `ONBOARDING.md` §0.2 队列改成「批次 N 最后 1 条」· VS Code + skills 同步（`README.md` 记法那条 ·
  `CHANGELOG.md` Unreleased · `teacher/SKILL.md` · `AGENTS.md` 硬规则 3）。
- **判据**：`docs-lint ✓` · `status-lint ✓` · `plan.py check` OK · `skill`+`dsh` 守卫 **8/0 + 5/0** ✓ ·
  课程门禁 **43/377/99/0** ✓ · `scripts/soko gate` **EXIT=0** ✓。
- **顺手修掉守卫自身的洞**（`no_course_signature_uses_an_implicit_binder`）：它原来对**带 import 的
  文件静默 `continue`**（空记法表下 `parse` 报 `NotationUnknownSymbol`）⇒ 迁移过的 4 个库里只看得到
  `lib/Set` 的 27 条 ✗。修法 = 带**继承记法表**解析（逐文件剔自声明符号）+ **解析失败也记 offender**
  ⇒ 立刻抓到 **37 条**并进白名单（**棘轮**：加签名要改清单，评审可见 ✓）。
- **端到端那条 `cases` 判据撞判定缝** ⇒ 立台账 **G-71**（`open` + **自包含复现件**，判红 = 缺口仍在 ✓，
  已进 `gap.py check` ✓）；判据主体移到真相层（夹具换纯 ∃ 形状）。
- **更正上一轮的一处误判** ✗：G-29/G-31 由 `fixed` **改回 `open`** —— 复现件的预算 `10×热开 + 200ms` 不稳定（热开 14ms ↔ 483ms）⇒ 同一天两次跑出**相反**结论；已换成**同 run 比值** `edit < 0.35 × cold`（连跑两次都判「仍在」✓），结构计数留作后续。
- **遗留**：判定缝没修（T-N13 的 4 条声明是换写法过的；pp 形态只丢**第一个**隐式实参 ⇒ 两种读法都
  不对，见 **G-71**）；点名叫法没全量迁移（仍有一批标记）；G-31 的复现件缺位。

## 第 518 轮（2026-09-30）：**T-N13 收口 —— B2 课程库改隐式风格（迁移本体 + 六条前端根因）**

- **契约**：`Set.image`/`Set.preimage` 一族 + `Function.comp`/`Rel.comp` 改隐式前导类型参数；
  调用点不必再写全 `α β`。三档 commit：`98c5804f`（库签名）→ `1d1ff0a9`（前端根因）→
  `9e07d6c7`（调用点收口 + 记账）。
- **① 库签名隐式化**：`lib/Set`（12 def + 1 abbrev + 1 axiom + 13 定理；`def Set` 保持显式）+
  `lib/Image` 6 条 + `Function.comp(_apply)` + `Rel.comp(_apply)` ⇒ 16 个 lib 逐个 **exit 0 / failed 0** ✓。
- **② 六条前端根因**（逐条带 front 判据 + **反向验证**）：① `unfold_one` 的实参对齐分短写/旧写法
  两种读法；② 零元记法在**函数位**（`(∅) x`）走唯一钩子；③ `unify_extract` 的**嵌套**实参位递归匹配；
  ④ `solve_prefix` 的**模板侧**展开（闸门：实际项剥到底的陪域必须是 Sort）；⑤ 路线③ 闸门补
  `starts_old_style`；⑥ 解出的隐式实参也吃该层的域当期望类型。
- **③ 调用点**：10 文件 / 19 诊断 ⇒ **0**；4 条声明按「项风格 + 显式前提」重写 —— `by` 块的 tactic
  路径在「pp 回读 + `Eq.subst`/`And.left`/`⊆`-展开」一族上会撞**判定缝**（两边 pp 一样而内核判不等）。
- **判据（逐项实测）**：课程门禁 **43 目标 · 377 checked · 99 open · 0 判负**（+1 = 新增的
  `diag_helper`）· `cargo test -p sokonanoda-front` **769/0** · 非课程语料对拍 **172 组 0 差异** ✓ ·
  `notation-lint` OK（豁免 587 处全带标记）· `gap.py check` 一致 ✓（**G-29/G-31 一度误改 `fixed`，
  第 519 轮已改回 `open`** —— 复现件的墙钟预算不稳定，两次跑出相反结论 ✗）。
- **遗留（写清楚）**：判定缝本身**没修**（4 条是换写法过的，缝的形状 = 「pp 回读 ⇒ 隐式实参/宇宙
  层级不同形」，与 E19/E20 同一片地，复现件留作 E19 取证）；点名叫法**没全量迁移**（仍有一批带
  标记的调用点，「数量级下降」只做到「不再必须写」）；G-31 的复现件缺位（详见 `docs/design/e2-plan.md`
  的 T-N13 as-built「遗留」三节）。

## 第 517 轮（2026-09-30）：**G-70 收口 —— 注册表签名必须「去记法」（+ 一个守卫自己的 bug）**

- **病根（B2 迁移实测）**：`KnownName::Decl::signature` 存的是 `render_expr(ty)`，而
  `implicit::telescope` 用 `parse_expr_text`（**空记法表**）把它**回读** ⇒ 签名里只要有一个
  记法节点（库定理常写成 `a ∈ univ`）解析就失败 ⇒ 望远镜 `None` ⇒ **隐式插入整条不触发** ✗
  ⇒ 实参落进隐式位（`exact Set.mem_univ x` ⇒ `期望 Set.univ α x，实际是 (a : x) -> Set.mem a Set.univ`）。
- **修法**：新增**判定路径**的去记法渲染 `proof::expand_notations` + 唯一入口
  `elab::decl_signature`（13 处 `signature:` 调用点全部改走它）⇒ 产物能被空记法表回读 ✓。
- **判据**：复现件 `G70-*.sh` **exit 1（已修）** ✓ · **反向验证** ✓（用未修的二进制跑同一件
  ⇒ exit 0 + 上面那条报错）· **未迁移**语料对拍 **644 组逐字节相同** ✓ · 课程门禁 **43/376/99/0** ✓。
- **顺带修掉一个守卫自身的 bug** ✗：`scripts/kernel-diff.sh` 的差异报告器写成 `"$file（exit …）"`
  —— bash 把全角括号并进变量名 ⇒ **恰好在「有差异」时**崩掉 ⇒ 改成 `${file}` ✓（修好后当场报出
  2/644 组差异，定位到本轮**语料**改动 ✓）。
- **⇒ B2 的三个前置（G-43 / G-69 / G-70）都已收口**；剩**调用点迁移本体**（分类表与顺序写进
  `docs/design/e2-plan.md` 的 **T-N13 as-built** ✓）。⚠ 迁移期间课程门禁会红 ⇒ **整段做完再一次过**。

## 第 516 轮（2026-09-30）：**G-69 收口 —— 归一化护栏补「逐位递归」（T-N13 的第二个前置）**

- **病根**：`by.rs::keep_if_lossless` 只比**顶层** spine 实参个数，而记法节点在 `spine_of` 里
  算 **1 个** ⇒ `Set.subset (A ∩ B) A` 与 pp 形态 `Set.subset (Set.inter A B) A` **顶层相等**、
  护栏放行 ✗ —— 可 pp 已把内层 `Set.inter` 的隐式 `α` 省掉 ⇒ `intro` 派生的假设成了**丢了参数的
  点形式** ⇒ `unfold_one` 把 `Set.inter A B x` 对成 `α := A, A := B, B := x` ✗。
- **修法**：护栏补**逐位递归**（新 `notation_positions_keep_implicit_prefix`）—— 源级记法节点在
  pp 形态里必须把该目标的**前导隐式实参**写出来（实参个数 ≥ 操作数 + `implicit_prefix`）；
  `DefInfo` 因此新增 `implicit_prefix`（两个构造点与 `KnownName::Decl` 同源 ✓）。
- **判据**：`compile/tests.rs::a_derived_hypothesis_solves_implicit_arguments_like_a_written_binder`（**反向验证** ✓：让该函数 `return true` ⇒ 当场判红）· 复现件 `G69-*.sh` **exit 1** ✓ · 对照组仍绿 ✓。
- **红线（逐项实测）**：全语料对拍 **644 组逐字节相同** ✓（今天全部记法目标 `implicit_prefix`
  都是 0 ⇒ 新判据**一次都不触发** ✓）· 课程门禁 **43/376/99/0** ✓ · front **796/0** · 记法契约 **50/0** ✓。
- **⇒ T-N13 的两个前置（G-43 / G-69）都已收口**；剩**迁移本体**（9 文件 / 19 诊断，逐站点改）。

## 第 515 轮（2026-09-30）：**G-43 收口 —— lambda 实参按「书写类型」求解（T-N13 的前置）**

- **病根（探针实测）**：**显示与判定共用一条 pp 文本** —— 内核 pp 会**丢掉第一个隐式实参**
  （`Set.image α β f A` 打成 `Set.image β f A`；后续隐式实参却留着：`unfold_apps_pp` 的
  `is_implicit_fun(fun)` **只认裸 `Const`**），而 `operand_type_expr` 把这份文本**回读成项**当
  "实参的类型" ⇒ 解出 `α := β` ✗ ⇒ `期望 Sort(1)，实际是 Pi ( : $4), $4`（**与 `import` 无关** ✓）。
- **修法（front 一处，内核零改动）**：新增 `lambda_source_type` —— lambda 的类型由**源级 binder
  注解**拼出来（`fun (h : P) => h` : `P → P`），与既有「`Ident` 取 `scope.source_type_of`」同一条
  **书写类型优先**规则 ⇒ 零内核调用、不被 pp 丢参污染 ✓；其余形状照旧问内核（不比从前差 ✓）。
- **判据**：`compile/tests.rs::a_lambda_argument_takes_its_written_type_not_the_lossy_pp_text`；**反向验证** ✓（中和成 `return None` ⇒ 当场判红）；复现件 `docs/gaps/repro/G43-*.sh` **exit 1（已修）** ✓。
- **红线（逐项实测）**：内核零改动 ✓ · 全语料对拍 **644 组逐字节相同** ✓ · 课程门禁 **43/376/99/0** 逐项相同 ✓ · front **795/0** · 记法契约 **50/0** ✓ · `gap.py check` ✓。
- **纪律教训**：本轮**两次**自造对照件被 bash 吃掉了 `''`（单引号里 `''` 会闭合引号）⇒ 量到的是 `f  A`（**另一个形状**）✗ ⇒ **对照件源码要 grep 出来核对** ✓。另：整文件批量改调用点**又一次证伪** ✗（649 处 ⇒ 16 文件判红）⇒ 只许逐站点核 ✓。

## 第 505 轮（2026-09-30）：**开工单纠错 + 三条用户实测 UI 缺陷全部收口** ✓

- **结论**：开工单纠错（P1-c/P1-d 权威定义 + 6 处悬空引用 + DSH 薄入口守卫，反向验证判红 ✓）·
  Infoview 两个"版本"判死（产物戳陈旧 ⇒ 每次写产物刷新戳 + 屏幕上补标签）· 终端 `build.tick`
  默认不发（`SOKO_BUILD_TICK_MS` 显式要）· Rebuild 0% 突跳 ⇒ additive 的 `build.progress`
  （42 条、跨度 4.15s→160.47s，真宿主 36/36 ✓）· P1-b 第二刀触 `--json` 红线 ⇒ 精确回退。
  **原文逐字 ⇒ `git log --all -- docs/STATUS-ARCHIVE.md`** ✓（2026-10-01 按 L1 预算压缩）。

## 第 521 轮（2026-09-30）：**E19 刀 1 —— 记法操作数位的待定参数（开关默认关）**

- **切片**：`SOKO_NOTATION_METAVAR=1`（**默认关**）⇒ 记法前导参数在**最大候选**上解不出时走
  **待定档**：先记 `?α`，走完由**同形的已解兄弟**合一（`spine::same_shape`，忽略 span）；
  **一个兄弟都借不到就照旧失败**（`∅ ≈ ∅` 不猜）✓。`implicit.rs` 求解骨架**一字未动** ✓。
- **语义（要用户点头的那一条）**：开关开时 `∅ ≈ {b}` 读作 **`Set.Equiv β β ∅ {b}`**
  （`α` 跟已定的 `β`）—— 论域是**选出来的**，不是推出来的 ⇒ **刀2（默认开）之前先问** ✓。
- **判据**：G-48 复现件 关态 **exit 1**（逐字节不变）/ 开态 **exit 0** ✓ · 非课程 **172 组对拍**：
  关态 **0 差异**、开态 **2/172**（**恰好** G-48 那一份，其余 170 组相同）✓ · 关态三个 sha256
  **逐字节等于刀0** ✓ · 开态**课程摘要不变** ✓ · 课程门禁两态都 **43/377/99/0** ✓ ·
  front **770/0**（+1 新判据）· notation **49/0** · 新判据 `crates/cli/tests/notation_metavar.rs`
  （开绿 / **反向**关红 / **不猜**）✓。
- **性能（先计数后墙钟）**：关态结构计数 `JUDGE_PREFIX runs=905 / bytes=47,866,553` ·
  `passes=1362` · `by_calls=21,551` · `JUDGE_INFER 87,507` —— **逐项等于刀0** ✓（元变量只在
  解不出的路径上生效 ⇒ 默认路径零开销 ✓）；墙钟 front 1.45s · notation 6.21s · 门禁 80.01s
  （基线同序列 80.69s）· 172 组 20.09s（基线 19.27s）⇒ **无退化** ✓。
- **记账 + 用户拍板**：`docs/design/e19-baseline.md` **§6 as-built**（语义 / 判据 / 回退一处）·
  台账 G-48 补登"开关默认关 ⇒ 仍 `open`"✓ · 第 518 轮归档 ✓ · 用户拍板：**接受那条语义** ✓、
  **刀2 沿用同一个开关默认关** ✓ ⇒ 下一轮直接开刀2 ✓。


## 第 522 轮（2026-09-30）：**E19 刀 2 —— 推广到 `solve_prefix` 一般路径**

- **切片**：同一个开关（当时默认关）下，机制上移一层到 `implicit::solve_prefix`（应用 / 裸常量 /
  `by` 的 `apply` 共用）—— 先跑严格档，失败才走待定档；返回形状与三个调用方**都没动** ✓。
- **判据 + 逐条重审 + 性能**（关态逐项等于刀0 · 开态 `runs=886`/`passes=1343` · 非课程 172 组
  **2/172**（恰好 G-48）· 门禁两态 **43/377/99/0** · 新判据 `crates/cli/tests/implicit_metavar.rs`）
  ⇒ **全部 as-built 在 `docs/design/e19-baseline.md` §7**（本文件不复制，避免两处漂移 ✓）。


## 第 523 轮（2026-10-01）：**E19 默认开 —— 逃生门保留、默认开 + 发 `v0.79.0`**

- **用户拍板**：**默认开** + 开关**保留为逃生门**（`SOKO_NOTATION_METAVAR=0`/`off` ⇒ 严格档）⇒
  两态反向验证照旧可跑；代码面只有 `implicit::metavar_enabled()` 一处（三个调用方**一字未动**）✓。
- **判据 + 交叉验证 + 逐条重审**（默认/逃生门两态摘要 · 门禁两态 **43/377/99/0** · `--digest`
  三个 sha256 证明「只翻了默认值」· `solve_prefix_reads_the_expected_type` 末条改成两条）
  ⇒ **全部 as-built 在 `docs/design/e19-baseline.md` §9**（本文件不复制，避免两处漂移 ✓）。


## 第 524 轮（2026-10-01）：**IA-4 立项 —— 元参数引擎设计计划**

- 用户拍板：E19 闭环，下一大项目 = 真正元参数；**先出设计计划** ⇒ `docs/design/metavar-engine.md`
  （设计 + 切片 + 决策点）；两条关键更正：**合一治不了 G-48 的 `α`**（那位**没有约束** ⇒ 必须显式
  **defaulting**）· 当时实测**接受面增量小**；集合论教材线同日排进队列 #2（S-A/S-B/S-C）✓。
- 记账：`ONBOARDING.md` §0.2 · 预算表登记 · 过期登记 · 第 521 轮归档 + 第 494 轮二次下沉进 L3 ✓。

## 第 525 轮（2026-10-01）：**IA-4 M0 收口 —— 基线冻结 + 13 形状能力清单（零行为变化）**

- **只加判据与取证，没动实现** ✓：新 `crates/cli/tests/metavar_inventory.rs`（**13 形状 × 2 开关态
  = 26 次真进程**，一个 `#[test]`，**1 passed / 2.21s**）+ `docs/design/metavar-m0.md`（93 行）✓。
- **三态分类（实测）**：**可解 7**（记法①/应用①②/裸常量②/Pi/路线③/两条约束 defeq 一致）·
  **依赖默认 3**（G-48 记法 + 刀2 应用 + 操作数顺序相反）· **解不出 3**（两侧都零元糖 · 参数不可达 ·
  **约束冲突**）——每条的**退出码 + 诊断码**都钉进测试（M1 的红线）✓。
- **结论（量化）**：**接受面增量 0/13** ⇒ 与设计 §0 的 C2 一致 ⇒ 按 **D7 缩范围**：余片次序 =
  **M1 引擎内核**（含 **S13 ⇒ 必须复用 delta 兜底**，否则误拒今天绿的形状 ✗ + `sibling` 回归臂）→
  **M3 sort/kind + 报错契约**（价值最高）→ **M2 一般路径接线** → **M4 默认开**（M1–M3 全绿后才谈）✓。
- **基线（逐条复现）**：三指纹 `7646fe2e…`/`d0375577…`/`06370a38…` **逐字节等于**设计 §1.4 ·
  `--non-course <bin> <bin>` **172 组 0 差异**（判据通道活着）· 门禁 **43/377/99/0** ·
  结构计数 `runs=886 bytes=47,437,669` · `passes=1343` · `by_calls=21,268` ✓。
- **记账**：`metavar-m0.md`（基线 + 清单 + 结论 + 复跑）· `metavar-engine.md` §4 M0 行 ✓ ·
  `ONBOARDING.md` §0.2 队列 #1（余片次序按 D7 重排）· 第 522 轮归档 · 第 523 轮压成指针（L0 只许减）✓。
- **用户 2026-10-01 定**：M0 之后**先做 IA-4 M1**（引擎内核）；**M3 的 sort/kind 检出行为 = 作废该
  候选 + 报既有码**（不做 hint-only、不新增码）✓ —— **M1 未开工**（本轮只到 M0 的片边界）。


## 第 526 轮（2026-10-01）：**IA-4 改做最完整版 —— 差异盘点扩写 + 范围全开**

- 用户推翻两条旧拍板（**D7 缩范围作废 · D2 宇宙层不做作废**）：做最完整版、**内核可改**、
  功能与性能并重 ⇒ `metavar-engine.md` 重写（§1.2 **17 行 Lean4/Coq 机制对照** + 11 个"查无此名"
  更正 · §2.9 宇宙层 · §2.10 范围 B · §2.11 内核支持 · §4 切片扩到 M/K/B/U）✓；
  D8 拍板 = **内核占位符**。记账：`ONBOARDING.md` §0.2 · `REQUIREMENTS.md` §9.6 ✓。

## 第 528 轮（2026-10-01）：**IA-4 M2 收口 —— 引擎接进一般路径**

- **接线** `implicit::solve_prefix_meta`（应用 / 裸常量 / 路线③共用同一条 `solve_prefix`）：严格档
  **永远先跑且不变**，失败后按档位分流（`Engine` ⇒ 引擎 / `Sibling` ⇒ E19 窄版）✓；
  **`fill_pending_by_shape` 降级**为 defaulting 的**参考实现**（`Sibling` 档那一份，引擎档的等价物 =
  `MetaCtx::default_unresolved`）✓。
- **判据**：front **782/782** · `implicit_metavar` **1 passed**（四条断言）· `metavar_inventory`
  **1 passed** · `metavar_engine` **3 passed**（M1 记法 5 形状 + M2 一般路径 5 形状，各 × 4 档）·
  `notation`/`notation_metavar` **49/1** · **三指纹：默认档与引擎档都逐字节等于冻结值**（0 增 0 失）·
  引擎档门禁 **43/377/99/0** · 冷 build 结构计数**逐项等于基线** · `gate --fast` **EXIT=0** ✓。
- **读数口径再修正**（M0 只说了全局缓存）：冷 build 计数还要求**项目缓存确认是空的**
  （`build --clean` 后 `ls courses/set-theory/.sokonanoda/compiled | wc -l` = 0）且**别与别的编译并发**
  —— 实测踩到 `compiled 30 / hit 12`、`runs=616`（**热启动，不是回归**）✗。
- **记账**：`metavar-engine.md` **§9 as-built** · `ONBOARDING.md` §0.2（M2 ✓，下一片 **M3**）·
  第 525 轮归档 · 预算 `_comment`（cap 360→400）✓。

## 第 529 轮（2026-10-01）：**IA-4 M3 收口 —— sort/kind 闸门 + 三通道归因**

- 引擎内 sort/kind 闸门（只拒「确定错」⇒ 不可能假拒绝）+ `MetaSolve{Solved,Unsolved,Kind,Clash}` 三通道：**码与 hint 契约不变**，只按通道换 message 那一句。
- 判据：真值 15/15 · front 786/786 · 三指纹两态逐字节等于冻结值（**本轮零用户可见变化**）· `gate --fast` EXIT=0；⚠ 诚实更正：设计 §4 的「kind 夹具不再落内核」做不到（严格档先跑且成功）⇒ 闸门是引擎自己的守卫，搬去 elab 期留作决策点。细节 ⇒ `docs/design/metavar-engine.md` §10。
## 第 534 轮（2026-10-01）：**增量检查 —— 独立验证 S2 步 1/步 2 + 结构计数探针（G-29）**

- **独立复跑**并行会话的 S2 步 1/步 2（`7c9936be`）：`cargo test --workspace` **58 套 0 failed** · 课程门禁 **43/377/99/0** · `gap.py check` exit 0 · fmt ✓ ⇒ 「纯重构零行为变化」成立。
- **更正口径**：`JUDGE_PREFIX runs` 只在 `judge_infer_uncached` 加（**不是** `by` 批次）；单文件对照 `passes` **24** vs 闭包 **113**。
- **新探针** `docs/gaps/repro/G29b-keystroke-structure.js`：`--cli` 给机器无关的结构计数 —— 改第一条 vs 改最后一条**完全相同**（113/79/1195）⇒ 「整文件重编」的签名。
- **S5 试做后回退**（收益未证实 + 在判定正确性路径上）⇒ 落点写进 G-29 `notes`。细节 ⇒ commit `767ca072`/`83c06abf`。
## 第 532 轮（2026-10-01）：**编辑响应 —— 去掉整文件高亮 + 增量检查诊断（用户反馈「整个文件被高亮」）**

- **整文件高亮确认仍在**（`setCompileDecorations` 范围=整份文档 + `backgroundColor`；P7 只改了"什么时候出现"）⇒ **已修**：只留概览尺第一行、无背景色（stub 三条断言）。
- **诊断**（真 LSP · unit08）：冷开 3093ms · 热开 11ms · **改一行 2154ms**；**改动位置不影响成本**（第 1 条 3157 / 第 12 条 2002 / 最后一条 2350ms）⇒ 前缀复用没生效。结构计数 `passes=113` · `JUDGE_PREFIX runs=79` · unit 编译 104；拆开 = 库层 ~500ms（14%）+ **入口自己 ~3.0s（85%）**。
- 根因 = G-29/G-31；设计（S1–S4 分片 + 判据）⇒ `docs/design/declaration-incremental.md`。细节 ⇒ commit `8f401586`/`407b5086`。
## 第 531 轮（2026-10-01）：**记法输入表补全 —— 希腊字母 + 课程符号（用户反馈「`α` 打不出来」）**

- 表 **18 → 75**（希腊 48 · 课程库 7 · 尖括号 2 · 既有逻辑 18）；`notationSymbol` 位区分「进词法的符号」与「标识符/括号」；LSP hover 加输入提示 · 上游 vscode-lean4 逐字取证（扁平表 / 最短键赢 / `\a` 是 α 的键）· `\<`/`\>` 词首规则。
- 双镜像契约（Rust `TABLE` 单一真相 + JS 逐条一致）由 `cargo test -p sokonanoda-cli --test extension` 钉死；调研与决策 D1–D7 ⇒ `docs/design/notation-input.md`。细节 ⇒ commit `117f849d`…`4eeb1482` 与第 532 轮的更正。
## 第 527 轮（2026-10-01）：**IA-4 M1 收口 —— 引擎内核 + 记法路径接线（默认档 = 今天）**

- **新模块 `crates/front/src/compile/meta.rs`**（元变量 = `\0soko_m{id}` **名字编码**）：三值合一
  （`Undef` = 弃权）+ 快路径 + **两侧**分解 · **occurs/type-occurs/作用域**三闸门 · 有界待定不动点
  （计数不降就停）· 三上限 · defaulting（E19 规则显式化）· zonk 无残留 · **delta 兜底**（S13）✓。
- **接线 + 三态开关** `SOKO_METAVAR=0|sibling|engine`（**默认 sibling = 今天**；旧逃生门仍等价）；
  记法路径按档位分流（**一般路径 = M2**）✓。
- **判据**：真值 **11/11** · front **782/782** · M0 清单 **1 passed**（26 读数一条不变）· 新
  `metavar_engine` **2 passed** · notation 系 **49/1/1** · **三指纹：默认档与引擎档都逐字节等于
  M0 冻结值**（⇒ 引擎 0 增 0 失）· 门禁 **43/377/99/0** · 结构计数**逐项等于基线** · gate **EXIT=0** ✓。
- **抓到两个真 bug（都修 + 钉判据）**：① **作用域误拒**（`notation_telescope` 用签名原文名 ⇒ 与用户
  变量撞名）⇒ 引擎路径**先 freshen 望远镜名**；② **缓存键漏开关**（**既有**，`v0.79.0` 也复现 ⇒ 逃生门
  被静默忽略）⇒ 键加**档位字节**（默认档保持 0）；残留面 `SOKO_JUDGE_INPLACE=shadow` **记账未修** ✓。
- **记账**：`metavar-engine.md` §8 as-built · `ONBOARDING.md` §0.2（M1 ✓，下一片 M2）· 第 524 轮归档 ·
  预算 `_comment`（cap 320→360）✓。

## 第 530 轮（2026-10-01）：**编辑响应 —— P7 展示延迟（用户反馈「一闪一闪」）** ✓

- **结论**：闪烁源 = 服务端**每键都编一次** ⇒ `$/progress` **2.0 条/键**，每个 `begin` 给**整份文档**加
  背景装饰 + 状态栏 + Infoview 进度块 ⇒ 真 VS Code **8 键亮 16 次**。P7 = `begin` 只挂定时器、`end` 先到
  就撤（窗口内编完的**一次界面都不碰**）。**前后**：闪烁 **16 → 0**（项目模式 A/B **18 → 0**）· 键→诊断 122 → 99ms · 键→面板 268 → 263ms。权威 ⇒ `docs/design/edit-latency.md`（含 §3 六条"不做"）。
## 更早的段（**二次下沉进 L3** ✓）

> **第 497 轮**原文逐字 ⇒ `docs/archive/status-removed-round-497-2026-10-01.md.gz`
> （2026-10-01 二次下沉：**L1 层预算只许减不许增** ✓）；
> **第 498–499 轮**原文逐字 ⇒ `docs/archive/status-removed-rounds-498-499-2026-10-01.md.gz`
> （2026-10-01 二次下沉：**L1 层预算只许减不许增** ⇒ 最老的段进 L3 ✓）；
> **第 496 轮**原文逐字 ⇒ `docs/archive/status-removed-round-496-2026-10-01.md.gz`
> （2026-10-01 二次下沉：**L1 层预算只许减不许增** ✓）；
> **第 494 / 500–501 轮**原文逐字 ⇒ `docs/archive/status-removed-round-494-2026-10-01.md.gz` ·
> `docs/archive/status-removed-rounds-500-501-2026-10-01.md.gz`（2026-10-01 二次下沉：
> **L1 层预算只许减不许增** ⇒ 最老的段进 L3 ✓）；更早的 ⇒ `git log --all -- docs/STATUS-ARCHIVE.md` ✓。

## 收口（2026-10-11）`v0.88.1`：声明列表去行号 + 名字普通粗体（判据四层 + **反向验证 8 条**判红 ✓）· 内核包版本随产品 · 本地 `gate` 被 60 分钟 timeout 截断（0 失败）。**原文** ⇒ git log --all -- STATUS.md ✓

<!-- 2026-10-13 从 STATUS.md 移入（AGENTS.md：只保留最近 3 轮） -->
## 清台账第 2 轮（2026-10-12）：**独立复核证伪 6 条** ⇒ 判据本身补了 4 条新守卫（未发版）
- **队列：41 条（高 5 · 中 24 · 低 12）** · blocker **0** ✓ · 本轮收口 9 条（`DOC-DANGLING` · `STRUCT-SRC-LINES` · `CI-WIRE-GUARD` · `W-1` · `W-2` · `W-STALE-PREMISE` · `C4` · `F10` · `r24/E1`）· 新增 1 条（`PROBE-ANCHORS-STALE`）。
- **§5 独立复核证伪 6 条**：`r10`/`r11`/`r23` = 判据**空转**（锚点读错行，exit 1 是干净树的默认态）· `H2`/`H3`/`N1` = 判据**不可复现**（needle 在画布上 0 次）⇒ **全部撤回收口**并更正口径；`r08` 结论成立但 commit 引错（真修复 `cac30118`）。
- **新守卫 4 条（都带反向验证）**：`docs-lint` 判据 **⑧**「文档引用可解析」（`--check-doc-refs`；存量 469→445，冻结成**只许减不许增**）· 判据 **⑨**「源码行数红线」（硬规则 5 的**首条机器判据**，46 个文件冻结）· 调度器**反向两层漂移**判据（来源已终态而调度器未终态 ⇒ 判红，治「修好了没登记」）· 探针**读数可归属**（非 `repo-build` 一律 exit 2/3 ⇒ 治假绿与「拿 0.83.0 判 0.90.0」）。
- **`CI-WIRE-GUARD`**：`audit-wire-fields.py` 接进 `ci.yml` 的 `contract` job —— 它原来只在本地 `soko gate`，而 **CI 从不跑 gate**（4 处命中全是注释）⇒ 接缝守卫在 CI 上**一直空转** ✗。
- **22 个复现件**不再硬编码 `target/release/…` ⇒ 受管环境下 `gap.py check` **25 条不一致 → 1 条**；默认环境 **exit 0 · 122 条通过** ✓。
# 当前快照（2026-10-12 · 最新一轮：**初学者体验三条 —— prelude 关键字 · vim 输入四修 · 隐式实参第二候选 + `apply` 结论校验**（未发版）；上一发版批次 **`v0.88.2`** = 版本切换 ⇒ 自动全量预热）
## 台账机制：**脚本当事件调度器**（2026-10-12 用户四连要求）
- **唯一机器入口** = `python3 scripts/ux-queue.py --next`（`--json` 机器读）：**队列 50 条未完成**（blocker 1 · high 9 · medium 26 · low 14；总量 73 = open 50 + 终态/边界/对照 23，**终态也留账** ⇒ 删条目 = 关守卫 ✗）。
- **调度器（规则在代码里）**：`--claim` 原子认领（锁在共享 git 目录；别人持活锁判红，死进程/超 TTL 才准 `--force`）· `--advance … --to done --commit … --reading …`（**没证据不许收口**）· `--add-child` 就地拆解（子任务插在父之前、父转 umbrella）· 非法迁移由 `TRANSITIONS` 表拒 ✗。
- **修掉上一轮另一个 agent 的三处硬伤**：§0.2 解析器只认二级标题而真文件是 `### 0.2` ⇒ 双向对账**从未跑通** ✗；它给 §0.2 现编 `Q-*`/`F-*`/`T-*`（来源里不存在的 id）⇒ 28 条红；它的 selftest fixture 是八列（契约七列）⇒ 永远红。现在 §0.2 = **渲染摘要块 + 粗粒度线**（47 → 28 行）。
- **判据**：`--selftest` exit 0（11 条读数判定 + 5 条反向验证 + **调度器 16 条**）· `--check`（覆盖 + 不变量）exit 0 · `--next` ⇒ `r07`（最该先修的那条）· **`gate --fast` exit 0**（含新队列门禁）· `docs-lint` ✓（L1 达标；必读 1000 → **978/1000**）· CI `ledger` job 同步接上。
- **发版节点（栅栏 + 克制 + 防无限 bug 分支）**：`--release open/add/check/block/drop/cut` —— 入版必须 done 且有证据 · **收拢**（不许有在飞认领 + 树干净）才准切 · 同一 blocker 试修**上限 3 次**（第 4 次脚本拒 ✗ ⇒ 只能换思路或 `drop --reason` 带着已知问题发）。 **外部提交面（inbox）**：`--submit fix|doc|gate|release-blocker --id … --where … --why … --evidence … [--patch]` ⇒ 外部 agent **只提交不改主线** ✗；`--inbox` 看状态 · `--triage … --to applied --commit <sha>`（受理必须带 commit）。接口 agent 任务书：`.cache/ux/PROMPT-interface-agent.md`。**并行基建**：`scripts/agent-worktree.sh new|list|land|rm`（4 核 = 4 棵 worktree + 分支 `agent/<id>`；独立 `CARGO_TARGET_DIR`；队列单点 `SOKO_QUEUE_ROOT`（不设直接拒 ✗）；`land` 只在主 checkout 上做）· `.worktrees/` 进 gitignore · `check-multi-session.py` 接进 `gate --fast`/CI · `--release check` 拦"agent 分支没合回"。**编译缓存收口**：`scripts/compile-cache.py`（跨树总管）—— `status`（硬链接去重，与 `du` 同口径）· `env <id>`（独立 target + **sccache** 共享 + `CARGO_INCREMENTAL=0` + 队列单点）· `reclaim`（死树 → `incremental/` → LRU；用 `.cargo-lock` flock 探测构建并拒绝 ✗）· 预算默认 60 G **超了 gate 判红** ✗ · `--selftest` ✓。**实测回收 50.2 G → 29.7 G（−27.8 G）**
- **判据**：`--selftest` **exit 0**（新增 11 条：没证据的提交拒 · applied 没 commit 拒 · 空节点拒 · <3 条拒（克制）· 有在飞认领拒（收拢）· **第 4 次试修拒** · drop 带理由过 · cut 缺 `--ci` 用法错）。
- **未做（如实）**：用户提的"**所有台账物理合成一个文件**"是跨模块重构（12 个真实 reader/writer + CI job）⇒ 独立一批；本笔只把**逻辑入口**收成一个。
- **⚠ 本批（4 核调度器这笔）再次用 `--no-verify` 推**：pre-push 的缺口台账 `--strict` 依旧被 **G-81 超时**挡下（非 strict `gap.py check` = **0 条不一致**；单跑 G-81 ≈ 66s 即过）⇒ **环境慢**，与上一批同形（**本轮第三、四笔（发版节点/提交面）同因**：非 strict `gap.py check` 仍 0 条不一致）。
- **⚠ 本批用 `--no-verify` 推**（纪律要求在此写明原因）：pre-push 的缺口台账 `--strict` 又被 **G-81 超时**挡下；非 strict 的 `python3 scripts/gap.py check` 为 **0 条不一致**，单跑 G-81 约 66s 即过 ⇒ 判为**环境慢**（与上一批同一形态）。 **本批（20:5x）还判红了 G-25**（`fixed` 而复现件报「缺口仍在」，`热开 15ms（2.5×）`）—— 旧判据是**墙钟三倍线** `hot * 3 < cold`（正是 AGENTS.md「判据不许用绝对毫秒」点名的假红；同代码 2.5× ↔ 8.4×），本轮已换成**结构性计数**（`SOKO_LSP_TRACE` 的 `modules=`：冷 3 ⇒ 热 1）⇒ 复现件 **exit 1 = 已修** ✓；权威判定交给 CI 的 `ledger` job ✓。
## 初学者体验长尾 ①–⑤（2026-10-12 · 用户拍板「好的」后按序开工）：洞位置模式 · 归因 · 内核说人话 · 补全 · 缓存键（未发版）
- **① LSP A1（blocker，`31354503`）**：`by` 块里的灯泡标题写 `exact hp`、**正文却只插 `hp`** ⇒ 一点就判红（`unexpected-token`）。修法：洞带**位置模式**（`HoleMode` Tactic/Term，`DeclState.hole_modes` 与 `holes` 逐位对齐，**`REPORT_SHAPE` 7→8**），tactic 位给 `exact hp`、值位仍给裸 `hp`；`lsp/actions.rs` 收敛成"只插 front 给的文本"。判据：A1 **exit 0**（改前 1）· 对照臂 A2（项位）仍 0 · **新增 A1b**（同文件两类洞 ⇒ 咬"模式按洞不按文件"）0 · **新增 A1c**（tactic 位每条候选都判绿）0 · `--all` 只有 A1 由不一致转一致。反向：强制成 Term ⇒ 三条全 **exit 1**。
- **② 入口 parse 错不再甩锅（`951a6fbc`）**：同一份文件"不用记法"报 `unexpected-token`（对）、"用了记法"却报 `import-module-invalid` + 级联 `notation-unknown-symbol`（错，LSP 还把红波浪画到签名里的 `∈` 上）。修法：新码 **`entry-parse-failed`**（`stage=parse`）+ `graph.rs` 按**真相层**"这个模块是不是入口"分流（依赖方向 `import-module-invalid` 语义收窄、断言未放宽）+ `query` 级联加闸门 + LSP 诊断以报告为准。判据：`r06` **exit 1** · `D1` **exit 0**（LSP 与 CLI 都报真错那一列）· **两通道诊断集逐条相等**（新契约用例）· 干净对照（未被 import 的 `⋆`）仍报未声明记法 ✓。
- **③ 内核拒绝说人话（`0ff4aede`）**：`kernel-rejected` 原样漏 `Pi ( : …)`/`Set.[]`/`第 N 个绑元（α）`，且 span 覆盖整条声明。修法（**只在前端渲染层，内核零改动**）：`$k(name)` 还原源级绑元名 · `.[]` 去掉 · `Pi (x : T),` 印成 `∀ (x : T),` · 走**唯一记法接口**（`Set.mem α a A` → `a ∈ A`）· Pi 比较时 span 收到**值**位（裸 sort 比较仍用整条声明）；反向开关 `SOKO_NO_SOURCE_KERNEL_MSG=1`。判据：`r01`/`r15` 均 **exit 1** · 反向两态各复现 · **判定不变**（40 文件 × 2 臂对拍 + 主会话抽 5 文件复核：exit 与事件序列不一致 **0** 条）。
- **④ 补全五条一起收（`e5b37c33` + lint 修 `618761ae`）**：新增 `crates/lsp/src/completion.rs` —— 库名来自**已解析的项目闭包**（不是硬编码课程 lib）· binder 按**光标语法位置**给（行末也给）· 候选按位置分档 + `sortText` · prelude 名带**完整签名** · `\…` 输入法候选带 `textEdit`（`\in` ⇒ `∈`）；逃生门 `SOKO_COMPLETION_CLOSURE=0`。判据：`C1`–`C5` 全 **exit 0**（`Set.*` 0 → **27** 条；行末 binder 0 → 5）· `--all` 两份 sweep 逐条比 **8/20 → 13/15**，**只有 C1–C5 转一致、零回归** · 反向 `SOKO_COMPLETION_CLOSURE=0` ⇒ `C2` 判红 ✓ · lsp **229/0** · front **948/0**。**顺带修掉 ③ 留下的 deny-by-default clippy 红**（`kernel_phase.rs` 的 `Some(&display)`，`clippy --workspace --all-targets` 此前编不过 ⇒ CI 会红）—— 教训：收尾说"clippy 无新增"必须跑**整 workspace `--all-targets`**。**做不到的一条如实登记**：parse 错时给本文件 binder 需要真相层的声明报告（`soko/project` 只答 `reason:"parse-error"`）⇒ 给出来即编造 ⇒ 改成防漂移单测、缺口归 `N2`。
- **顺带的文档纪律**：本批三条契约事实（洞位置模式 · `entry-parse-failed` · 源级内核消息）进 `docs/protocol.md` ⇒ 先把历史叙述压掉（1106 → **1102**），残差**手改** `scripts/docs-budget.json` 登记（protocol 1086→1102 · L1 6238→6254，`_comment` 写明三条内容与"`docs/ux-findings-2026-10-12.md` 到期归档后 L1 自然回落"）⇒ `docs-lint` ✓。
- **⚠ 又一次 `--no-verify` 推送（2026-10-12 16:0x，按仓库纪律在此写明原因）**：pre-push 的缺口台账 `--strict` 被 **G-81 超时**挡下（`>300s`；非 strict 的 `python3 scripts/gap.py check` **0 条不一致** ✓）。单独复跑同一条 ⇒ **66s · rc=1（满足）** ✓，且它的反向臂也如预期判红 ⇒ 判为**环境慢**（当时机器上正跑着批次收尾的 gate 与真宿主 e2e），按纪律 `--no-verify` 推并留痕于此。
- **⑤ 缓存键折进内建 prelude 摘要（`d1c92956`）**：原键只有 FNV(profile·OS·ARCH[,`SOKO_BUILD_LABEL`]) ⇒ 改了 prelude **只重建不清缓存**时旧产物继续答旧行为（本批实测咬过两次）。修法：`build_stamp()` 折进 `builtin_prelude_digest()`（三段 `include_str!` 源 + 两张名字表，`\0` 分隔防撞车）；模块产物无需第二处改动（走的就是同一个 `cache::key`）。**不 bump `CACHE_FORMAT`**（schema 与键的显式分量都没动；改了 prelude 的构建自带新键 ⇒ 旧条目必然够不着），理由写进常量注释。判据：改一行 prelude + 重建 ⇒ 同一夹具读回 **`def And.left`** ✓、还原重建 ⇒ **`theorem And.left`** ✓（stamp 回同值 = 纯函数）· 新单测 2 条（front lib **950/0**）· **`m07` 探针判据由歧义改成三侧可分辨**（旧式 exit 0 / 新式 exit 1 / 设了 label ⇒ exit 2 UNDECIDABLE —— 旧判据在那里会**假报已修** ✗）。
## 初学者体验三条（2026-10-11/12 用户报，**本轮主项**）：prelude 关键字 · **vim 输入** · 隐式实参推断（未发版）
- **用户原话三条**：①「prelude.lean 里 def 太多，完全可以换成 theorem……def 的版本对用户以及初学者非常不友好」（追问后拍板「**应该性能还会好一些**」）；②「**我 vscode 的 vim 模式在做题目的时候感觉全乱了**」；③「`Eq.subst α (fun (y : α) => y ∈ A) a x` 基本上自动推导全坏了……不知道要不要传入，不传入又会失败……**如果没有能力自动补全，那还是尽量保持显式参数**」。
- **① prelude 关键字（`b8b64918`）**：类型是 Prop 的证明类声明**一律 `theorem`（20 条）**，含 Lean 自己写 `def`/abbrev/投影的 9 条（有意偏离、语法仍合法）；`Not`/`Iff`/`Ne` 与 `Eq.ndrec`/`Eq.mp`/`Eq.mpr`/`cast` 保持 `def`。**性能理由**：`theorem` 在 def_eq 不展开。配套 `install_l1_command` 的 `Command::Theorem` 臂（漏了 ⇒ 该命令静默不装）· 镜像重生成 · 两层守卫（源级 kind 表 + 内核 `#print`）+ 两条反向验证。
- **② vim 输入（`58d83a1d`）**：真 VS Code 1.140 + vim 1.32.4 + 真 keydown 复现出**四个叠加成因** —— 替换后光标被推到自动配对 `)` 右边（每个 `\word` 后多一个 `)`）· normal 模式 `o`/`p` 把上一行补刀成 `∧` · `\` 撞 vim 的 `leader` · 即时替换让 VS Code 忘掉"这个 `)` 是自动补的"。修法：光标按净长度差钉回符号之后（对齐 Lean 4 `updateUnchangedSelections`）· 只理单字符纯插入 + 光标一致性两道守卫 · 新设置 `sokonanoda.input.leader` · `[sokonanoda]` 钉 `editor.autoClosingBrackets: "never"`。判据：新 e2e **14/14** · 无 vim 对照 **11/11** · stub 宿主 **68/68** · 真宿主台账 **50/0** · 主会话独立复跑整段证明 8 次无 `)` 错乱（修前副本对照臂红）。**残留如实登记**：连打时 vim 臂偶发丢一个 Enter（1/5，未定性）。
- **③ 隐式实参推断 + `apply` 结论校验（本轮）**：**第二候选**（同一类型的全显式 pp `@Eq α x a`，严格档先跑、失败才试）修好裸写 `Eq.symm hx` / `exact Eq.subst (Eq.symm hx) h` / `apply Eq.subst (Eq.symm hx)`；同族真 bug —— `apply` 不校验结论（写反 x/a 也"成功"）⇒ 改成「以当前目标为期望类型 elaborate + 断言结论可合一」，错误落在写错那行。判据：独立夹具 `c-probe` **9/9** · 反向 `SOKO_METAVAR=0` **6/9** · 探针 `r04`/`r05`/`r08`/`r09`/`r12` 转 exit 1 · front **48 个测试二进制 0 判负** · 用户的 `unit01` **6 checked/0 failed**（81ms）。**⚠ 性能插曲（主会话 09:5x 抓到、已修）**：第一版把第二候选**预计算**成 `arg_tys_alt` —— 每次应用的**每个实参**都先渲染+再解析全显式形态，不管主候选是否成功 ⇒ 部分课程文件慢 **140×**（`I.3/unit08-images-preimages` 397ms → **56 375ms**；113 个单元里 ≥8 个 45s 超时 ⇒ 门禁跑不完）⇒ 改成 `alt_type(slot)` **按需取用 + 同一位只算一次**，修后该文件 **131ms** · 课程门禁 **258 目标/2192 checked/912 open/0 判负 · exit 0**。**教训**：「只在失败时才走」的判据必须落在**成本产生处**，不能只在取用处。
- **④ 并行找茬（`d5c554dd` + `d1875fa4`）**：四条探针线（语言/反馈 · LSP · 真 VS Code 全流程 · vim）**63 条**缺口 ⇒ `docs/ux-findings-2026-10-12.md` + 探针入库 `scripts/ux-probes/`（路径可移植）；独立复核 **一致 48 · 误读 1（`r02`）· 已变 0**；顺带修掉**探针自己会撒谎的两个坑**（干净缓存纪律 —— 语言改了会读 M-07 旧条目假红；`r02` 从"缺口"改成**对照臂**）。
- **⚠ `--no-verify` 推送一次（2026-10-12 11:0x，按仓库纪律在此写明原因）**：`a6c5ec26`（纯重构：把全显式档并进 `infer_type_text`，消掉 `audit-notation-paths` 判红的 2 处新增绕过）被 pre-push 的**缺口台账 `--strict`** 挡下 —— 红的**不是本改动**，而是 G-07/G-44/G-81/G-83 在**本机超时**（`--strict` 把"本轮未验证"判红）：单独复跑 `G07-course-manifest-v2.sh` **4s rc=1** ✓、`G81-…root-state.sh` **67s rc=1** ✓（两条都满足）；非 strict 的 `python3 scripts/gap.py check` **exit 0** ✓（仅报"因环境慢被跳过"）。⇒ 判为**环境慢**、按纪律用 `--no-verify` 推并留痕于此 ✓。
- **⑤ 顺带修**：`scripts/soko grade --root` 以前**静默丢掉**（而 `AGENTS.md` 写着这个用法）⇒ `30030b7a` + 新用例两半（认根 / 不误伤）。
## prelude 证明类声明关键字：**类型是 Prop ⇒ 一律 `theorem`**（2026-10-11 子项 A）：20 条 · 安装器补 `Command::Theorem` 臂 · 两层守卫（未发版）
- **用户要求**：prelude 里「声明类型是 Prop 的证明类声明」从 `def` 改成 `theorem`（「def 的版本对用户以及初学者非常不友好」）；同日追问「要改到什么程度」后拍板「**应该性能还会好一些**」⇒ 取**最宽口径**（不按 Lean 原文用词）。已进 `REQUIREMENTS.md` §9.16。
- **规则**：L1 的 **20 条证明类声明全部 `theorem`** —— 含 Lean 自己写 `def`/`abbrev`/结构投影的 9 条（`False.elim` `Init/Prelude.lean:235` · `absurd` `:245` · `Not.elim` `Init/Core.lean:1625` · `And.elim` `:1628`（abbrev）· `And.left`/`And.right`（`structure And` `:555` 投影）· `Iff.intro`/`Iff.mp`/`Iff.mpr`（`structure Iff` `:185`）—— Lean 侧签名更宽（结果 `Sort u`）或自动生成的投影；本语言签名收窄到 `Prop` ⇒ 写 `theorem` 是**有意偏离**，语法仍是合法 Lean ✓）；**保持 `def` 的 7 条**（`Not`/`Iff`/`Ne` 是类型构造子；`Eq.ndrec`/`Eq.mp`/`Eq.mpr`/`cast` 结果未必 Prop）。理由：① 初学者友好；② **性能** —— `theorem` 在 def_eq 里不展开（`conv.rs::unfold_hint` 只展开 `Declar::Definition`）⇒ 越多 theorem = 越少 delta 展开 ✓。
- **配套（漏一处就静默坏）**：`prelude.rs::command_belongs_to` + `install_l1_command` 补 `Command::Theorem` 臂（不补 ⇒ 该命令不属于任何族 ⇒ **静默不装**）· 镜像 `SOKO_WRITE_PRELUDE=1 … --test prelude_mirror` 重生成（逐字节）· 哨兵行 `def Or.elim …` → `theorem Or.elim …`（留旧的 = 咬不住 ✗）· `courses/set-theory/lib/Exists.sokonanoda:95 Exists.elim` 同轮改 `theorem`（Lean 也是 theorem）。
- **守卫**：`prelude_mirror.rs::the_prelude_declaration_kinds_are_pinned` **两层** —— ① 生效源的**源级 kind 表**（27 条逐条）② 内核 `#print` 读回的**声明种类**（走真安装路；`pretty_printer::main_def` 按 `Declar` 种类出关键字）。**反向验证两条实跑**：① `Or.elim` 改回 `def` ⇒ 判红 ② 撤 `command_belongs_to` 的 Theorem 臂 ⇒ 判红（11 条 `unknown identifier`）✓。
- **判据（主会话独立复跑）**：`prelude_mirror` **8/8** · `cargo test -p sokonanoda-front` 全绿（5 个测试二进制）· `scripts/dev-verify.sh` ✓ · `scripts/soko grade playground.sokonanoda` exit 0（23 checked · 0 诊断）· 课程门禁**整门** exit 0（**258 目标 · 2192 checked · 912 open · 0 判负**，与改前逐项相同）· `docs-lint` / `status-lint` ✓。
- **判定不变**：`eval.rs::const_kind` 里 `Theorem`/`Definition` 同类（都 Unfoldable）；差别只在 `conv.rs::unfold_hint` —— theorem 与 Lean 的 thmInfo 同款，**不在 def_eq 里展开**（这也正是用户要的性能那一刀）。
- **横向审计（只读；`course/` 一行未改）**：全语料 Prop 类型的 `def` 只剩 `course/` 的 16 处（`unit2` 的 `demo_refl`/`eq_symm_demo`、`unit5` 的 `predict_then_prove`、`unit11` 的 `and_left_x`/`and_left_export` + 两份 solutions/en 镜像）—— **有意保留**：`course/unit11-modules-projects.sokonanoda` 的练习 2 原文就在教「库不只有 theorem，也有 `def`」（hint 写「声明形式是 def …」）⇒ 改成 theorem 会与课文自相矛盾 ✗；其余 250+ 条 `def` 都是谓词/类型定义（`… : Prop` / `Set α` / `Type`）⇒ 本来就该 `def`。
## 用户向命令文档 + 命令字 F12（2026-10-11 第七轮）：`reference/commands/` 四篇 · VSIX 分发 · 跳转 ✓（未发版）
- **起因三条（同日）**：①「`#print` 打印隐变量的功能实现了吗」→「没看到文档有写，我在哪里能看到文档」→「补上」（功能本来就有，缺的是**用户向**文档）②「`#print Set.singleton` 里 `Set.singleton` 不支持 F12 跳转」③「把命令文档加入 vsix，`set_option` `#print` `#check` 等等 F12 跳转到对应文档里」。 **① 文档**（本轮第一件）：`reference/commands/`（索引 + `check` / `reduce` / `print` / `set_option`，五节体例照 tactic、例子逐块喂真内核）+ 根 `README.md` 命令表一行 + 守卫 `crates/front/tests/command_docs.rs`（现 **9 条**：表↔文件双向 · parser 字面量反向 · 内嵌 == 磁盘 · 例子逐块喂真内核）。
- **② bug（台账 G-116）**：`walk.rs::print` 从不 push `CmdHover` ⇒ 那一行**零 hover 行** ⇒ F12 null（hover 那半由 `command_line_hover` 顶着，所以看不出来 ✗）⇒ 补一条与 `push_lexical_hover_rows` 逐字段同形的行；判据 LSP 单文件 + **项目模式**（库名 `Set.singleton` 形状）各一条、**断言落点行**，真 LSP 复现件 `G116-…sh` **exit 1** ✓（修前 0）；front `repeated_edits_…` 的 hovers 基线 10 → 11（那条判据看的是「不随轮次增长」）。
- **③ 命令字 F12 + VSIX**：真相表 `crates/front/src/commands.rs`（`include_str!` 内嵌 · `parser` 白名单**由表派生**）· 五档机械抽一份 `reference_docs.rs`（tactic 与命令共用）· LSP 走 `semantic_tokens` 的 `Keyword` run（**不动 `DocumentReport`**）⇒ 参数位不受影响 · 新 env 键 `SOKONANODA_COMMAND_DOCS_DIR`（旧键语义不变）· `stage-docs.js` 泛化两个目录 · `release.yml` 对 **9 个产物**逐字节查 · 真宿主 e2e **P8**（真按键打开插件那份）。**读数**：front lib **942/0** · LSP lib **225/225**（新增 4 条）· extension 接缝判据 **1/1** · `stage-docs --check` 逐目录一致（漂移时真的判红 ✓）· `notation-lint`（新纳 `reference/commands`）0 旧写法 · `gap.py check` 119 通过 / 不一致 0。**边界**：`#reduce` 的报告通道缺口是独立议题（本刀走词法）· `#env`/`#prove`/`#help` 是 REPL 命令不进表 · `set_option` 的选项名/值**有意**无落点 · CI 的 host-VSIX 冒烟仍不咬文档（与 tactic 侧同状）。

## 用户实测线（2026-10-11 第六轮）：**三条尾巴全部收口** ✓（`unfold … at h` 点假设名 · 目标显示不吞应用 · `unfold` 实参可跳）—— 原文 `git log --all -- STATUS.md` ✓
## 用户实测线（2026-10-11 第五轮）：**`rfl` 对齐 Lean 4（defeq 目标）· 新 tactic `unfold` · 失败声明的签名 F12** ✓（未发版）
- **三条用户原话**：①「`theorem mem_of_subset_singleton … := by apply h; rfl` 的 rfl 报错，这个应该是 bug」②「`(h : {a} ⊆ A)` 鼠标移动到花括号，但是 F12 没办法跳转到 `Set.singleton`」③「`apply h` 到这一步的目标是 `⊢ a ∈ ({a})`，但是我想增加一个 tactic，展开成 `⊢ a = a`，调研查查 lean4 有没有类似功能的 tactic」。
- **①（台账 G-114）**：**不是内核缺陷** —— 真内核判 `exact Eq.refl a` / `apply Eq.refl a` 都绿（`decl.checked`）；是前端 `rfl_candidate` 只认**语法上** `Eq`/`Iff` 头的目标。修法对齐 Lean 的 `MVarId.applyRfl`（`Meta/Tactic/Rfl.lean`：先 `whnfR` 目标类型）：源级多轮展开逼近 whnf（`unfold_head_deep`，与 G-109 的 `apply` 修复**同一份**机械）+ 认**内建糖的头**（`{a}` → `Set.singleton`；`ast::set_literal_target` 与 elab 共用一张表）+ 便宜的形状闸（头不是 Eq/Iff 就不花那次内核 pp）。**零假绿面**（候选仍交内核 `judge`）。**反向验证实跑**：退回 `unfold_head_once` ⇒ 判据当场判红（报的正是用户那句文案）✓。
- **②（台账 G-115）**：真因是**同一条声明正红着**（= ① 的 `rfl` 报错）⇒ **失败声明的签名跳转行被整段丢掉**（G-108 第一刀只补了**体**里的词法行）。修法：三个 lowering 失败臂把签名**再 elaborate 一遍只为收行**（`elab::elab_type_for_hovers`，不 `add_declar` ⇒ 环境不动）。真 LSP 实测（用户实际点的 `{` 字符）：修前 `null` ⇒ 修后落 `lib/Set.sokonanoda:74 = def singleton` ✓；**反向验证实跑**（撤三处调用）✓。
- **③**：新增 **`unfold Foo Bar`**（Lean 同名 tactic；对照 `Init/Tactics.lean:802` + `Lean/Meta/Tactic/Unfold.lean`：非递归 def = `deltaExpand` + beta；本仓在**源级**做同一件事，**逐处**展开 + `.visit` 链式、**内核验收后才提交**、不做 `at h`）。tactic 真相表 **14 → 15**：`tactics.rs` + `reference/tactics/unfold.md`（五节 + 内核判绿的例子）+ 索引 + `semantic::KEYWORDS` + `tactic_docs`/`tactic-docs-lint` 两条判据同轮跟上。**用户目标实测**：`apply h` → `unfold Set.mem Set.singleton` ⇒ 目标 **`a = a`** ✓（`query state` 的展示副本）。
- **发版预检逮到两处真问题**（`scripts/release-preflight.sh`，全量 gate）：① **TM 语法漏跟** —— `unfold` 进了 `semantic::KEYWORDS` 却没进 `editor/vscode/syntaxes/sokonanoda.tmLanguage.json` ⇒ `tm_grammar_keywords_follow_the_single_source` 当场判红 ✓（已补）；② **内核一条判据在并行下假红** —— `sealing_keeps_the_library_layer_out_of_the_copy_on_write` 读的是**进程级** `clone_stats` 原子计数，同二进制其它用例并行触发的克隆会污染读数（全量负载下偶发 `copies = 2`，单跑 70/70 恒绿）⇒ 改成**最多 5 趟重测**（真回归永远产不出满足条件的读数 ⇒ 守卫照样咬得住；**反向验证实跑**：撤 `seal_library_layer` ⇒ 5 趟后判红 ✓）。
- **读数**：front lib **936 passed / 0 failed**（新增 7 条：rfl 正向 + 2 反向 · unfold 4 条 · 失败声明签名行 1 条）· `tactic_docs` **6/6**（15 条基线）· 设计 `docs/design/unfold-tactic.md`（新档，已登记过期）· 台账 G-114/G-115 各带复现件（G-115 是真 LSP 探针，断言**落点行**）。

## 用户实测线（2026-10-11 第四轮）：`#print` 看得见隐式实参 + `Iff.refl` 签名对齐 Lean 4
- **起因与结论**：用户贴出 `#print demo_mem_def` 印 `… := Iff.refl`，追问「是 pp 简略还是内核被 heck」+「Lean 4 里 `Iff.refl` 也是隐变量吗」。内核**没放水**（反向验证两条都判红：非 defeq 的 `↔` 上 `by rfl` ⇒ `elab-tactic-failed`、直接写 `Iff.refl` ⇒ `kernel-rejected`，诊断「实际」逐字 `Iff (Set.mem a A) (Set.mem a A)` = 隐参被补上的样子）；真因 ① prelude 把 `Iff.refl` 写成隐式（比 Lean core 宽）+ ② 内核 pp 默认 `explicit: false`。
- **A（拍板）**：`set_option pp.explicit true` / `pp.all true`（Lean 同名、默认值也同）⇒ `#print` / `#check <表达式>` / `#reduce` 显示隐式实参；**默认逐字节不变**；只两条名字（其余给 `set-option-shape` 专用诊断，**不静默**）；`… in …` 不做。设计 `docs/design/set-option-pp.md`（92 行，预算/过期已登记）。
- **B（拍板）**：`Iff.refl (A : Prop)` 改**显式**（与 Lean core `Init/Core.lean:1022` 同形；隐式版兄弟 `Iff.rfl` 本就有），`by rfl` 与洞上灯泡的候选改用 `Iff.rfl`（= Lean 的 `exact Iff.rfl`）；课程 5 处 + 注释同步；`notation-lint` 规则翻转（`allowed 0 → 1`）；台账 **G-113** + 复现件 `G113-iff-refl-explicit.sokonanoda`（裸写现在**判红**）。
- **判据 + 顺带修 + 边界**：front **929 lib + 全部集成** ✓（`set_option_pp_*` 3 条 + parser 1 条）· LSP ✓ · CLI ✓（2 条 + help 自文档化）· `t1a_module_checkpoint_parity` ✓（**跨模块携带**：档在 `Common`、`#print` 在 `LibB`/`MainA`）· `prelude_mirror` **7/7** · `notation-lint` 0 旧写法。**顺带修**：`split_report` 的 `checks/prints[].cmd` 漏重基（`cmd` 6 vs 2）⇒ 同法重基（单文件恒等）。**边界**：档只影响命令输出（`ty_text`/hover 保持 G-71，**偏离 Lean**）· `#check <裸常量>` 走 U2 捷径 ⇒ 有意不受档影响 · 用户 `unit01` 的未提交改动**一行未动** ✓。
## `target/` 体积守卫（2026-10-11 第三轮）：**度量修正 + 进 gate + 回收入口** ✓ —— 用户：「浪费我太多 ssd，好麻烦」
- **读数/修法/判据**：`target/` **142 GiB → 1.7 GiB** · 度量口径高报 60%（不认硬链接）已修 · `--selftest` **16/16** + 真硬链接夹具 · **原文 ⇒ `git log --all -- STATUS.md`** ✓
## 发版线（2026-10-11 第二轮）：**`v0.88.2`** —— 版本切换 ⇒ 自动全量预热（**patch**：无新协议、无新能力，是「已有缓存策略在版本切换时换档」）
- **落点与纪律**：`server.js` 只读探针 `projectArtifactsWrittenByOtherVersion`（判据 = **条目文件名** `<编译器>+<构建戳>+<键>.json`，**不是** `meta.json.compiler` —— 它会被任何一次写入刷成当前版本，是 G-106 修掉的那个谎）；`extension.js` 的 `loadProject()` 尾部 `void autoRebuildOnVersionChange(answer)` + `serverCompilerVersion()` + `autoRebuiltRoots`。四条纪律：① **只看版本、不看构建戳**（同版本换构建 = G-112 ⇒ 不触发）；② **CLI 对齐闸**（CLI 与 LSP 版本不一致时预热写了也白写 ⇒ 每次开档都全量预热 ✗ ⇒ 先比 `--version`，不一致就不动手，交给 `doctor`）；③ **每根每会话只自动跑一次**（否则诊断事件会再触发 ⇒ 死循环级事故）；④ **不阻塞、不弹窗**（后台活，进度进 `sokonanoda build` 通道）。
- **判据与代价**：`test-server.js` **20/20**（含「同版本不同戳不算」）· `test-extension-host.js` **63/63**（旧版本⇒起 `rebuild --json <模块根>` / 当前⇒一次不起 / 每根一次 / **CLI skew⇒不起**）· `test-webview.js` **35/35** · `cargo test -p sokonanoda-cli --test extension` **41/41** · `gate --fast` exit 0 · `gap.py check` **118 通过 · 不一致 0**；**反向验证 2 条实跑**（撤检测 ⇒ server 判红 ✓ · 撤对齐闸 ⇒ 宿主判红 ✓）。**代价**：release、251 文件 ⇒ 一次全量预热 **22.3 秒**（`compiled 248 · failed 2 · hit 1`；那 2 个 failed 是 `gaps/` 的负例）。设计档 `docs/design/version-switch-rebuild.md`。
## 发版线（2026-10-10 第三轮）：**`v0.88.0`** —— tactic 文档体系收口（**minor**：悬停摘要 + F12 + 14 篇随插件分发；批次 P1–P7 · 打包/漂移/全量/真 e2e 四组判据 · 首轮 gate 逮到「自带 CLI 版本漂」的真发版 bug）⇒ 设计 `docs/design/tactic-docs.md` + `docs/visible-changes.md`；原文 ⇒ `git log --all -- STATUS.md` ✓
## tactic 文档体系（2026-10-10 · P1–P7 七段，**已发版** ⇒ `v0.88.0`，见上节）：单一真相表 `crates/front/src/tactics.rs`（白名单派生 · 四层防漏项门禁）+ 14 篇正文 + F12 五档落点 + 如实边界（`exact?`/`intros` 本语言没有 ⇒ 不进基线）⇒ 设计 §5；原文 ⇒ `git log --all -- STATUS.md` ✓
## 编辑器收口第 3 轮（2026-10-10）：**四条用户实测一次收口** ✓ —— 结论与边界（回放重复在入口侧收口 · 产物写者进条目名 · hover 唯一渲染点 · `.decl-name` 改粗体，以及 G-102…G-105 / G-108 / G-109 与两条「如实记」）⇒ `docs/visible-changes.md` 第 3 轮 + 台账；原文 ⇒ `git log --all -- STATUS.md` ✓

## hover 收口 + 命令输出不重复（2026-10-10 第 2 轮）：**五条用户实测一次收口** ✓ —— 根因五条 / 修法 / 判据（`REPORT_SHAPE` 4 → 5 · 命令行 hover 走真相层 `messages_at` · 内核 `leq_core` 补 `MVar` 臂）与两条边界 ⇒ `docs/visible-changes.md` + 台账 G-102…G-105；原文 ⇒ `git log --all -- STATUS.md` ✓

## 发版线（2026-10-10 第二轮）：**`v0.87.3`** —— 五条编辑器反馈收口（**patch**：无新协议、无新能力；批次 6 笔 + 预检在干净检出上逮到 3 处漏跟的旧期望 + e2e 台账 · 台账 `gap.py check` 111 通过/0 不一致 · `release-preflight.sh --sweep` exit 0 · 判定面红线对拍 · `bump.py 0.87.3` 写全 4 处 · 真宿主 e2e 45/45 `dirty:false` · 从干净 worktree 推 `bc831ecf..cc97e51c` ⇒ CI 27 成功）⇒ 原文 `git log --all -- STATUS.md` ✓
## 发版线（2026-10-10）：**`v0.87.2`** —— 四条编辑器反馈收口（**patch**：无新协议、无新能力；`Iff.rfl` 是 `Iff.refl` 的**别名** ⇒ 没多出能力 · `bump.py 0.87.2` 写全 4 处 + `CHANGELOG` 的 `[Unreleased]` 收口成 `[0.87.2] — 2026-10-10` · `release-preflight.sh` exit 0 · 推送 `a4d4ffa9..6b29679f`（本地快层 16/16 全绿、未走逃生门）⇒ CI `37982604553` 27 成功）⇒ 原文 `git log --all -- STATUS.md` ✓
## 编辑器反馈线（2026-10-10）：**四条用户实测反馈收口 + 顺带两条** ✓（已发版 ⇒ `v0.87.2`，见上节）—— 每条都走「一个 subagent 实现 + 主会话独立复跑判据 + 反向验证实跑」；**①** prelude 的 `Classical.byContradiction` 漏了 `Or.elim` 式收口（`7c547a62`）· ②③④ 见 `docs/visible-changes.md`；**顺带两条**（同类横向排查的产物）：hover 不再报**旧签名**（原 `judge_type_of_constant` 是进程级名字键缓存、无失效路径 ⇒ 改走前缀键 + 真判定）· `d9a1c3d4` 的另一条同类）⇒ 原文 `git log --all -- STATUS.md` ✓
## 更早轮次（2026-10-09：`v0.87.1` 三条实测收口 · `#check` 重复输出批次 · 命令输出记法/高亮 · Infoview 四条 · `v0.87.0`；更早：第 4/5 棒 + 第 2/3 棒 + 第 122–136 棒 + L-04 + G-55 + 发版 · 2026-10-05/06/07/08）：**已按「只留最近 3 轮」压缩成结论 + 指针** ✓ —— 原文 ⇒ `git log --all -- STATUS.md` ✓
- **127 / 125 / 122 / 第 4–6 棒（G-81 · G-87 · G-30 元变量 · G-29 · `v0.84.0` 五条）**：各自收口或按「判定中性 ✓ · 判据未达 ✗」如实记账；**原文 ⇒ `git log --all -- STATUS.md`** ✓

## 清台账第 4 轮（2026-10-13）：**引擎第 5 刀落地** + 队列 32 → 2（未发版）
- **队列：0 条**（blocker 0 · 高 0）· 起点 32 条 · 已收口 **32 条** ✓ · 悬空文档引用 **445 → 0** ✓
- ⭐ **引擎第 5 刀**（`6266bede` + `cb79b1ac`）：新增 `const_arg_expected` 第四档（**注册表签名 + telescope + 位置代换**，与 `Lean/Elab/App.lean:1113` 的 `instantiate1 arg` **同构**；**零内核调用、非递归**）⇒ **解锁 59 处课程自然写法**（34 文件）· **2190 checked 不掉** ✓ · **零回归**（30 处仍红站点基线复判 ⇒ 回归 0）✓ · **语料 251/251 逐字节相同** ✓ · 反向门 8/8 咬 ✓
- 前序引擎修：`25e02d8c`（de Bruijn 差一收口）· 四处过期妥协 · 第 4 刀（`ecba7433`）· `b714e16b`（T-D31 词法器列 UTF-16）· `d12f20a8`（W-5 第二半：撤 prelude 安装期比对排除）✓
- 课程侧：**119 → 54 行**（+189 处转隐式，`check.py` 计数逐字不变 ✓）；旧妥协订正文档 **16 处** + 受理代码 **4 处** ✓
- ⚠ **premise 被实测证伪 7 条**（含我自己写错的 2 条 ✗）· **环境坑 12 条**（全部回写进后续开工单 ✓）· **判据当场纠正我的操作 7 次** ✓
- ⚠ **文档预算**：按用户 2026-10-13 21:57 口径 ⇒ **归档旧的腾空间**（`STATUS.md` 19 个旧轮 + `ROADMAP.md` 三节纯历史 ⇒ 归档）✓，**没有抬任何上限** ✓



## 编排进程的**结构性排查**（2026-10-15 · `SUB-orchestrator-attention-structure`，未发版）
- ⭐ **用户硬读数逐条复核（他自己量的，逐条给"对/差多少"）**：① 提交分类 **246 笔**（fix 111 · chore 59 · perf 32 · docs 20 · feat 11 · test 7 · release 3 · refactor 1）**逐格全对** ✓（边界 = 排掉 `139db9a1`，它是 10-14 00:00:21 的 `perf(e2e)`；**但 8 类之和 = 244 ≠ 246** ⇒ 漏登 `ci:` ×1 与 `course:` ×1 ✗）；**队列/CI/基建 137/246 = 56%** ✓（分子 **137 逐格对上**，正则须**大小写敏感**；大小写不敏感会数成 147 ✗）② **行数分区逐桶复算，差 0 行** ✓：生成物/台账 **76,280** · 工具 **13,690** · 产品 **4,572** · 其它文档 **3,942**（合计 98,484 = 我的复算值 ✓）；**比值 76,280 / 4,572 = 16.68 ≈ 17** ✓（口径：`docs/gaps/ledger.jsonl` 算 gen、`scripts/ux-queue.py` 算**工具**）③ **前 4 个最频繁文件 91 / 58 / 56 / 54 = 259 次** ✓ 逐格对（对照 `server.js` 4 ✓ · `ci.yml` 5 ✓）④ 自报复核轮次**到第十六次** ✓（`第七次复核` 标题出现 59 次）⑤ **同形洞四次** ✓ —— `ci.yml:416` 自己写着「**第三次**同形洞 ✗，前两次是 `scripts/**` 与 `.github/workflows/**`」+ `ci.yml:148` 的「同族第四次」⑥ 台账 **126 条 · 41 条 blocker** ✓ 逐格对；标题命中"守卫/判据/静默/假绿/假红/漂移/漏" = **14**（用户写 15 ⇒ **差 1**，口径 = 只搜 `title`）
- ⭐ **本条最刺眼的那一半（用户没量）**：76,280 行里 **74,705 行 = 97.9% 是 `docs/e2e/logs/**`**；它**已经在最小集**（52 份文件 ↔ 52 条活台账引用，**孤儿 0** ✓）⇒ **不是"可删的生成物"**；⚠ `docs/e2e/**` 本轮**不可写**（且 `e2e-merge.py --check` 校验存在 ⇒ 移出 git 就是死指针 ✗）⇒ **如实说：落不了"减少生成物进 git"，落的是"给簿记设预算并判红"** ✓
- ⭐⭐ **落地的两条新守卫（都进 CI `queue-lint`（不设 `if:` ⇒ 每推必跑）+ `scripts/ci-local.sh`）**：
  · **`scripts/check-queue-views.py`**（破【1】"自造工具·自用·自判"的闭环）：**第二份实现**（自己折原始事件流，**不 import** `ux-queue.py` —— `C6` 扫自己的源码自证）+ **纯 git 事实**（`merge-base --is-ancestor`）⇒ 工具自报的结论只是**被告**。六条判据 C1–C6，含 **C4 必须折过 `repoint` 的最终指针**（拿原始 sha 判 ⇒ 实测 **100+ 条假红** ✗⇒折完 **0 条** ✓）
  · **`scripts/check-attention-budget.py`**（落【5】/【5'】+ 17:1）：**两档**（照 `target-hygiene.py` 先例）告警 **17:1 / 57%**（只出声 ✓）· 红线 **19:1 / 60%**（判红 ✗）；窗口**固定锚点 → HEAD**（**不用滑窗** —— 滑窗会因"大产品提交老化出窗"造假红 ✗）
- ⭐ **改前/改后 + 反向验证**：改前**没有这两条判据**（`grep -c check-queue-views scripts/ .github/` = 0）⇒ 改后：C1 注入 `advnace` ⇒ 红 ✓ · C2 注入一条工具看不见的事件 ⇒ 红 ✓ · C4 注入 `HEAD` 之外的 sha（`ef651ef7`）⇒ 红 ✓ · C5 注入一条证据只指 `.cache/` 的收口 ⇒ **177 → 178 > 上限** ⇒ 红 ✓ · B1 把窗口关在 `c82097fe`（**53,595 行的 e2e 提交**）后 ⇒ **19.32 : 1 > 17** ⇒ 红 ✓；**全部跑完还原**（`grep -rc "OA-Y-RV"` = **0** ✓ · 真台账 md5 **改前 = 改后** ✓）
- ⭐ **新读数（守卫自己量的）**：收口证据可独立复算 **20/199** ⇒ **不可复算 179/199 = 90%**（其中 **34** 条只引 `.cache/**`；**近 33 条新收口里 27 条**引它 ⇒ **这个做法在扩散** ✗）· 簿记预算 **16.98 : 1** ✓ 在限内 · 簿记提交 **143/255 = 56.1%** ✓ 在限内 · `--recent 50` **72.97 : 1**（只报不判 ✓）
- ⚠ **`crates/kernel/**` 一字节未动** ✓ · `docs-lint` 0 ✓ · `status-lint` 0 ✓ · `ux-queue --check/--selftest` 0 ✓ · `ci-yml-lint` 0 ✓（新步骤名字里的 ` : ` 必须加引号 —— 裸标量会被 YAML 当**第二层映射**，实测 `ci.yml:292:27` 判红 ✓）
- **边界（如实）**：另五条原因【3】横向排查 /【4】判据绑用户可见结果 /【6】垃圾回收 /【7】端到端目标 —— **只落纪律，没落机械守卫**（理由逐条写在 `.cache/ux/fix-oaY/VERDICT.md`）；`docs/e2e/**` 与 `.cache/**` 不可写 ⇒ "减少生成物进 git" 未落地

## `SUB-parse-error-kills-whole-file`（2026-10-15 · 用户亲报）：**一处语法错不再废掉整份文件**（未发版）
- ⭐ **用户原话**：在 `unit01-sets-membership.sokonanoda` 里删掉 `apply Eq.subst (Eq.symm hx) h` ⇒ **整个文件都报错**，Infoview 报「目标/声明：文件没解析成功」；而"后面接着的内容很明显可以正常解析"（`theorem` 关键字 + 它前面的注释）
- ⭐ **两条提交不是同一根因**（读了两条原文后判）：`SUB-eqsubst-clue-order-clash` 是**隐式实参求解顺序**（`elab-implicit-argument-unsolved`，本轮仍在：`counts` 3/4、诊断照发 ✓）；本条是**解析器的参数表边界** + **闭包丢掉全部命令**。同一条用户代码、两个独立根因 ⇒ 本条只修后者
- ⭐ **复现（真课程单元，只改练习 4）**：改前 `counts = {decl_checked:0, exercise_open:0}` + 一条 `entry-parse-failed` @ line 82 col 30（`(`）✗ ⇒ **改后** `{decl_checked:3, exercise_open:5}` **与好文件逐字段相同**、0 诊断、rc=0 ✓
- ⭐ **"文件没解析成功"从哪来**：`crates/front/src/project/graph.rs` 入口 `parse_with_inherited` 失败 ⇒ 旧代码塞 `FolFile { commands: Vec::new() }` + `failed=true` ⇒ `Closure::compilable()` 不含它 ⇒ 不编译 ⇒ `counts` 全 0、只剩入口级诊断（Infoview 的「目标/声明」读的就是这份报告）
- ⭐ **为什么一处错废掉整份**（根因两处，都给 `文件:行`）：① `crates/front/src/parser.rs` 的 `intro` / `unfold … at` 名字串**跨行吃名字**（下一行顶格的 `theorem` 不是 tactic 关键字 ⇒ 被吃成 binder ⇒ 在 `(` 上报命令级 parse 错）；② `graph.rs` 的入口 parse 失败**丢掉全部命令**（恢复式解析早就有，只是这条路没用）
- ⭐ **Lean 4 对照**：`Init/Tactics.lean:50` `"intro" … (ppSpace colGt term:max)*` · `:802` `"unfold" (ppSpace colGt ident)+` · `Elab/Tactic/Location.lean:28` `locationHyp := (ppSpace colGt …)+` · `Parser/Basic.lean:1512` `colGt` = 列**严格更大**（文档自己写着"保证下一条 tactic 不被当实参"）· `Parser/Module.lean:137` `parseCommand` = **逐条命令 + 恢复**（`recovering := true`、至少前进一个 token、继续下一条）⇒ 两处都按 Lean 对齐
- ⭐ **改前/改后 + 正对照 + 反向验证**：反向验证 = 还原五处（四个 `at_or_left_of` 调用 + 恢复分支）⇒ 用户文件 `counts` 全 0 ✗、`min1` 报 `unexpected-token` ✗、真语法错条目 `counts` 全 0 ✗，且**3 条新判据全红**（994 passed · 3 failed）✓、跑完还原（`grep` = 0 ✓）。正对照（真有语法错 `def broken : Nat := )`）⇒ 改后 `{3,5}` + `entry-parse-failed`（真位置 line 78）+ **rc=1** ⇒ **错没被吞** ✓
- **判据**：front `crates/front/src/tests/parser_boundary.rs` **2 条**（`intro` / `unfold … at` 两处出口）· `crates/front/src/project/tests.rs` **1 条**（坏块**之前与之后**都照常判定 + 出错那条不判定 + 仍判红）· 拆模块（`docs-lint` ⑨：`parser.rs` 6838→**6788**、`graph.rs` 570→**545**，新增代码进 `src/tests/parser_boundary.rs` 与 `project/graph/recovery.rs`）· `cargo test -p sokonanoda-front --lib` **997 passed · 0 failed · 0 ignored**（基线 994 + 3 ✓）· `cargo test --workspace --locked` **114 个二进制全 ok** ✓ · `crates/kernel/**` **一字节未动** ✓
- ⚠ **改的是"诊断/恢复"面，不是判定路径**：`parser.rs`（`grep -c at_or_left_of` = 5）+ `project/graph.rs` + 新 `project/graph/recovery.rs`；**解析失败的文件**的 `--json` 事件流**变了**（`counts` 0 → 非 0 + 恢复出的 `decl.checked`）—— 这正是本洞要修的那一面；**解析成功的文件逐字节不变** ✓
- ⚠ **边界（如实）**：① `parse_by_block` 在**未知 tactic**（`exactt h`）上**静默收块** ⇒ 恢复出的 `theorem … := by` 被判 `exercise_open`（**与单文件通道逐字段一致** ✓，既有行为、不是本条引入；Lean 那里报 "unknown tactic" 并丢整条命令 —— 另一处偏离，未修）② **只对入口**：依赖模块 parse 失败仍 `import-module-invalid` + 阻断 ③ `intro`/`unfold` 的**实参表达式**（`apply f` 跨行）仍可能吞下一条命令（`parse_expr` 的地界，未动）
- ⚠ **同步面**：`docs/protocol.md` 的 `entry-parse-failed` 一条**已改**（+1 行，恰在 1102 上限内）✓；`docs/visible-changes.md` **未写** —— 它 90/92 行、只余 2 行而一节要 4 行 ⇒ 如实记在这里；`editor/**` 在本轮**不可写范围**内 ⇒ CHANGELOG 未写（扩展本身零改动）；`skills/**` 与 `AGENTS.md` **零改动**（命令/工作流没变；AGENTS.md 435/435 行、**无余量**）

## M1 单元⑮ 整数序的良定义性（2026-11-09 · issue #17 / PR #24）
- `unit15-leRep-wd`：`intRel_to_eq`（假设位不自动展开 `intRel`，先 `Eq.subst` 取等式）· `intRel_symm` · `leRep_wd_fst` / `leRep_wd_snd`（同加见证数 → `add_rotate` 搬运 → `leNat_add_cancel_right` 消去）· `leRep_wd` · `leRep_wd_iff`；画布 23 checked / 5 open，解答 28 checked / 0 open.
- 判据：课程门禁 **41 目标 · 623 checked · 79 open · 0 判负**（0.98.4 修复构建，`--bin /tmp/soko-kernel/target/debug/sokonanoda`，两组 `--only` 实测 51 checked / 5 open）；`notation-lint` 绿.
- 边界：`leRep_wd_iff` 是 `Quot.lift` 所需的良定义性；整数序公理（全序/加法单调）与 ℚ 构造仍差 3 单元.
## M1 单元⑳ ℚ 的商载体与相等关系（2026-11-09 · issue #17 / PR #24）
- `unit20-rat-quotient`：`ratRep := (ℕ×ℕ 的整数代表元) × ℕ`（分母 = `Nat.succ n`，永不为 0）· `ratRel` 交叉相乘 `a·(n+1) = c·(m+1)`（仍停在代表元层，避免 `funext`，issue #28）· `Rat := Quot ratRel` · `ratOf`；练习 = `intRel_refl` · `ratRel_refl` · `ratRel_symm` · `rat_sound`。画布 13 checked / 4 open，解答 17 checked / 0 open.
- 判据：课程门禁 **51 目标 · 810 checked · 98 open · 0 判负**（0.98.4 仓库构建 `target/debug`；单卡 20 → 30 秒级）；`notation-lint` / `docs-lint` 绿.
- 边界：传递性（交叉相乘后消去正因子）留给单元㉑；M1 = **19/28**（II.1 19/19 · II.2 1/9），M1 未完成。二元运算仍停在代表元层（#28）.

## M2 44/44 收口：ℚ 性质 + Cauchy + ℝ + 完备性（2026-11-12 · issue #18 / PR #32）
- 44 单元全部落盘（II.3 ㉙–㉞ · II.4 ㉟–㊹ · II.5 ㊺–54 · II.6 55–68 · II.7 69–72），每个画布 ≥2 题、解答 0 open；M1+M2 共 72 单元，`course.json` 编号 1–72 无缺号。判据：`check.py` **rc=0** —— **176 目标 · 2313 checked · 343 open · 0 判负**；`notation-lint --root courses/analysis` **rc=0**（184 文件 = 181 `.sokonanoda` + 3 `.md`，0 命中，15 处显式豁免）。
- 边界（不静默）：68 只做**代表元层** Cauchy 完备性（有理 Cauchy 序列收敛到自己的类）；一般 LUB 需 `Classical.choice` / Dedekind 切割，L2 没有 ⇒ 72 只证具体集合 `{x | x ≤ 0}` 有 LUB，差额记在 #18；不把 ℝ 立公理、不加课程 axiom（`axiom` 只出现在 C0 探针）。
- 章配额偏差随 #18 报告：II.3 6/10 · II.4 10/10 · II.5 10/10 · II.6 14/9 · II.7 4/5 = 44；练习配额差额只由 `check.py` 报告、不判红。

## M3 单元93–94：上极限与下极限（2026-11-13 · issue #19 / PR #41）
- `lib/Limsup`：`Limsup`（极限点集合的上确界）、`limsup_upper`、`limsup_least`、`limsup_le_iff`、`limsup_unique`、`limsup_of_converges`、`limsup_unique_of_converges`、`limsup_const`；`lib/Liminf`：`Liminf`、`liminf_lower`、`liminf_greatest`、`le_liminf_iff`、`liminf_unique`、`liminf_of_converges`、`liminf_unique_of_converges`、`liminf_const`、`liminf_le_limsup`；`lib/Demo` 补两个 import 与两条自检。
- `unit93-limsup`：5 道练习；正文 3 checked / 5 open / 0 rejected，解答 8 checked / 0 open。
- `unit94-liminf`：6 道练习；正文 3 checked / 6 open / 0 rejected，解答 9 checked / 0 open。
- 判据：`check.py --json` rc=0（233 目标 · 2641 checked · 479 open · 0 判负，M3 22/51）；`notation-lint` rc=0（241 文件，15 处豁免）；III.3 文案门禁 0 处；`style-lint --selftest` rc=0；`docs-lint` rc=0。
- 边界：两个界定成关系不是函数，任意序列的存在性未证（要选择公理或 Dedekind 切割）；`liminf_le_limsup` 带非空前提。不新增公理、不碰 kernel/front。下一单元：子序列与上下极限（取子序列不升上极限、不降下极限）。

## M3 单元95–96：子序列与上下极限、常数界（2026-11-13 · issue #19 / PR #41）
- `lib/SubseqLimit`：`subseqSeq`、`subseq_limitPoint`、`limsup_subseq_le`、`liminf_le_subseq`、两条收敛情形、`demo_subseq_const`；`lib/LimsupBound`：`BoundedAbove`/`BoundedBelow`、两条逐项界、两条终究界、`limsup_const_rel`、`demo_both_bounds`；`lib/Demo` 补 import 与三条自检。
- `unit95`：5 道练习；正文 2 checked / 5 open，解答 7 checked / 0 open。`unit96`：5 道练习；正文 3 checked / 5 open，解答 8 checked / 0 open。
- 判据：`check.py --json` rc=0（239 目标 · 2682 checked · 489 open · 0 判负，M3 24/51）；`notation-lint` rc=0（247 文件）；III.3 与新增 lib 文案门禁 0 处。
- 边界：子序列的界只有单向比较；常数界是充分条件。下一单元：尾部改动与上下极限。

## M3 单元97–99：上下极限的收敛与 Cauchy 极限点（2026-11-13 · issue #19 / PR #41）
- `unit97`（上轮落盘）：尾部等价沿子序列复合，并搬运极限点与上下极限（`limitPoint_congr_tail` / `limsup_congr_tail` / `liminf_congr_tail`）。正文 1 checked / 6 open，解答 7 checked / 0 open。
- `unit98-limsup-converges`：6 道练习。收敛时上下极限等价、空隙排除收敛、极限点落在两界之间；有极限点时两界相等（`limsup_liminf_rel_of_le`）。正文 0 checked / 6 open / 0 rejected，解答 6 checked / 0 open。
- `unit99-cauchy-limit`：5 道练习。Cauchy 序列有极限点就收敛到它（`cauchy_limitPoint_converges`），极限点至多一个等价类，上下极限落在同一点。正文 0 checked / 5 open / 0 rejected，解答 5 checked / 0 open。
- 判据：`check.py --json` rc=0（246 目标 · 2714 checked · 506 open · 0 判负，M3 27/51）；`notation-lint` rc=0（254 文件，15 处豁免）；III.3 文案门禁 0 处；`style-lint --selftest` rc=0。
- 边界：98 不反推收敛（要可数选择）；99.0 保留极限点前提。不新增公理、不碰 kernel/front。下一单元：III.4。

## M3 单元100–101：Cauchy 尾部刻画与有界性（2026-11-13 · issue #19 / PR #41）
- `unit100-cauchy-tail`：6 道练习。Cauchy 性等价于「尾巴上的项都靠近 x N」（`cauchy_tail` / `cauchy_of_tail` / `cauchy_tail_iff`）；平移保持 Cauchy（`cauchy_shift`），终究为常数 ⇒ Cauchy（`cauchy_of_eventually_const`），常序列实例。正文 0 checked / 6 open / 0 rejected，解答 6 checked / 0 open。
- `unit101-cauchy-bounded`：5 道练习。Cauchy 序列尾部有界（`cauchy_eventually_bounded`）⇒ 整条有界（`cauchy_bounded`）；平移与加常数保持有界（`cauchy_bounded_shift` / `bounded_add_const`）。正文 0 checked / 5 open / 0 rejected，解答 5 checked / 0 open。
- `lib/Bounded`（77 的机器，14 checked）、`lib/CauchyTail`（100 的六条，6 checked）、`lib/Demo` 补 import 与两条自检（14 checked）。
- 判据：`check.py --json` rc=0（252 目标 · 2749 checked · 517 open · 0 rejected，M3 29/51）；`notation-lint` rc=0（260 文件，15 处豁免）；III.4 与新增 lib 文案门禁 0 处；`style-lint --selftest` rc=0。
- 边界：只证 Cauchy ⇒ 有界，不反推；有界序列未必 Cauchy。不新增公理、不碰 kernel/front。下一单元：III.4 单元102。
