# STATUS.md 移出的轮次（原文逐字）

## 第 508 轮（2026-09-30）：**§3.C「前缀环境」落地 —— 全课程 `build` 2.65×**
- **先勘后动**（开工单 §3.C 明写要求）：让勘的**两条路都够不着**那 791 趟
  （候选① per-前缀 builder 池 = §17 的 B″ 同死因：arena 生命周期；候选② judge 收调用方
  builder = 借用可行但**前缀位置不同**）；**我据此推断的第三处（提升 arena 作用域）
  也被逐趟明细推翻** ✗ ⇒ 真刀口是「**judge 每次都从源码重编整个前缀**」。
- **真数字**（`SOKO_JUDGE_STATS=2`）：`by` 路径 **265 趟 = 115.9s = `judge_ms` 的 99%**，
  而 `judge_infer` 的 71126 次只 38.5s（P1-b 已吃干净）；那 265 趟 **key 全不重复 ⇒ 加缓存没用** ✗。
- **刀口**：把既有的 `TRUSTED_PREFIX` **接到主编译 pass**（`walk.rs` 每检查完一条命令压栈担保）。
  ⚠ **关键一行 `before.min(prefix_commands)`** —— 两个坐标系不同（AST 序号**含 `import`**，
  judge 前缀文本走 `importless_source`）⇒ 不夹会**多担保合成声明** ⇒ 判定声明没被检查
  （`--json` **38 行不同**，与 P1-b 第一次失败同签名）✗。
- **读数**：墙钟 **126.4s → 47.8s（2.65×）** · `judge_ms` 113,659 → **19,223（−83%）** ·
  `pass_total_ms` 276,407 → **92,058** · `by_calls` 不变 ✓。
- **证据链**：影子档（**判据级**，两条路都跑）`shadow_same=265 · diff=0` · `--json`
  **0 行不同** · 反向判据（去掉夹紧 ⇒ 判红）· 带开关跑完整 `gate` PASS · `grade` 错误路径同诊断 ✓。
  ⚠ 影子档第一版比**整份报告** ⇒ 265/265 **假分叉**（差的是报告**范围**不是**判定**）✗ ⇒ 改比**判据**。
- **默认开**（收益成立才开）；逃生门 `SOKO_JUDGE_ENV_VOUCH=0` / `SOKO_JUDGE_ENV_REUSE=0`。
- 🚀 **`v0.78.3` 已发布并闭环** ✓：CI `36655613663` **28 success / 0 failure**（1 skipped）·
  tag `v0.78.3` → release workflow `36656518982` success · `gh release list` **Latest** ·
  26 个资产（8 CLI + 8 LSP + 9 VSIX + 1 源码）✓。
  ⚠ **CI 侧也看得到提速**：`gates-course` **12m26s → 6m38s**（同一 job、同一 runner 家族）✓。
