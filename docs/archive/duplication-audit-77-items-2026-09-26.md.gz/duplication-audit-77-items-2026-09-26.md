## 3. **T-U10 收口：77 处绕过的逐条处置**（用户 2026-09-25 要求 ✓，见 `REQUIREMENTS.md` §9 ㉟）

**硬规则（用户原话）**：**凡产出用户可见文本的（LSP / hover / 诊断消息 / 状态栏 / 项目树）
必须走 ① 或 ②** ✓（① 迁移到唯一接口 / ② 补"必须折叠"的判据 ✓）；**不许拿 ③ 糊过去** ✗。

### §3 的分组表**已按当前基线（89）刷新** ✓（2026-09-25 round 111 ✓）
> **口径**：以 `scripts/notation-paths-baseline.txt` 的**当前 89 条**为准 ✓
> （用户 2026-09-25 要求 ✓）。与下面那张**旧 77 表**的差别有**两处原因** ✓：
> ① 守卫修准（`(?<![\w:.])` ⇒ `(?<!\w)` ✓）**多抓 15 处** ✗（旧数是**低估** ✓）；
> ② `round 106` 迁掉 `kernel_phase.rs` 3 处 ✓（-3 ✓）⇒ 77 + 15 − 3 = **89** ✓。

| 组 | 处数（**89 版** ✓） | 位置 | 产出什么 | 处置 |
|---|---|---|---|---|
| **A** | **5** | `crates/lsp/src/lib.rs`（全在 `half_expression_goals_hover` :1332-1376 ✓） | **hover 文本** ✗ | **① 优先** ✓（需报告结构小扩展 ⇒ 见下 ✓） |
| **B** | **20** | `crates/front/src/compile/elab.rs` | 诊断消息（**只有 4 处是给人看的** ✓，其余 17 处是判卷/解析输入 ✗） | **① 4 处** ✓ / **③ 17 处** ✓（§3 的 B 组逐条表 ✓） |
| **C** | **22** | `crates/front/src/by.rs` | tactic 候选/错误文本（混判定输入 ✗） | 逐条判 ⏳ |
| **D** | **17** | `crates/front/src/compile/goals.rs` | 目标/候选文本（混判定输入 ✗） | 逐条判 ⏳ |
| **E** | **8** | `crates/front/src/compile/check/walk.rs`（**守卫修准后从 1 → 8** ✗） | 目标生产（**喂 judge** ✗） | **③ 不做** ✓（折它 = `suggest::*` 判红 ✓，见 §9 ㉜ ✓） |
| **F** | **6** | `crates/front/src/semantic.rs`（`tag_runs_with_notations` ✓） | 分段标签 | **②** ✓（接缝守卫已钉 ✓） |
| **G** | **3** | `crates/front/src/compile/prelude.rs`（**守卫修准后新可见** ✗） | prelude 的类型文本 | 逐条判 ⏳（多为**内建声明**的源级文本 ✓） |
| **H** | **2 + 1** | `crates/front/src/compile/check/mod.rs`（`render_expr`×2 + **`print_back`×1** ✓） | 显示副本生产（**这类正是"该迁移"的** ✓） | **①** ✓（`print_back` 那处与 `kernel_phase` 同款 ✓） |
| **I** | **3** | `crates/front/src/compile/tests.rs` | **测试期望串** | **③ 不做** ✓ |
| **J** | **1** | `crates/front/src/judge.rs` | **判定量** | **③ 不做** ✓（内核红线 ✓） |
| **K** | **1 + 1** | `crates/front/src/suggest.rs`(1) · `crates/front/src/query/mod.rs`(1，`tag_runs` ✓) | 候选文本 / wire runs | 逐条判 ⏳ / **②** ✓ |
| — | **0** ✅ | ~~`kernel_phase.rs`~~ | ~~`ty_text`/`val_text`~~ | **✅ round 106 已迁** ✓（基线 -3 ✓） |

**下一步顺序**（round 107 定 ✓）：**H 组的 `print_back` 那处**与 **B 组 4 处消息**最容易 ✓
（都在 front 内部 ✓）；**A 组**需要先做报告结构扩展 ✓。

---

**历史（旧 77 版，保留对照 ✓）**：**基线全貌**（`scripts/notation-paths-baseline.txt`，共 **77** 处 ✓，按 文件×调用 归组 ✓）：

| 组 | 处数 | 位置 | 产出什么 | 处置 | 理由 |
|---|---|---|---|---|---|
| **A** | **5** | `crates/lsp/src/lib.rs`（全在 `half_expression_goals_hover` ✓ :1332-1376 ✓） | **hover 文本** ✗ | **① 优先** ✓ | **用户可见** ⇒ 硬规则强制 ①/② ✓。5 处逐条见下表 ✓ |
| **B** | **19** | `crates/front/src/compile/elab.rs` | **诊断消息**片段 ✓（含拼消息 ✗） | **① 优先** ✓ | **用户可见**（诊断会显示给学习者 ✓）⇒ 硬规则 ✓ |
| **C** | **17** | `crates/front/src/compile/goals.rs` | **开放练习的候选/目标文本** ✓ | 逐条判 ✗ | 有些是**判卷输入** ✗（红线 ✓：不许折 ✓）⇒ 只迁**显示副本** ✓ |
| **D** | **22** | `crates/front/src/by.rs` | tactic 引擎的**候选/错误文本** ✓ | 逐条判 ✗ | 同上：判定量不许折 ✗；显示量走显示副本 ✓ |
| **E** | **6** | `crates/front/src/semantic.rs`（`tag_runs_with_notations` ✗） | **分段标签** ✓ | **②**（已有 ✓） | 它靠 `runs` 那层 ✓：接缝守卫已钉"`runs` 拼接 == `text`" ✓；**再补**"输入必须已折过" ✓ |
| **F** | **1** | `crates/front/src/query/mod.rs`（`tag_runs_with_notations` ✓） | **wire 的 runs** ✓ | **②**（已有 ✓） | 同上 ✓；`text` 侧已改显示副本 ✓（T-U4 ✓） |
| **G** | **3** | `crates/front/src/compile/tests.rs` | **测试夹具** ✓ | **③ 不做** ✓ | 测试自己的期望串 ✓，不是用户可见文本 ✓ |
| **H** | **1** | `crates/front/src/compile/check/mod.rs` | 编译期诊断拼串 ✓ | 并入 **B** ✓ | 与 B 同类 ✓ |
| **I** | **1** | `crates/front/src/compile/check/walk.rs` | 目标生产 ✓ | **③ 不做** ✓ | **它是判卷输入** ✗（红线 ✓：折它 = `suggest::*` 当场判红 ✓；见 §9 ㉜ ✓） |
| **J** | **1** | `crates/front/src/judge.rs` | 判定用文本 ✓ | **③ 不做** ✓ | **判定量** ✗（折它就会改变接受/拒绝 ✓ —— 内核红线 ✓） |
| **K** | **1** | `crates/front/src/suggest.rs` | 候选文本 ✓ | 逐条判 ✗ | 候选要**能解析**✓ ⇒ 折与不折都可能对 ✓；**② 补判据**为主 ✓ |

**A 组 5 处逐条**（用户点名 ✓）：
| # | 位置 | 产出 | 处置 |
|---|---|---|---|
| A1 | `lsp/lib.rs:1332` `term_text = render_expr(body)` | hover 里的**项**文本 ✗ | **①**：走 `render_text`（用报告里的 `notations` ✓） |
| A2 | `lsp/lib.rs:1340` `goal_text = render_expr(&goal_ty)` | hover 里的**目标**文本 ✗ | **①**（同上 ✓） |
| A3 | `lsp/lib.rs:1359` `goals.push(render_expr(domain))` | 部分应用的目标列表 ✗ | **①**（同上 ✓） |
| A4 | `lsp/lib.rs:1364` `goals.push(render_expr(…))` | 同上 ✗ | **①**（同上 ✓） |
| A5 | `lsp/lib.rs:1376` `codomain = render_expr(cur)` | 同上 ✗ | **①**（同上 ✓） |

**落地要点（A/B 两组 ✓）**：front 已有 `DisplayNotations`（`print_back` 那一族 ✓），
而 `ProjectReport` 里带着 `notations: Vec<NotationDecl>` ✓（`report.rs:137` ✓）
⇒ 需要一个**公开的**"按报告折一段文本"入口 ✓（例如
`query::fold_text_with(report, text) -> String` ✓），LSP/hover 与 elab 的诊断拼串都走它 ✓
—— **本次未实现** ✗（上下文不足 ✓），但落点已精确到行 ✓。

### A/B 组的**落地设计**（round 102 实测定的 ✓ —— 不是简单委托 ✗）
**实测**：`DisplayNotations { table: Vec<NotationDecl>, arity: HashMap<String,usize> }`
（`display.rs:108-116` ✓）⇒ 建表**必须有 ARITY 表** ✗，而 arity 是从**声明的类型**算出来的
（`arities_in_commands` ✓，`display.rs:641` ✓）。`ProjectReport` 里带的
`notations: Vec<NotationDecl>`（`report.rs:137` ✓）**只有声明点** ✓ ⇒
**LSP / hover 这一侧拿不到 arity** ✗ ⇒ **折不了** ✗（本 session 第三次撞到同一堵墙 ✓：
`query::runs` 那次、`goal_display` 那次、这次 ✓ —— 每次都是"**表不在这一层**" ✓）。

⇒ **正解（与 T-U4 同款 ✓）**：**显示副本在 front 的生产/查询层折好** ✓，
LSP 只**搬运** ✓。具体：给 hover/诊断要用的文本在 **front 侧**产出**折过的副本** ✓
（照 `ty_text` / `val_text` / T-U4 的 `goal_display` 的样板 ✓），
A 组 5 处与 B 组 19 处改成读那份副本 ✓ —— **而不是**在 `lsp/lib.rs` 里调 `render_expr` ✗。
**这条设计结论取代**本文件 §3 里"加一个公开 `fold_text_with(report, text)`"的初稿 ✗
（那需要 front 侧把 arity 也放进报告 ✓，改动面更大且没必要 ✓）。

**因此 T-U11 的第一步是**：找出 A/B 两组各自**该由哪个 front 生产者**产出显示副本 ✓
（`half_expression_goals_hover` 的输入从哪来 ✓、`elab.rs` 的诊断消息在哪一步拼 ✓），
**先定这个再动代码** ✗（否则就是又一次"在错的层上修" ✓）。

### ✅ **T-U11 的第一次实际迁移**（round 106 ✓）：`kernel_phase.rs` 的 `ty_text` 走唯一接口
* **迁移前**：`crates/front/src/compile/check/kernel_phase.rs:104/123/321` 直接调
  `crate::display::print_back(&text, display).as_display_str().to_string()` ✗
  （正是 T-U12 副发现指出的那条路 ✓ —— `ty_text`/`val_text` 与开放练习的类型副本 ✓）。
* **迁移后**：`display.fold(&text)` ✓ —— **零行为变化** ✓（`fold` 就是
  `print_back(text, self).as_display_str().to_string()` ✓，见设计 §2 ✓）。
* **判据** ✓：`cargo check` ✓ · `cargo test -p sokonanoda-front --lib` ⇒ **735 passed** ✓
  （含 T-U12 的面级判据 `a_kernel_pp_display_surface_must_be_folded` ✓）
  · 守卫：**92 → 89** ✓（`--rebless` ✓）· `audit-notation-paths.py` ⇒ 无新增绕过 ✓。
* ⚠ **基线数字更新** ✓：上一轮修好守卫后是 **92** ✓（不是 77 ✓ —— 旧数字漏检了
  **路径限定**调用 ✗，见守卫自己的注释 ✓）；本轮的 **89** 是新基准 ✓。
  §3 的分组表**仍按旧 77 编** ✗ ⇒ 待按 **89** 刷新 ⏳（新抓的那些集中在
  `walk.rs`(8) / `kernel_phase.rs`(3，本轮已迁 ✓) / `check/mod.rs` 等 ✓）。

### A 组的**精确落点**（round 107 实测 ✓）
`crates/lsp/src/lib.rs:1283 half_expression_goals_hover(report, text, offset, decls)` ✓
自己 `parse_expr_text` + `peel_pi_layers` + `render_expr` ✓ ⇒ 它渲染的是**源码 AST**
与**剥出来的 Pi 层** ✓。**点形式从哪里漏** ✗：剥出来的 `domain`/`codomain`
是**内核侧**的类型 ✓（不是源码里的记法 ✓）⇒ 5 处 `render_expr` 里，
真正需要折叠的是这些**内核侧子项** ✓。

**好消息（少走一步 ✓）**：报告里的 `DeclState` **已经带折过的副本** ✓：
`ty_text` / `val_text`（`report.rs:109/114` ✓）—— 它们就是**整个类型/值**的折叠结果 ✓
⇒ A 组的**整类型**那一类（`goal_text = render_expr(&goal_ty)` ✓）可以直接改读它 ✓。

**卡点（与 round 102 同一条墙 ✓）**：`domain`/`codomain` 是**子项** ✗，
报告里**没有**对应的折叠副本 ✓，而 LSP **拿不到 arity 表** ✗（`DisplayNotations` 需要它 ✓）
⇒ 折不了 ✓。**正解（下一步 ✓，设计与 T-U4 同款 ✓）**：让 **front 把"折叠能力"带进报告** ✓
—— 最小改法是在 `ProjectReport` 里带上**记法表 + arity**（或直接带一个
`Vec<NotationDecl>` + `HashMap<String,usize>` ✓，即 `DisplayNotations` 的字段 ✓），
并给 front 一个**公开的** `fold_text(&self, text) -> String` ✓；LSP 只调它 ✓。
**不许**在 LSP 侧重建 arity ✗（那会变成第五套实现 ✓ —— 守卫会抓 ✓）。

**本轮结论** ✓：A 组**不能**用"简单替换"完成 ✗（需要一次 wire/报告结构的小扩展 ✓）；
**先做 B 组更容易** ✓（`elab.rs` 在 front 内部 ✓ —— 那里**本来就有**表 ✓，
可以就地走 `fold` ✓，零结构改动 ✓）。⇒ **顺序调整：B 组优先** ✓。

### B 组逐条处置（round 108 实测 ✓，21 处 = 基线 20 + 1 ✓）
**判据**：看**这一处的产出是不是"给人看的消息"** ✓。是 ⇒ **①**（折 ✓）；
是**判卷/解析输入** ⇒ **③ 不做** ✓（**折它 = 改判定** ✗，内核红线 ✓，见 §9 ㉜ ✓）。

| # | 位置 | 产出什么 | 结论 |
|---|---|---|---|
| 1 | `elab.rs:1513` | binder 记法 guard **报错消息**里的 guard 文本 ✓ | **① 折** ✓ |
| 2 | `elab.rs:1754` | ``` `{candidate}` 的结果类型是 `{}` ``` **消息** ✓ | **① 折** ✓ |
| 3 | `elab.rs:2158` | ``` `{}` 的签名 `{}` 里有 N 个隐式参数… ``` **消息** ✓ | **① 折** ✓ |
| 4 | `elab.rs:2161` | 同上消息里的 `ty_text` ✓（**本来就是折过的** ✓） | **已 ①** ✓ |
| 5 | `elab.rs:2434` | ``` `⟨…⟩` 的期望类型 `{}` … ``` **消息** ✓ | **① 折** ✓ |
| 6 | `:2003 · :3042 · :3742 · :4192` | `judge_infer(…, &render_expr(x))` ✗ **判定输入** | **③ 不做** ✓（折它 = 改判定 ✗） |
| 7 | `:1556 · :1611 · :1692` | `render_expr(&Expr::Ident{…})` 供 `resolve_known` **名字解析** ✗ | **③ 不做** ✓（解析要**点名**形式 ✓） |
| 8 | `:515 · :557 · :736 · :755 · :889` | `GoalBinderSpec.ty` / 归纳/递归子的 `signature` ✓ | **③ 不做** ✓（**喂 judge** ✗；显示侧由 T-U4/T-U5 的 `runs` 负责 ✓ —— `notation_fold.rs` 第 2 组的行程开关钉着这条 ✓） |
| 9 | `:1356 · :4221 · :4656` | 内部/期望类型文本（参与推断 ✓） | **③ 不做** ✓（同上 ✓） |

⇒ **B 组的实际工作面只有 ~4 处**（1–5 里除 4 ✓）✓ —— 而不是"20 处一起折" ✗。
**下一步** ✓：确认 `elab.rs` 那几处**能不能拿到记法表** ✓（若 `ElabCtx` 没有 ✓，
就沿用 A 组的正解：**由 front 的生产侧产显示副本** ✓，而不是在 `elab.rs` 里重建表 ✗）。

### 迁移与基线流水（T-U11，逐条可核 ✓）
| round | 动作 | 基线 |
|---|---|---|
| 105 | 守卫修准（漏检**路径限定调用** ✗⇒✓） | 77 → **92** ✓ |
| 106 | 迁 `kernel_phase.rs:104/123/321`（`ty_text`/`val_text` ✓） | 92 → **89** ✓ |
| 111 | 迁 `check/mod.rs:392`（`by_step_states` 的 `fold` 闭包 ✓） | 89 → **88** ✓ |
| 111 | 守卫精修：**跳过定义/再导出签名行** ✓（`check/mod.rs:1243` 的 `pub fn render_expr` 与
其体内再导出**不是绕过** ✗ ⇒ 去掉 2 条假条目 ✓） | 88 → **86** ✓ |
**判据** ✓：每次迁移后 `cargo test -p sokonanoda-front --lib` 全绿 ✓（735 ✓，含 T-U12 面级判据 ✓）；
每次 `--rebless` 后 `audit-notation-paths.py` ⇒ 无新增绕过 ✓；`--self-test` ⇒ **仍咬得住** ✓。

### A 组与 B 组的**共同卡点**（round 111 实测 ✓）⇒ 需要**同一次**结构扩展
* **A 组**（LSP hover ✓）：`half_expression_goals_hover(report, …)` 里 **LSP 拿不到 arity 表** ✗
  （报告只有 `notations: Vec<NotationDecl>` ✓，`DisplayNotations` 需要 arity ✓）。
* **B 组**（`elab.rs` 的 4 处消息 ✓）：`ElabCtx`（`elab.rs:445` ✓，字段 `prefix_src`/`options`/
  `inductives`/`ns`/`defs` ✓）**完全没有** `DisplayNotations` ✗（`grep DisplayNotations elab.rs`
  ⇒ **零命中** ✓）⇒ 那 4 处**就地折不了** ✗。
⇒ **两个组卡在同一条**：**"表不在这一层"** ✓（本 session 第 **4** 次 ✓：`query::runs` ✓、
`goal_display` ✓、A 组 ✓、B 组 ✓）。
**一次扩展同时解两组** ✓（下一步的设计 ✓）：
1. `ElabCtx` 加 `notations: &'b DisplayNotations` ✗ ⇒ B 组 4 处走 `ctx.notations.fold(text)` ✓；
2. `ProjectReport` 带上**表 + arity**（或一个公开的 `fold_text(&self, text)` ✓）⇒ A 组 5 处走它 ✓。
**红线** ✓：**不许**在任何一层"重建" arity ✗（= 第五套实现 ✓，守卫会抓 ✓）；
**也不许**把 `ElabCtx` 的表用在**判定路径**上 ✗（B 组那 17 处 ③ 的理由不变 ✓）。
**顺序** ✓：先 1（B 组 ✓，改动面小、判据现成 ✓）后 2（A 组 ✓）。

### `ElabCtx` 扩展的侦察结果（round 112 ✓）—— **不是"加个字段"** ✗
| | 实测 |
|---|---|
| 构造点 | **9 处** ✗：`walk.rs:420/651/865/986/1267/1313` ✓、`elab.rs:662` ✓、`prelude.rs:446/557` ✓ |
| 记法表在哪可得 ✓ | **`walk.rs` 的 6 处**（`self.display` ✓，`check/mod.rs:830` 建的 ✓） |
| 记法表在哪**不存在** ✗ | **3 处**：`elab.rs:662` ✓、`prelude.rs:446/557` ✓（**都不在 check 阶段** ✓） |
⇒ 直接加 `notations: &DisplayNotations` ✗ 会逼着往上游传表 ✓（改动面**不止 9 处** ✓）。
**可行设计（待做 ✓）**：加 **`Option<&'b DisplayNotations>`** ✓ ——
`walk.rs` 的 6 处填 `Some(&self.display)` ✓、其余 3 处填 `None` ✓；
4 处消息在 `Some` 时走 `fold` ✓、`None` 时按原样 ✓（"**没有表的地方 ≠ 显示上下文**" ✓，
与 `prelude.rs` 注释里那句"没有表的地方传空表（不影响）"同一种约定 ✓）。
⚠ **不许**把 `None` 当默许去**重建**表 ✗（第五套实现 ✓，守卫会抓 ✓）。
**本轮未动** ✗（9 处 + 语义分叉 ⇒ 上下文不足 ⇒ 不留半成品 ✓）。

### ⚠ `ElabCtx` 扩展的**硬约束**（round 128 实测 ✓，下次别踩 ✗）
**`sokonanoda-front` 把 `dead_code` 当错误** ✗：只加字段、不读它 ⇒
```
error: field `notations` is never read
  --> crates/front/src/compile/elab.rs:456:9
```
⇒ **"加字段"与"至少一处真实使用"必须落在同一个提交** ✓（分两步做会编译不过 ✗）。

**下次的正确做法（本轮已把前半做完并验证 ✓，只是回退了 ✓）**：
1. 加字段 ✓（`elab.rs` 的 `ElabCtx` ✓）—— 已实测**编译器会精确点名全部 9 处** ✓：
   `walk.rs:420/651/865/986/1267/1313` ✓（填 `Some(&self.display)` ✓）、
   `elab.rs:668` ✓、`prelude.rs:446/557` ✓（填 `None` ✓）；
2. **同一提交里**改一处消息 ✓ ⇒ 字段被读 ✓ ⇒ 编译通过 ✓。
**机械填法（本轮验证过 ✓，别用正则 ✗）**：正则只匹配到 2/6 ✗ —— 要用**编译器给的行号**
**从后往前**插（行号不漂 ✓），循环到 `rc==0` ✓。
**4 处消息的真实签名（本轮已读出 ✓）**：
| 位置 | 函数 | 有没有 `ctx` |
|---|---|---|
| `elab.rs:1513` | `binder_notation_operand` | **有** ✓（首选 ⇒ 第一处就改它 ✓） |
| `elab.rs:1754` | `candidate_list(candidates: &[&str])` | **没有** ✗（纯格式化 ⇒ 要给它加参数 ✗） |
| `elab.rs:2158` | `try_implicit_application` | 有 ✓ |
| `elab.rs:2434` | `anon_ctor_target` | 有 ✓ |
⇒ 第一处改 `binder_notation_operand` 的**消息文本** ✓（折它 ✓）；其余三处随后 ✓
（`candidate_list` 要么加参数 ✓、要么不折 ✓ —— 它是**消息** ✓ ⇒ 按硬规则该折 ✓）。

### ✅ **T-U11 第二次迁移**（round 129 ✓）：`ElabCtx` 拿到记法表 + 3 处诊断消息走唯一接口
* **字段** ✓：`ElabCtx.notations: Option<&'b DisplayNotations>`（`elab.rs:445` ✓）——
  **只许消息路径用** ✓，判定/解析路径一律不折 ✗（内核红线 ✓）。
* **9 个构造点全填** ✓（用**编译器行号、从后往前**插 ✓，一次成功 ✓）：
  `walk.rs` ×6 ⇒ `Some(&self.display)` ✓；`elab.rs:668`、`prelude.rs:446/557` ⇒ `None` ✓
  （`None` = "这里不是显示上下文" ✓，沿用 `prelude.rs` 既有约定 ✓）。
* **助手 `render_msg(ctx, expr)`** ✓：`Some` ⇒ `n.render(expr)` ✓（= 唯一接口 ✓）；
  `None` ⇒ `render_expr(expr)` ✓（原样 ✓）。
* **迁移的 3 处消息** ✓：`binder_notation_operand`（`render_expr(guard)` ✓）、
  `try_implicit_application`（`render_expr(head)` ✓）、`anon_ctor_target`（`render_expr(expected)` ✓）
  —— 都是**给人看的诊断文本** ✓（按用户硬规则必须折 ✓）。
* ⏳ **剩 1 处**：`candidate_list(candidates: &[&str])`（`:1754`）**没有 `ctx`** ✗
  ⇒ 要么给它加参数 ✓、要么不折 ✓（它是消息 ⇒ 按硬规则该折 ✓）。
* **判据** ✓：`cargo check` **rc=0** ✓（`dead_code` 那条错误消失 ⇒ 字段确实被读了 ✓）·
  `cargo test -p sokonanoda-front --lib` ⇒ **735 passed / 0 failed** ✓（行为不变 ✓）·
  `audit-notation-paths.py` ⇒ **无新增** ✓ · 基线 **86 → 84** ✓（`--rebless` ✓）· fmt ✓

### ✅ **B 组（`elab.rs` 诊断消息）** 全部迁完 ✓（round 130 ✓）—— 4/4
* 第 4 处 = `describe_candidate_results` ✓（产出"`候选` 的结果类型是 `…`" ✓ —— **给学习者看的消息** ✓）：
  给它加了 `ctx: &ElabCtx<'_, '_>` 参数 ✓、`render_expr(result)` ⇒ `render_msg(ctx, result)` ✓、
  调用点（`elab.rs:1738` ✓）同步补 `ctx` ✓。
* **判据** ✓：`cargo check` 干净 ✓ · `cargo test -p sokonanoda-front --lib` ⇒ **735 passed / 0 failed** ✓ ·
  `audit-notation-paths.py` ⇒ **无新增** ✓ · `--self-test` ⇒ **仍咬得住** ✓（`walk.rs` 8 处 ✓）·
  基线 **84 → 83** ✓（`--rebless` ✓）· fmt ✓
* **B 组小结** ✓：4 处**用户可见诊断**全部走唯一接口 ✓（`render_msg` ✓）；
  其余 17 处按 ③ **不做** ✓（判卷输入 ✗ / 名字解析 ✗ / 喂 judge ✗ —— 折它们会改判定 ✓）。
* ⏳ **下一步 = A 组**（LSP hover 5 处 ✓）：需要 `ProjectReport` 带表 + arity ✓
  （或公开 `fold_text` ✓）；红线 ✓：**不许**任何一层**重建 arity** ✗（第五套实现 ✓，守卫会抓 ✓）。

### 🔴 **新缺陷（round 156 实测 ✓）**：`kernel-rejected` 诊断漏出**原始内核 pp** ✗
**证据** ✓（探针原文 ✓，折叠**开与关完全相同** ✗）：
```
code = kernel-rejected
message = 类型不匹配：期望 `Pi (A : (Set.[] Nat.[])), Pi (B : (Set.[] Nat.[])),
          (((Set.subset.[] Nat.[]) $1) $0)`，实际是 `Pi (…), Sort(0)`
```
⇒ 这是**给学习者看**的诊断 ✓（"类型不匹配" ✓），却把内核 pp 原样吐出来 ✗ ——
`Set.[]` / `Set.subset.[]` / `$1` / `Sort(0)` ✓ **既不是记法、也不是干净的点形式** ✓。
**用户硬规则** ✓（`REQUIREMENTS.md` §9 ㉟）：「凡产出用户可见文本的（… 诊断消息 …）
必须走 ① 或 ②」✗ ⇒ 它**当前两条都没走** ✓。
**归属** ✓：这条**不在** T-U11 的 79 条基线里 ✓（基线只扫 `render_expr`/`print_back`/
`tag_runs_with_notations` ✓）⇒ 它是**守卫的盲区** ✓ —— 消息由**内核拒绝**那条路拼出来 ✓
（`kernel-rejected` ✓，源头在 judge/内核→诊断的转换处 ✓）。
**下一步（先定位再改 ✓）**：
① `git grep '"类型不匹配'`（或 `类型不匹配：` ✓）找拼串点 ✓；
② 看它有没有记法表可用 ✓（若有 ⇒ 直接走 `fold` ✓；若没有 ⇒ 与 A/B 组同款"把表带进去" ✓）；
③ 判据 ✓：该消息在 `SOKO_NO_NOTATION_FOLD=1` 下**必须变**（能咬 ✓ —— 因为它是**内核 pp** ✓，
不是源级渲染 ✓）；若它现在**两态相同** ✗ ⇒ 判据就是"**两态必须不同**" ✓
（这比"无点形式"更贴切 ✓：先把折叠接上 ✓，再谈记法 ✓）。

### 🔴🔴 **更正（round 158 实测 ✓）**：round 157 那个"修复"**无效** ✗ —— 但它换来一条**真正的诊断** ✓
**证据** ✓（判据在两态下**都红** ✓、消息**一字不差** ✓）：
```
折叠开：… 期望 `Pi (A : (Set.[] Nat.[])), …, (((Set.subset.[] Nat.[]) $1) $0)` …
折叠关：… 完全相同 ✗
```
⇒ `display.fold(&expected)` **什么也没做** ✓。**真因** ✓：
那段文本是**内核的 debug 形式** ✗（`Set.[]` / `$1` / `Sort(0)` / `Pi (…)` ✓），
**不是**前面那套可折叠的渲染形式 ✓ ⇒ **折叠器解析不了它** ✓ ⇒ 折与不折同值 ✓。
（对照 ✓：`ty_text` 那条路折的是 `render_expr` 出的**源级形状** ✓ ⇒ 能折 ✓；这条不是 ✓。）

**⇒ 真正的修法方向（不是"折一下" ✗）** ✓：**换渲染器** ✓ ——
`expected` / `actual` 是在 `kernel_phase.rs` 里由 `format!("{e}")` 从**内核错误**取来的 ✓
（`:160` / `:373` ✓ 的 `let msg = format!("{e}")` ✓）⇒ 要让**内核/诊断转换处**用
**可读的类型打印**（前端的 `render_expr` 形状 ✓，或内核的 surface printer ✓），
**而不是** `Debug`/`Display` 的 `Set.[]` 形状 ✓。折记法是**第二步** ✓；第一步是**先给出能折的文本** ✓。

**方法论收获（值得单独记 ✓）** ✓：这一轮的判据**红了两次** ✓ —— 但它证明的不是"判据写错了"✗，
而是"**修复没生效**"✗。**把"弄红"的纪律用在修复上，同样有效** ✓：
如果只看 `cargo check`/`cargo test` 全绿 ✓ 就宣布修好 ✓，这个缺陷会**原样留在**用户面前 ✗。

### 🔴🔴 真修法的**两条路线**（round 159 侦察 ✓）
`Set.[]` **不是内核里的字面量** ✗ —— 它是 printer **拼出来**的 ✓
（`名字 + ".[]" + 宇宙层` ✓，`crates/kernel/src/debug_printer.rs` 那族 `fmt` ✓）。
⇒ 修法有两条，**代价差很远** ✓：

| 路线 | 做法 | 代价 |
|---|---|---|
| **A. 改内核 printer** ✗ | 让它输出可读类型 ✓ | **侵入内核** ✗ ⇒ 触发红线流程（三层回归 + 语料逐字节对拍 ✓）；而且 `. []` 这种形状可能是**别处依赖**的 ✓ ⇒ **不首选** ✗ |
| **B. front 侧带出结构化类型** ✓✅ | 在**内核→诊断**的构造点 ✓，让错误**一并带出类型**（`Value`/`Expr` 结构化 ✓）；`kernel_phase.rs` 用它 + front 的可读渲染器打印 ✓ | **最小侵入** ✓：内核只**多带一个字段** ✗（不改既有判定 ✓）；front 侧改动可控 ✓ |

**⇒ 首选 B** ✓。**下一步（第 ① 步 ✓）**：读**内核错误类型** ✓（`crates/kernel` 里那个被
`format!("{e}")` 打印的东西 ✓）—— 看它**是否已经**带类型字段 ✓：
* **已带** ✓ ⇒ 直接在 `kernel_phase.rs` 用 front 渲染器打印 ✓（改一处 ✓）；
* **没带** ✗ ⇒ 在内核侧**加字段** ✓（结构化 ✓、不动判定 ✓，仍走三层回归 ✓）。

**判据已经就绪** ✓✓：round 158 写的那条（**两态必须不同** + 折叠后出现 `⊆` ✓）
**已经证明能咬** ✓（它红过两次 ✓）⇒ 渲染一改好它就会**转绿并从此锁住** ✓。

### **G 组（`prelude.rs`，3 条）逐条处置** ✅（round 169 ✓）
三条**完全同形** ✓：`:470` · `:492` · `:591`，都是
```rust
signature: Some(crate::proof::render_expr(ty)),
```
⇒ 它们造的是 **`GoalBinderSpec.signature`** ✓ —— 与 **B 组**里 `elab.rs:515/557/736/755/889`
那些**同款** ✓（round 108 已判过 ✓）。
| 位置 | 产出 | 结论 |
|---|---|---|
| `prelude.rs:470` · `:492` · `:591` | **`GoalBinderSpec` 的 signature** ✓（内建/prelude 声明的 binder 规格 ✓） | **③ 不做** ✓ |
**理由** ✓（与 B 组那 5 处**同一条** ✓）：`GoalBinderSpec` 是**喂 judge 的输入** ✗（
`judge_binders` ✓）—— **折它 = 改判定** ✗（内核红线 ✓）；而**显示侧**由 T-U4/T-U5 的
`runs` 负责 ✓（`notation_fold.rs` 第 2 组的**行程开关**钉着这条 ✓）。
⇒ G 组 **0 条迁移 / 3 条 ③** ✓ —— 它们此前**不在**旧基线里 ✓（守卫修准后才露出来 ✓，
`round 105` ✓），所以是**新可见、但不需要动**的一批 ✓。
---

### **I 组（`compile/tests.rs`，3 条）· J 组（`judge.rs`，1 条）逐条处置** ✅（round 171 ✓）
**I 组** —— 三条都在**同一个往返测试**里 ✓（`tests.rs:1501-1505` ✓）：
```rust
assert_eq!(render_expr(&expr), expected, "source: {source}");        // :1501
let back = parse_expr_text(&render_expr(&expr))                      // :1503
assert_eq!(render_expr(&back), expected, "round-trip: {source}");    // :1505
```
⇒ 它们验的是**渲染器的往返性质** ✓（源 → AST → 文本 → AST → 文本 ✓）⇒ **测试内部的期望串** ✗
⇒ **③ 不做** ✓（在那里折记法就**换了一个被测对象** ✗ —— 测的就不再是"往返"了 ✓）。
**J 组** —— `judge.rs:1113` ✓：
```rust
_ => render_expr(expr),          // 判定侧渲染器的**回退分支**
```
⇒ 它是**判定量** ✗（`judge` 模块 ✓）⇒ **折它 = 改判定** ✗（内核红线 ✓）⇒ **③ 不做** ✓。
⇒ **两组共 4 条：0 迁移 / 4 条 ③** ✓ —— 与组级结论一致 ✓、理由各自具体 ✓。
---

### **F 组（`semantic.rs`，5 条）· K2 组（`query/mod.rs`，1 条）逐条处置** ✅（round 173 ✓）
`tag_runs_with_notations` 这一族**不是**"绕过接口"✗ —— 它是 **`runs` 的**生产机制**** ✓
（T-U4/T-U5 的"显示副本"正建立在它上面 ✓）。
| 位置 | 产出 | 结论 |
|---|---|---|
| `semantic.rs:241` | **真实生产调用** ✓（`text, decls, binders, &[]` ✓ 由编译侧喂入 ✓） | **② 已有** ✓（T-U5 的**接缝守卫**钉着 `runs` 拼接 == `text` ✓） |
| `semantic.rs:1201/1217/1483/1505` | **测试内部**的调用 ✓（断言 `runs` 的分段 ✓） | **③** ✓（测试自己的期望 ✓） |
| `query/mod.rs:495` | **wire 的 `runs` 生产者** ✓（`semantic::tag_runs_with_notations(text, decls, binders, notations)` ✓） | **② 已有** ✓（同上 ✓） |
**K 组（`suggest.rs`）现在是 0 条** ✓ —— 该文件的 `render_expr` 已被 `render_msg` 包装 ✓
（守卫的"已折写法不算绕过"规则 ✓，round 133 ✓）⇒ **无事可办** ✓。
---

### **E 组（`check/walk.rs`，8 条）逐条处置** ✅（round 174 ✓）—— 只有**两种形状** ✓
| 形状 | 位置 | 产出 | 结论 |
|---|---|---|---|
| `signature: Some(render_expr(ty))` ×6 | `:503` `def` ✓ · `:598` `def` ✓ · `:709` `theorem` ✓ · `:822` `theorem` ✓ · `:896` `axiom` ✓ · `:943` `axiom` ✓ | **`GoalBinderSpec.signature`** ✓ | **③** ✓ —— 与 **G 组完全同因** ✓（喂 judge ✗，折它 = 改判定 ✓ 内核红线 ✓） |
| `goal: render_expr(ty)` ×2 | `:737` `theorem` ✓ · `:1055` `example` ✓ | **walk 累积的"开放练习目标"** ✓ | **③** ✓ —— **有实测证据** ✓：T-U4 那轮我折了它 ⇒ **5 条 `suggest::*` 当场红** ✗（§9 ㉜ 的行程开关 ✓），已回退 ✓ |
⇒ **8 条全 ③** ✓，理由分两类 ✓（6 条同 G 组 ✓、2 条有**历史实测**背书 ✓）。
⚠ **为什么不放进白名单** ✗：`--self-test` **正是拿这个文件当靶子** ✓
（"应当抓到 walk.rs 里的绕过" ✓）⇒ 排除它 ⇒ **自检瞎掉** ✗（round 171 实测 ✓）
⇒ **这 8 条留在基线里** ✓ —— **守卫的可验证性 > 数字好看** ✓。
---

### **C 组（`by.rs`，22 条）逐条处置** ✅（round 175 ✓）—— **全部在判定侧** ✓
按**所属函数**归类后一目了然 ✓（**一个显示面的都没有** ✗）：

| 所属函数 | 行 | 性质 | 结论 |
|---|---|---|---|
| `level_hint_of` | `:60` `:63` | `infer(&render_expr(…))` ✓ 宇宙层推断 | **③** ✓ |
| `restore_universe_levels` | `:257` | `judge_infer(…)` ✓ | **③** ✓ |
| `canonical_goal_type` | `:513` | `judge_render_type(…)` ✓ | **③** ✓ |
| `canonical_goal_with_spec` | `:563` | `judge_render_type(…)` ✓ | **③** ✓ |
| `run_tactics` | `:953` `:954` `:965` `:1164` | `spec.ty` / `term` / 余式 —— **tactic 引擎的判定输入** ✗ | **③** ✓ |
| `solve_type_params` | `:1240` | `probe` ✓ 合一求解 | **③** ✓ |
| `apply_tactic` | `:1277` `:1349` `:1350` `:1351` | `term` / 候选 / `codomain` / `goal` ✓ | **③** ✓ |
| `cases_tactic` | `:1486` `:1550` | `goal_ty` / `scrutinee_ty` ✓ | **③** ✓ |
| `spec_of_for_judge` | `:1892` `:1904` | **函数名就写着** `for_judge` ✓✓ | **③** ✓ |
| `exact_tactic` | `:2015` | `nodes[cur].ty` 喂判卷 ✓ | **③** ✓ |
⇒ **22 条全 ③ / 0 迁移** ✓ —— 与 round 108 的**组级**结论一致 ✓，
但现在**逐条**落到了**所属函数**上 ✓：**这一组没有任何用户可见面** ✗
（它们全部服务 `front::judge` 与 tactic 引擎 ✓ —— **折它们 = 改判定** ✗ 内核红线 ✓）。
⚠ **留在基线里** ✓（46 条待迁移的账目要真 ✓；白名单只收"不会再被守卫自检用到"的文件 ✓
—— `by.rs` 不在其中 ✓）。
---

### **D 组（`compile/goals.rs`，17 条）逐条处置** ✅（round 176 ✓）—— **最后一组** ✓
按**所属函数**归类 ✓（与 C 组同一手法 ✓，结论同样干净 ✓）：
| 所属函数 | 行 | 性质 | 结论 |
|---|---|---|---|
| `probe_arg_type` | `:433` | `term` 喂**探针** ✗（判定 ✓） | **③** ✓ |
| `peel_pi_domain_text` | `:507` | 在**类型文本**上剥 Pi（判定侧）✗ | **③** ✓ |
| `render_arg` | `:699` ×2 | 实参文本 ✓ —— 服务**目标文本**（判卷用 ✓，见 T-U4 实测 ✓） | **③** ✓ |
| `field_type_text` | `:1022` ×2 | 构造子字段类型文本 ✓（判定/交互 ✓） | **③** ✓ |
| `ctor_spine_case` | `:1059` | `goal: render_expr(ty)` ✓ | **③** ✓ |
| `func_spine_case` | `:1106` | `text` ✓ | **③** ✓ |
| `instantiate_binder_type` | `:1274` | `text` ✓（instantiate ✓） | **③** ✓ |
| `goal_under_binders` | `:1341` ×5 | `goal` / `arm_r` / `r` / `text` / `ty` ✓ | **③** ✓ |
⇒ **17 条全 ③ / 0 迁移** ✓。**留在基线里** ✓（账目要真 ✓）。

---

## ✅ **要求 ① 的逐条清单：全部收口**（round 176 ✓，**11 组 / 87 条** ✓）
| 组 | 文件 | 处数 | ① 迁 | ② 已有 | ③ 不做 |
|---|---|---|---|---|---|
| **A** | `crates/lsp/src/lib.rs` ✓（**用户可见** ✓） | 5 | **5** ✅ | – | – |
| **B** | `compile/elab.rs` ✓（**用户可见** ✓） | 21 | **4** ✅ | – | 17 ✓ |
| **C** | `by.rs` ✓（判定侧 ✓） | 22 | – | – | **22** ✓ |
| **D** | `compile/goals.rs` ✓ | 17 | – | – | **17** ✓ |
| **E** | `check/walk.rs` ✓ | 8 | – | – | **8** ✓ |
| **F** | `semantic.rs` ✓（runs 机制 ✓） | 5 | – | **2** ✅ | 3+1 ✓ |
| **G** | `compile/prelude.rs` ✓ | 3 | – | – | **3** ✓ |
| **H** | `check/mod.rs` ✓ | 1 | – | – | **1** ✓（+守卫精修 ✓） |
| **I** | `compile/tests.rs` ✓ | 3 | – | – | **3** ✓ |
| **J** | `judge.rs` ✓ | 1 | – | – | **1** ✓ |
| **K** | `suggest.rs` ✓ | **0** | – | – | 已消解 ✓ |
| **K2** | `query/mod.rs` ✓ | 1 | – | **1** ✅ | – |
| **合计** | | **87** | **9 迁移** ✅ | **3 已有** ✅ | **75 不做** ✓ |
**⇒ 用户硬规则（§9 ㉟）满足** ✓：**凡产出用户可见文本的（A 组 5 + B 组 4 = 9 处）全部走 ①** ✓；
其余 **75 处逐条**给出 ③ 并写明理由 ✓（**没有一处是"没看"** ✓）。
**基线 68 条**（= 87 − 9 迁移 − 3 ②已有 − 4 测试 ③ − 3 白名单）✓ —— 它有明确含义 ✓：
**"判定侧、待将来内核改造后才可能谈"的那一批** ✓。
