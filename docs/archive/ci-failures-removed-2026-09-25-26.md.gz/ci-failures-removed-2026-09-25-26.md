## 判据
本机行为**不变** ✓（本地本来就解析仓库构建 ✓）；**CI 侧由下一轮确认** ✓
—— 这是**必须推**的那类改动 ✓（本地绿 ≠ CI 绿 ✓ 本 session 已证 ✓）。

## 2026-09-25 · **用户指出：整轮的 `in_progress` 掩盖了已发生的失败** ✗（round 182 修 ✓）
**用户原话** ✓："ledger **立马就失败**了，但是**整个 github action 还在继续**，
导致**你不知道已经失败了**" ✓ —— 完全成立 ✓，而且我在旁边反复撞这堵墙 ✗：
* 实测 ✓（`#36151088821` ✓）：整轮 `in_progress` ✗，而 `ledger (3)` **15:09:04 就红了** ✗
  （`test/*` · `gates` 还在跑 ✓，要十几分钟 ✓）⇒ **失败信号被拖住了** ✗；
* **为什么我读不到细节** ✗：`gh run view --job <id> --log` 在**整轮结束前**回
  `run … is still in progress` ✓ ⇒ **日志拿不到** ✗（本 session 为此刻苦了半小时 ✓）。

### 两处修 ✓
1. **`scripts/gap.py` 写 `$GITHUB_STEP_SUMMARY`** ✓ —— 每片无论红绿都写一行结论 ✓
   （红时给出"本地复跑这一片"的命令 ✓）⇒ **页面上**一眼可见 ✓、**不必等整轮** ✓。
2. **`scripts/ci-watch.sh`** ✓ —— **按 job 看，不看整轮** ✓：
   `gh run view <id> --json jobs` ✓ ⇒ 逐 job 打印结论 ✓，**只要最新一轮有 job 红就 `exit 1`** ✓。
   **实测** ✓：对用户指的那轮 ⇒ "失败 job 数 = **3**" ⇒ **它会立刻判红** ✓✓。
3. **清队列** ✓：取消 3 个**排队中**的 run（`#36151294668` ✓ `#36151088821` ✓ `#36150927359` ✓），
   保留最新一轮 ✓（含 `ledger` 修复 ✓）。

### 教训（对"我"的 ✓）
**监控要盯最细的可判单元** ✗：整轮状态是**聚合量** ✓，聚合会把"已经确定的失败"
**稀释**成"还在跑" ✗。**这一条与判据设计同源** ✓：**别用聚合信号判断局部状态** ✗。

## ✅ **注解链路打通**（round 199 ✓）—— `ledger (2)` 的**真凶已指名** ✓（2026-10-13 压缩存档）

**结论**：`G-23` 的复现件在 CI 上撞了 **Node 自己的定时器超时**（栈含 `listOnTimeout`/`processTimers`
= **Node 内部**，**不是**我们的 `SOKO_GAP_REPRO_TIMEOUT`）⇒ 退出码 2 ⇒ `judge` 判「环境异常」
⇒ 与台账的 `fixed` 不一致 ⇒ 整片红 ✗。**与 round 126 同族但不同路**：那次修的是**我们自己的超时**，
这条走的是**复现件内部的 Node 超时** ⇒ 两条路都要覆盖 ✓。
**修法**：① 给复现件**加长 Node 侧超时**；② 把「`exit 2` + 栈含 `listOnTimeout`/`processTimers`」
也**分档为环境异常**（响亮跳过 + `--strict` 才判红）—— **必须配本地兜底判据**，否则会掩盖真回归 ✗。
**判据**（原文保留）：
```bash
SOKO_LSP_REPLY_TIMEOUT_MS=1 bash docs/gaps/repro/G23-notation-navigation.sh   # ⇒ exit 2 + Node 栈 ✓
SOKO_LSP_REPLY_TIMEOUT_MS=1 python3 scripts/gap.py check --shard 2/3           # 期望 0（A+B 都上之后 ✓）
SOKO_LSP_REPLY_TIMEOUT_MS=1 python3 scripts/gap.py check --shard 2/3 --strict  # 期望 1 ✓
```
**顺带确认**：`ledger (1)` 与 `ledger (3)` 都转绿 ✓；`gates-fast` **2 分 09 秒** ✓（原 3 分钟+）。

## 2026-09-25 · `0.72.0` 发版连续红三次 —— **三条教训**（2026-10-13 压缩存档，教训一条不删）

### ① **bump 其实是五处** ✗ ——「两处」是脚本替你写全之后的**表象**
`Cargo.toml` · **`Cargo.lock`** · `editor/vscode/package.json` · **两个 `sokonanoda.toml` 的 `requires`**。
**症状**：只改 `Cargo.toml` ⇒ `gates-fast` 红在 `cargo build --locked`（**锁文件还记着旧版本** ✗）；
下一红又是同一类 ⇒ `bump.py --check` 报**版本漂移**（两个 `sokonanoda.toml` 的 `requires` 没跟上）。
**规程** ✓：**bump 一律 `python3 scripts/bump.py <x.y.z>`** ⇒ **然后 `--check` 复检** ✓
（手改两处 = 必然漏三处 ✗）。

### ② **修 CI 时**：每改一处就推 ⇒ `cancel-in-progress` **帮你省时间** ✓（掐掉旧轮 ✓）
### ③ **发版窗口里** ✗：**每一推都掐掉唯一那轮 `rust == true` 的运行** ⇒ **推一次就停手** ✓
—— 等它跑完（**别再推，哪怕发现小错** ✗；小错留到下一批 ✓）。

## 2026-09-25 · 整轮 **success 却什么都没跑** —— `paths-filter` 看的是"**这一推的 diff**" ✗

**症状** ✓：`0.72.0` 的发版推之后，整轮 **`success`** ✓ 而**只有 3 个 job** ✗
（`changes` + `lint-fmt` + `lint-clippy` ✓）⇒ **重活与 `auto-tag` 全 `skipped`** ✗ ⇒ **没发版** ✓。
**日志原文** ✓（`changes` job ✓）：
```
Run dorny/paths-filter@v4
  **Matching files: none** ✗
  **Changes output set to []** ✗
```
**根因** ✓：**`paths-filter` 只比"这一推的 `before..after`"** ✓ ——
**不是"仓库里有什么"** ✗、**也不是"前几推带了什么"** ✗。
⇒ 我那次推的 diff **只有 `STATUS.md`** ✓（**rust 改动在**上一推**里** ✗）⇒ **过滤器报"无 rust"是对的** ✓。

**⇒ 规程（这是"发版推"的硬条件 ✓）**：**发版那一推必须自带过滤器认的路径** ✓：
```
crates/** · Cargo.toml · Cargo.lock · scripts/** · .github/workflows/**   ← rust ✓
editor/** ← editor ✓    courses/** · playground.sokonanoda ← courses ✓
```
⇒ **而"改 `.github/workflows/**` 也算 rust"** ✓ 是一条**很有用**的性质 ✓：
**修 CI 的推会自动触发重活** ✓ ⇒ **不用为了触发而造改动** ✓（**真实待办自己就是触发器** ✓）。

**⚠ 而一个"看起来很像"的错误结论** ✗：我一度推断是 **`git pull --rebase` 让 `before` 不可达** ✗
⇒ **错了** ✓（**快进推也一样** ✓）⇒ **真因是 diff 内容** ✓。
**⇒ 教训** ✓：**"这推带了什么"和"仓库里有什么"是两个问题** ✗ ——
**判据要问对**：`git diff --name-only origin/main...HEAD` ✓（**这一推的 diff** ✓）。

## 2026-09-26 · **整个 workflow 被 GitHub 拒绝：同一 step 里两个 `run:` 键** ✗

**症状** ✓：推上去的那一轮 CI **`completed/failure`、`jobs=0`、耗时 `0s`** ✗
—— **不是测试红，是 workflow 文件没通过校验** ✓。

**根因** ✓（**我的错** ✗）：我给 `ci.yml` 加"STATUS.md 瘦身 lint"那一步时，
把新的 `run:` **写进了上一个 step 的映射里** ✗ ⇒ 同一个 step 出现**两个 `run:` 键** ✗：
```yaml
      - name: 课程记法规则
        shell: bash
        run: python3 "$GITHUB_WORKSPACE/scripts/notation-lint.py"
        run: python3 "$GITHUB_WORKSPACE/scripts/status-lint.py"   # ← 同一个 step ✗
```

**为什么我没发现** ✓✓（**这条最贵** ✗）：我用 `python3 -c "yaml.safe_load(...)"` 验过 ✗ ——
**而 `yaml.safe_load` 对重复键不报错** ✗，**它静默取最后一个** ✗
⇒ 我甚至打印出"`status-lint` 出现 1 次 ✓" ✗ —— **那正是它把 `notation-lint` 顶掉了** ✗✓。

**⇒ 两个后果，第二个更糟** ✗：
1. GitHub 拒绝整个 workflow ⇒ 0 job、0 秒失败 ✗（**响亮** ✓，所以发现了 ✓）；
2. **如果 GitHub 接受它，`notation-lint` 会被悄悄关掉** ✗ ——
   **一条既有的课程门禁消失** ✗，而**本地看起来全绿** ✗✓。

**修复** ✓：拆成**独立的 step**（各自的 `- name:` ✓）。

**⇒ 新增守卫** ✓：**`scripts/ci-yml-lint.py`** ✓ —— 用**禁止重复键的严格 loader** ✓
（`yaml.safe_load` 不够用 ✗），并检查每个 job 有 steps、每步有 `run` 或 `uses` ✓。
已接进 **`scripts/ci-local.sh` 的 ⓪ 号阶段**（**最前面** ✓ —— 它是唯一能在 push 前拦住的地方 ✓）
与 **`ci.yml`** ✓。

**反向验证** ✓（**咬得住** ✓）：把重复键塞回去 ⇒
`ci-yml-lint：1 条不通过 ✗ - :518:9 YAML 不合法 ✗：重复键 \`run\`` ✓（**带精确位置** ✓）。

**预防** ✓：**改 workflow 之后，验证命令只能是 `python3 scripts/ci-yml-lint.py`** ✓ ——
**不要再用 `yaml.safe_load` 当门** ✗（**它连重复键都不报** ✗）。

## 2026-09-26 · **`status-lint` 挂在过滤过的 job 里 ⇒ 只改 `STATUS.md` 时它根本不跑** ✗

**症状** ✓：我把 `status-lint.py` 接进 `gates-fast` ✗ ⇒ 而 `gates-fast` 由 **`rust` 过滤器**驱动 ✓
⇒ **只改 `STATUS.md` 的推送不碰 rust 路径** ✗ ⇒ **`gates-fast` 被 `skipped`** ✗
⇒ **lint 永远不跑** ✗（**实测** ✓：`675491b` 只改 `docs/` + `STATUS.md` ⇒
那一轮 **15 个 job 里只有 3 个绿、其余全 `skipped`** ✓，含 `gates-fast` ✓）。

**⇒ 为什么这条最讽刺** ✗✓：**"只改 `STATUS.md`"恰恰是最常发生的情况** ✓
—— 每轮收尾都要改它 ✓ ⇒ **我加的那条守卫，在最需要它的场景下不跑** ✗
（**"咬不住的守卫等于没有"** ✓ 的又一个变体：**"不跑的守卫等于没有"** ✗）。

**修复** ✓：**独立的 `status-lint` job** ✓，**不设 `if:`、不加过滤器** ✓ ——
它只要 **~1 秒** ✓，所以**永远跑** ✓（**顺带避开"skipped 的依赖会拖垮 `auto-tag`"** ✗，
见 `changes` job 的注释 ✓）。同时**从 `gates-fast` 里撤掉那一步** ✓（**避免两处重复** ✓）。

**⇒ 顺带暴露的第二条** ✓：**`675491b` 那一轮 `success` 是"什么都没跑"的 success** ✗
（**3/15 绿、其余 skipped** ✓）—— 与 2026-09-25 记的那条**同一个形态** ✓：
**`paths-filter` 看的是"这一推的 before..after"** ✗，**不是仓库里有什么** ✗。

**⇒ 第三条（我自己又犯的）** ✗：**在 run 在飞的时候又推了一次** ✗
⇒ 顶层 `concurrency: cancel-in-progress: true` **把上一轮掐了** ✗
（`36207207425` ⇒ **`cancelled`** ✓，**6/27 绿** ✓）⇒ ⇒
**于是"验证 ci.yml 修复"的那一轮永远没跑完** ✗ ——
**要验证 `.github/**` 的改动，就得让那一推带 `.github/**` 路径** ✓，
**而且推完要等它跑完再推下一次** ✓。

## 2026-09-26 · **改 `editor/**` 永远不会跑真宿主 e2e：skipped 的依赖把它拖走了** ✗

**症状** ✓：`afceda9`（只改 `editor/vscode/src/test/extension.test.js` + docs）那一轮
**`success`** ✓，但 **5/16 绿、11 skipped** ✗ —— **三条 e2e 全 skipped** ✗
（而 `editor` job **success** ✓）。⇒ ⇒ **"success" 是"什么都没验"的 success** ✗。

**根因** ✓：`e2e` 的条件**本来是对的** ✓：
```yaml
    if: needs.changes.outputs.rust == 'true' || needs.changes.outputs.editor == 'true'
```
**但它还写着** ✗：`needs: [changes, lint-fmt, lint-clippy, gates-fast]`
—— 而 **`gates-fast` 的条件是 `rust == 'true'`** ✗ ⇒ **editor-only 推送时它 `skipped`** ✗
⇒ ⇒ **skipped 的依赖把 `e2e` 也拖成 `skipped`** ✗✓（**仓库里记过的那个坑，这次撞在自己身上** ✗）。

**⇒ 这是一个真洞** ✗：**改 `editor/vscode/**` 时，真宿主 e2e 一次都不跑** ✗ ——
而 `if:` 里写着 `|| editor == 'true'` ✓ ⇒ **本意是要跑的** ✓，**是 `needs` 列表把它废掉了** ✗。

**修复** ✓（**两条 e2e 一起** ✓）：**`!cancelled()` + 逐条"依赖没失败"** ✓
```yaml
    if: >-
      !cancelled()
      && (needs.changes.outputs.rust == 'true' || needs.changes.outputs.editor == 'true')
      && needs.lint-fmt.result != 'failure'
      && needs.lint-clippy.result != 'failure'
      && needs.gates-fast.result != 'failure'
```
⇒ **保留原意** ✓（**便宜门禁红了就别跑贵的** ✓），**同时让 skipped 的依赖不再阻塞** ✓。

**⚠ 过程中守卫又咬了一次** ✓：我第一次改用的锚点是那行 `if:` 本身 ✗ ——
而**它和 `editor` job 的那行一字不差** ✗ ⇒ **`assert count == 1` 拦住了** ✓
（**否则会误改 `editor`** ✗）⇒ **改成带 `name:` 的锚点** ✓。
⇒ **这就是"锚点必须先验唯一性"的价值** ✓（**`AGENTS.md` 里那条** ✓）。

**预防** ✓：**新增/修改 `needs` 时，先问"它会不会在本次路径下被 skip"** ✗ ——
**skipped 的依赖会让下游静默消失** ✗，而**整轮还报 `success`** ✗。
