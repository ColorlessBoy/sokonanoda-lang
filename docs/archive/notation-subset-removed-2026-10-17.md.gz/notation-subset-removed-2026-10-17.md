# notation 子集（G-04 / WO-011）——第一刀：`∈` / `⊆` / `∅` + 通用 `infix` ｜ 本文提到的 `docs/**` 指针都是**历史位置**（那批设计文档已收口删除）：原文 ⇒ `git log --all -- <path>`。doc-refs: history-only

> 状态：**已落地（as-built）**。工作单 `docs/gaps/WO-011-notation.md`；台账
> `docs/gaps/ledger.jsonl` 的 G-04。硬规则依据：`REQUIREMENTS.md` §2 第 3 条
> （语法增量 = 课程 + 测试 + 白名单三件套）、第 4 条（判定走内核）、第 1 条
> （当时口径 = 本项零内核改动；内核 2026-09-21 已解冻）。本文是白名单的**边界文档**：`docs/architecture.md` §4.1
> 只列命令清单，语义规则在这里。

## 记法符号上的 `documentHighlight` / `references` / `rename`（T-D24 的落地决定，2026-09-24）

**做**：**`documentHighlight`（文件内）** ✓
光标落在记法符号上时，给出**这个符号在本文里的每一处**（词法：喂符号表再收
`Sym(symbol)` token 的 span —— **不用子串匹配**，否则注释/字符串里的同形字符也会算进来）。
`lib/LSP` 侧只把 span 映射成 `Range`；扫描本身在**前端** `notation_input::symbol_occurrences`
（词法器与内建符号表都归前端所有）。

> **T-D30 的意图一条都不破**：先前的守卫是"光标在符号上 ⇒ 直接返回空"，
> 但它**真正**要防的是"把外层 binder 点亮"（binder 的 span 覆盖整段类型标注
> `(h : a ∈ A)`，旧回退会把 `∈` 解析成 `h`）。现在改成给符号自己的每一处，
> 判据也改成语义化的那条：**每一段被点亮的文本都必须就是符号本身**（不是"必须是空"）。

**不做（给理由）**：
* **`references`（跨文件）** ✗ —— LSP 的 `references` 是**项目级**语义，而记法符号的
  使用点要扫**闭包里每个模块**；那等于每次请求都把每个文件词法扫一遍 ✗，
  与本项目"性能是生命线"的取向冲突。**文件内**的需求已由 `documentHighlight`
  覆盖（同一个问题换个更便宜的问法）✓。
* **`rename`** ✗ —— 符号是**源级糖**：它的"名字"是记法**声明行里的字符串字面量**，
  而且同一个符号可能在**多个模块**里各声明一次（见 T-D23）⇒ 重命名必须同时决定
  "要不要改别的模块那条声明"、"要不要改声明里的字符串" ✗。
  真正自洽的功能是"重命名**目标常量**"（那属于标识符重命名，是另一件事）。
  今天的行为是**明确拒绝**（`InvalidParams`）✓ —— 安全且诚实 ✓，
  由 `a_notation_symbol_does_not_resolve_to_the_enclosing_binder` 钉住 ✓。

## 重载的落点：一个 `Location` 还是 N 个（T-D23 的落地决定，2026-09-24）

**问题**：同一个符号在**多个模块**里声明（或同一目标有多个符号），`definition`
该给一个落点还是全部？

**决定**：**一个** `Location`，取**闭包记法表里的第一个**（`notation_at` 的
`.find`）。理由：
1. 展示层的折叠规则**已经是**"同一 target 声明了两个符号 ⇒ 取声明顺序第一个"
   （`notation.rs` 头部注释）——导航与展示用**同一条**约定，用户看到的故事才自洽；
2. "跳到定义"这个动作的预期是**一个**落点；给菜单是另一件事（`documentHighlight`
   才是"所有相关位置"的语义）；
3. 顺序是**确定的**（闭包表的顺序 = 拓扑序 + 声明序），不是哈希序。

**判据**：`crates/lsp/src/tests/navigation.rs::an_imported_user_notation_symbol_resolves_into_its_module`
（跨模块的常见情形：import 进来的用户符号 ⇒ 落到**声明它的模块**）+ 真 LSP 探针
`docs/gaps/repro/G39-imported-user-notation-has-no-navigation.js`。

**⚠ 这条清单项顺带挖出一个真 bug（G-39，已修）**：`notation_at` 原来用
`notation_input::symbol_at`（只看**输入表 + 本文件声明**）⇒ **import 进来的用户
自定义符号**（`⊗`）在使用它的文件里**认不出来**，导航全 `null`。
**既有跨文件用例没抓到**——它用的 `∈` 恰好在输入表里（`\in`），
**夹具选得太顺手，把整条路遮住了**。修：改用闭包感知的 `symbol_at_with_sources`。

## `scoped` 记法的导航跟不跟作用域（T-D22 的落地决定，2026-09-24）## `scoped` 记法的导航跟不跟作用域（T-D22 的落地决定，2026-09-24）

**背景**：`notation_input` **刻意忽略 scoping**（`docs/design/notation-input.md`
§10 偏差 3）——那是给**输入提示**用的：输入法是**全局**的，`\in` 在任何地方都该
提示得出来，跟"这个文件 import 了谁"无关。

**决定**：**导航跟作用域，输入提示不跟 —— 两者的偏差是有意的**。
1. **导航**（`definition`/`hover`）**以作用域为准**：闭包记法表（import 进来的）
   + 本文件声明 + 内建。三者都没有 ⇒ **返回 `null`**，**不许**因为"词法上认得出
   它是个符号"就编一个定义出来；
2. **输入提示**保持全局（不动）——用户敲 `\in` 时想要的是"怎么打这个符号"，
   不是"这个文件里能不能用"。

**判据**：`crates/lsp/src/tests/navigation.rs::a_notation_symbol_out_of_scope_is_not_resolved`
—— 建一个真临时项目（`SetLib` 声明 `∈`、入口**不** import 它），断言
`textDocument/definition` 返回 `null`。

## 跨文件记法的"定义"落在哪（T-D21 的落地决定，2026-09-24）## 跨文件记法的"定义"落在哪（T-D21 的落地决定，2026-09-24）

**问题**：`∈` 声明在 `lib/Set`，用在 unit —— 定义是**库的那一行 `infix`**，
还是入口的 `import` 行？

**决定**：**库的那一行 `infix`**（记法真正的声明点）。理由：
1. 用户问"这个符号是什么、谁定的"时，要看的是**声明**，不是"我把它引进来了"；
2. `import` 行只说明**传播**（设计 §10.3），一个符号可能有多个 import 点，
   而声明点**唯一**；
3. 与 T-D12/T-D13 的既有实现一致（`notation_at` 给出**模块 + 那一行的 span**）。

**判据**：`crates/lsp/src/tests/navigation.rs::goto_definition_on_a_notation_symbol_lands_on_its_declaration`
—— 它建一个真临时项目（`SetLib.sokonanoda` 声明 `∈` + `Canvas.sokonanoda` import 它），
断言跳转结果的 `uri` 是**库文件**（`assert_eq!(uri, lib_uri, "要跳到**声明它的模块**")`）。

## 内建 / prelude 目标的导航（T-D20 → **2026-10-10 重写**）

**T-D20（2026-09-24）当时的决定**：`∧`→`And`、`=`→`Eq` 的展开目标是**内核 prelude
名**，**没有源码声明**（`top_level_def_spans` 按构造排除 prelude）⇒ ① `definition`
返回 `null`（编一个目标是撒谎）；② hover 说明「内建记法（内核 prelude）：**没有源码
声明**，`F12` 无处可跳」；③ 判据断言那一行存在。

**⚠ 那份决定今天只剩"不编位置"这一半还成立**（用户 2026-10-10 反馈）：

* **`=` 不是"没有声明点"，是三处故意特例的叠加**：词法原生分支（`parser.rs` 的
  `LEXER_NATIVE_SYMBOLS`，**永远不许动** ✗ —— `=` 进符号表会把 `=>` 吃成 `=` + `>`）·
  旧注释**不登记**它 · `span.start.offset != 0` 的闸门 ⇒ F12 **无声返回 `null`**
  （既不报错也不跳）✗；
* **hover 那句话在 E10 之后是假话**：`∧ ∨ ↔ ¬ ≠` 早有 prelude 登记行
  （`-- sokonanoda:builtin-notation "∧" => And`）、F12 **真的跳得到** ⇒ hover 与
  `definition` **当场自相矛盾** ✗（同一份读数里 F12 落 prelude、hover 说无处可跳）。

**今天的决定（2026-10-10）**：

1. **对称**：prelude 登记区补一行 `-- sokonanoda:builtin-notation "=" => Eq` ⇒ **6 条
   内建记法全都有声明点**。⚠ 登记行是**注释**、只被 `notation::builtin_directive_span`
   做**纯文本查找** ⇒ **不喂词法**、对 `=>` 的分词**零影响** ✓ —— 旧注释把「注释登记行」
   与「喂词法的符号表」**混为一谈**，那正是 `=` 被漏掉的成因 ✗（两处注释已同轮更正）。
2. **项目无关的兜底**：`QueryDoc::notation_at` 只在**项目模式**下工作 ⇒ 单文件里
   `=` 无声 `null`、`∧` 更糟（落到 `definition_at` 的 `Notation` 分支，`range` 用
   **光标处**那个 span ⇒ **原地跳** ✗，E05/G-37 同一条教训）⇒ `definition` 加一条
   `notation::builtin_declaration_span(symbol)` 兜底（与记法表**同一份 span** ✓）。
3. **第二跳（注释登记行里的目标名）**：`=> And` 那个名字以前三条消费者全 `null`
   （F12 / hover / documentHighlight）—— **注释不产生 token**，词法扫描永远认不出 ✗，
   与 `docs/gaps/repro/G23-notation-navigation.js` 白纸黑字的**两跳模型**矛盾。
   `notation_input::notation_target_at` 现在**两种形态都认** ✓（声明形态 + 注释形态），
   名字解析走**已有真相通道**：`project_definition` → `prelude_def_span`
   ⇒ `And` 落 `inductive And`、`Eq` 落 `axiom Eq` ✓（**不做文本比对** ✓）。
4. **hover 说今天的事实**：内建记法 ⇒「声明点是 prelude 里那行登记注释，`F12` 落到
   `prelude/Prelude.sokonanoda`」；`builtin-sugar` / `builtin-rust` 的目标名 ⇒ 说清
   **为什么**给不出签名 / 没有落点（诚实说明 ≠ 静默 ✓）。
5. **判据**（三层，都断言**用户实际点的字符位置**与**落点行号**，不许只断言"非 null"）：
   front `notation_input::target_resolution_tests::a_comment_registration_target_name_is_found_at_its_own_offset`
   （含反向：注释里别的词 ⇒ `None`）·
   `notation::span_tests::builtin_notations_carry_their_directive_line_as_the_declaration_site`
   （**6 条**，`=` 不再豁免）· `prelude_mirror::builtin_notations_reach_the_closure_notation_table`
   （闭包表 **6 条**）；LSP `navigation::goto_definition_on_the_equals_notation_lands_in_the_prelude`
   / `..._in_a_project_lands_in_the_prelude` /
   `goto_definition_on_a_comment_registration_target_lands_on_its_definition` ·
   `hover::hover_on_the_equals_notation_no_longer_claims_there_is_nothing_to_jump_to` /
   `hover_on_a_comment_registration_target_name_explains_itself` /
   `hover_on_a_builtin_rust_registry_name_explains_the_missing_span` ✓。

**同族边界（本轮逐条表态，别只修单点）**：

* `builtin-sugar` 的 `Set.singleton` / `Set.pair` / `Set.sep`：目标是**卷 I 课程库常量**，
  在 prelude 文件自己的闭包里解析不到 ⇒ F12 **诚实 `null`**，但 hover **说明原因** ✓；
* `builtin-rust` 的 `Nat`/`Bool` 两族 9 个名字：`prelude_def_span` 如实是 `None`（E2）⇒
  F12 **诚实 `null`**，hover 说明「内核按名字安装、源文本里没有声明位置」✓；
* 登记行**字符串里的符号**（`"∧"`）：F12 的落点只能是**那一行自己**（内建记法没有第二个
  源位置）⇒ 必然**原地跳** ✗（E05/G-37 的教训）⇒ **不做**；hover 在注释里保持静默
  （台账 G-55 notes ② 仍建议另立一条）；
* `notation.rs::builtin_directive_span` 的**列按字节**（`∧` 那行整行 span 的 end 列多 2）：
  本轮**不动** —— 它只影响整行 range 的 end 列，落点**行号**判据不受影响；真要修得另立
  一条带列断言的判据（别顺手改没有判据的行为 ✗）。

**判据实现的一个坑（记下来）**：内建符号在**闭包记法表里查不到**时
（`QueryDoc::notation_at` 返回 `None`），**不能**用「既不是本文件声明的、也不来自任何
模块」来**反推**它是内建 —— `∈` 没 `import` 库时同样满足那个条件 ✗。今天的判据直接问
内建表：`notation::is_builtin_notation` ✓。

## ## 0. 一句话

记法（notation）是**糖**：parser 只把 `lhs ∈ rhs` 记成一个带目标名的记号节点，
elaborator 把它**源到源**降级成既有的 `App` 形状。点名形式（`Set.mem α a A`）
一字不改、继续可用；**显示侧的 print-back 已另立线 C**（0.65.0 起 goal/hover 的类型文本折记法，见 §附；本节说的是**判定契约**不含打印文本）
内核的 pp 产出点名形式）。

## 1. 为什么不能只改 parser（WO-011 附 A 的三条实测事实）

第一刀的目标是「core 级最小记法集 `∈`/`⊆`/`∅` 可用」。真做起来会撞到三件事，
全部是 WO 里实跑出来的：

1. **词法层没有字符串 token**。`"` 直接落进 `token.rs` 的 `other =>` 臂报
   `unexpected-token`——记法命令的符号根本读不进来。
2. **符号字符今天是标识符字符**。`is_ident_start` 把 `≥0x80` 一律当标识符首字符，
   所以 `a∈b` 是**一个** `Ident`（实测 `unknown identifier \`a∈b\``）。
3. **`∈` 藏着一个类型参数**。课程库是
   `Set.mem (α : Type) (a : α) (A : Set α) : Prop`，而本语言**不插入隐式实参**
   （`mem2 x s` 被内核拒绝、`mem2 T x s` 通过）⇒ 记法**不是纯 parser 糖**：
   展开路径必须自己补前导 `Type` 参数，否则 `infix:50 " ∈ " => Set.mem` 会把
   `a ∈ A` 展开成一个被内核拒绝的项。

## 2. 语法边界（v1 语义规则，逐条可测）

### N1 命令形状

白名单只加**四个拼写**：

```
infix:N  " sym " => name      -- 无结合，两边同级
infixl:N " sym " => name      -- 左结合
infixr:N " sym " => name      -- 右结合
notation " sym " => name      -- 零元常量记法（∅）；不写优先级
```

- `N` **必填**（`infix` 族），合法范围 **1–1000**（严格落在 `->` 与函数应用
  之间）；越界给专用诊断 `parse-notation-precedence`，不静默取整。
- 符号是**字符串字面量**；v1 取 `trim` 后的内容，两侧空格是书写习惯
  （Lean core 逐字都带空格）。符号**不得**为空串，**不得**是标识符词
  （`"in"` 会被当成普通标识符读走，记法永远不可能命中）。
- 目标 `name` 是**点名**（可带 `Set.` 前缀，走既有点分名字解析）；未知目标
  在 elaborate 期给专用诊断。
- 目标**必须已经声明**（文件内、声明之后，见 N5）。

### N2 使用

`lhs sym rhs` 只要求在**同一文件、记法声明之后**（N5）；操作数顺序**保持**
（与 Lean `infix` 糖一致）。core 的 `∈` 是**显式 `notation` 并交换操作数**
（`Membership.mem b a`），那需要具名占位（`notation:50 a:50 " ∈ " b:50 => …`）
——**第二刀**。第一刀用保序 `infix:50 " ∈ " => Set.mem` 对准课程库的
`Set.mem (α) (a) (A)`。

### N3 优先级梯子

所有记法算子与内建 `+` 共用**一条优先级梯子**，位置在 `parse_arrow`（`->`，
最松）与 `parse_app`（函数应用，最紧）之间——今天的 `parse_plus` 就在这个缝里。
`+` 作为**内建保留项**进梯子，优先级 **65**，并**逐字节保持今天的行为**
（仍产出 `Expr::Plus`）。

| 结合 | 左操作数最小优先级 | 右操作数最小优先级 |
|---|---|---|
| `infix`（无结合） | `p` | `p + 1` |
| `infixl`（左结合） | `p` | `p + 1` |
| `infixr`（右结合） | `p + 1` | `p` |

> 取证状态：`infix`/`infixl`/`infixr` 的**精确脱糖**（左右是 `p`/`p`、
> `p`/`p+1`、`p+1`/`p`）**未从 Lean 源码逐字取证**（WO-011 待确认 1，写 WO 时
> 无网络）。仓库里逐字取证的只有 `infix:50 " ⊆ "`、`infixl:65 " ∪ "`、
> `infixr:80 " '' "` 三条**声明行**（`prior-art-report.md` §1.3）。上表是 v1
> **自定的规则**，实现与测试都钉它。
>
> `+` 在 Lean core 的优先级**未取证**（待确认 2，记忆中是 `infixl:65`）。
> v1 的实现不依赖这个数：`+` 行为逐字节不变（仍产出 `Expr::Plus`），这个数
> 只影响 `a ∈ A + B` 这类混写的分组——v1 里 `+` 走**同一条爬升**、优先级 65。
> 记法符号的**默认优先级**（`notation` 不写 `:N`）对**零元**记法无意义（没有
> 左右操作数），所以 v1 只在 `infix` 族要求 `N`。

`infix`（无结合）**不做** Lean 的「优先级冲突报错」语义：v1 用固定规则——
同级同符号连写（`a ∈ b ∈ c`）是**解析错误**（`infix` 无结合 ⇒ 右操作数要求
`p+1`，同级不再吃），不同符号同级按**左结合**处理。设计取舍：把 Lean 的
「同级混用需要括号」那套诊断留到第二刀（WO「不做的事」）。

### N4 展开（本设计核心）

1. 展开发生在 **elaborate 阶段**（不是 parser）：parser 只把 `lhs sym rhs`
   记成 `Expr::Notation { symbol, precedence, assoc, lhs, rhs, target, span }`；
   elab 把它**源到源**降级成既有的 `App` 形状，之后 elab/hover/kernel/事件
   全部复用既有路径。
2. **补全只允许发生在记号展开路径**：目标 telescope 比操作数多出来的**前导
   参数**按 **① 由操作数解出 → ② 无操作数时由期望类型解出** 的顺序补。
   可实现的形态是**裸变量匹配**：
   - `Set.mem : (α : Type) → (a : α) → (A : Set α) → Prop`，第 2 个参数的
     类型就是裸变量 `α` ⇒ `α := typeof(a)`；
   - `Set.empty : (α : Type) → Set α`，结果类型 `Set α` 对上期望 `Set α₀`
     ⇒ `α := α₀`。
   **不支持**一般合一/元变量。解不出给专用错误码
   `elab-notation-argument-unsolved`（hint 直接教怎么写点名形式）。
3. **回归护栏（兼容性的护城河）**：`Set.mem a A`（点名、省 `α`）**今天被内核
   拒绝，改后必须仍被拒绝**——补全只挂在记号路径上，不改变任何既有程序的语义。
4. 不许动内核：展开只产出 `mk_const`/`mk_app`。

**类型参数求值的实现路径（as-built）**：前导参数的值 = `judge_infer` 问内核
（合成 `#check fun <当前 binder 上下文> => <操作数>`，取 `TypeChecked` 文本再
剥掉 binder 层）。补全后的**完整应用**再交给既有 `elab_expr`（`Expr::App`
链）走正常路径——所以类型错、`@`、宇宙参数等既有语义**一字不改**地复用。
**操作数先 elaborate、类型参数后补**（as-built，实测钉在
`crates/cli/tests/protocol.rs::notation_diagnostics_stage_as_parse_and_elab`）：
- 操作数本身是未定义标识符 ⇒ 既有的 `elab-unknown-identifier`（那条诊断更准，
  不遮成记法错误）；
- 操作数都合法、但类型参数补不出来（例如 `#check ∅`）⇒
  `elab-notation-argument-unsolved`，hint 指向点名写法。

### N5 作用域：文件内、声明之后（file-local）

跨 `import` 的记法**第二刀**。依据：项目闭包加载时**先 `parse` 当前文件、再收集
import 边**（`project/graph.rs`），所以「记法写在 `lib/`、`units/` 直接用」今天
拿不到：入口文件 parse 时还不知道依赖里声明了什么。做跨模块要么改闭包加载顺序、
要么二次 parse——两条路的代价都写在这里，留给第二刀定。

因此：**文件内、记法命令之后**。在记法声明**之前**使用该符号 ⇒ 未声明符号诊断
（`parse-notation-unknown-symbol`，hint 给「先声明」与「点名写法」两条出路）。

> **第二刀（0.60.0）把这一条拆成两半**：**本文件自己**的记法仍然"声明之后才
> 生效"；**被导入模块**声明的记法**从文件头就可用**（与 Lean 的 import 一致，
> §10.3）。

### N6 记法不产生事件、不是声明

`infix`/`notation` 命令**不**产生 `decl.checked`/`exercise.open`/`expr.typed`/
`expr.reduced`，也**不进声明表**（与 `Command::Import` 同族：有命令、无声明）。
⇒ 既有两个课程的 GOLDEN 计数**不变**（§5）。

### N7 教学契约（验收的语言）

同一命题的两种写法——点名 `Set.mem α a A` 与记法 `a ∈ A`——**判卷结果一致**
（`grade` 退出码一致 + 五元事件计数一致），且**点名形式继续可用**。
契约**不含「打印文本一致」**：目标/hover 的类型文本由**显示边界重写**（`front::display::print_back`，0.65.0 起折记法）产出，
会显示点名形式。

## 3. 词法设计（as-built）

### 3.1 两个新 token

| token | 触发 | 说明 |
|---|---|---|
| `Str(String)` | `"` … `"` | 字符串字面量；**只**给记法命令用（表达式里没有字符串）。未闭合 ⇒ 专用诊断 `parse-unterminated-string`，span 指向**开引号**的行列 |
| `Sym(String)` | 数学符号码点（见下） | 记法符号 token；最大吞噬（连续符号字符算一个 token） |

### 3.2 数学符号码点类

`is_ident_start` 收窄为「`≥0x80` **且不属于**数学符号码点集」。第一刀取：

- `U+2200–U+22FF`（数学算子：`∈`U+2208 / `⊆`U+2286 / `∅`U+2205 / `∪`U+222A /
  `∩`U+2229 / `∘`U+2218 都在内）；
- `U+2A00–U+2AFF`（为第二刀的 `⋃`/`⋂` 预留）；
- `\`（U+005C）：今天直接是词法错误，改为 `Sym("\\")` ⇒「未声明符号」诊断
  比「不是一个合法 token」更教学。

**希腊字母/数学斜体字母仍是标识符字符**（`α`、`α'1` 逐字不变，`token.rs` 的
`non_ascii_identifiers_lex_as_ident` 守住）。`∀`（U+2200）在**码点类之内**，
但它今天就是一个 token（`TokenKind::Forall`），所以 `next_token` 的
`'∀' => self.single(TokenKind::Forall, …)` 臂**必须留在符号分支之前**——
否则 `∀` 会变成 `Sym("∀")` 而 `forall` 关键字失效。这条由
`forall_is_a_keyword_but_prefixed_idents_are_not` 与
`turnstile_and_forall_keep_their_own_tokens` 两条测试守住。

### 3.3 已知差异（对我们更宽松）

符号码点类切分让 `x∈A`（**无空格**）可用——比「要求两侧空格」更强。
「Lean 里也一样」这句话**没有取证**（WO 待确认 3）；这里记成
**我们更宽松**的已知差异。

### 3.4 `⊢`（U+22A2）与 `𝒫`（U+1D4AB）

- `⊢` 落在 `U+2200–U+22FF` 里 ⇒ 词法层变成 `Sym("⊢")`。它**不是**源语言
  token（goal 面板的 turnstile 是**渲染文本**，不是源码），所以
  `front::semantic::tag_runs` 必须把 `Sym` 归到**不产 run**（与 `->`/`=>`
  一致）——否则 goal 文本 `⊢ a` 会被当成「未声明符号」。既有测试
  `goal_runs_projects_to_hypothesis_lines_then_turnstile` 里
  「turnstile stays a plain run」这条断言**原样保留**，正是这条的守护。
- `𝒫`（U+1D4AB）与 `ᶜ`（U+1D9C）是 Unicode **字母**（数学斜体/修饰字母），
  不在符号类里 ⇒ 仍是标识符字符。第二刀不能用符号类处理它们，需要声明驱动的
  词法或专门 token（WO 待确认 4）——**第二刀选了声明驱动的词法**，见 §10.2。

## 4. 命令 / AST / 分发的落点（as-built）

| 层 | 文件 | 落点 |
|---|---|---|
| lexer | `crates/front/src/token.rs` | `TokenKind::{Str, Sym}`；`"` 分支；符号分支；`is_math_symbol`/`is_ident_start` 收窄；`lex_string` |
| parser | `crates/front/src/parser.rs` | 四条命令臂 + `parse_notation_command`；`is_reserved_command` 加四个拼写；`parse_operators(min_prec)` 取代 `parse_plus`（`+` = 保留项 65）；`starts_atom` 让 `Sym` 让路 |
| AST | `crates/front/src/ast.rs` | `Command::Notation { symbol, precedence, assoc, target, span }`、`Expr::Notation { … }`、`NotationAssoc { Infix, Infixl, Infixr, Nullary }`；`span()`/`is_import()`/`import_module()` 补臂 |
| elab | `crates/front/src/compile/elab.rs` | `Expr::Notation` 臂：`desugar_notation` → 裸变量匹配补全 → 复用 `elab_expr` |
| elab 错误 | `crates/front/src/compile/error.rs` | `ElabNotationUnknownTarget`、`ElabNotationArgumentUnsolved` |
| parse 错误 | `crates/front/src/diagnostic.rs` | `UnterminatedString`、`NotationShape`（缺优先级/缺 `=>`/符号非法/重复声明）、`NotationUnknownSymbol` |
| 分发 | `check/walk.rs`、`check/mod.rs`、`warning.rs`、`goals.rs` | `Command::Notation { .. } => {}`（无声明、无 PendingOp、不进声明表） |
| 分发 | `session.rs`、`lsp/src/lib.rs` | 已由 `_ => None` 兜住（已确认，无需改） |
| semantic | `crates/front/src/semantic.rs` | `Names.notations: HashMap<String, SemanticKind>`；`Command::Notation` 登记符号 + 目标名（`DefUse`/`TheoremUse`/…）；`TokenKind::Sym` 分类：**已声明 → Keyword**，未声明 → `continue`（不产 run）。**不新增 `SemanticKind`**（`ALL` 与 `tm_scope` 表逐字不变） |
| print-back | `crates/front/src/proof.rs` | `render_expr(Expr::Notation)` 渲染成 `lhs sym rhs`（带括号规则）；`render_atom`/`render_fun_position` 视 `Notation` 为复合式 |
| pp 复读 | 全部 `parse_expr_text` 调用点 | 内核 pp **不会**产出记法，所以回读路径不受影响；但 `render_expr` 的往返测试要能处理记法（新增，不改变既有） |
| hover | `crates/lsp/src/render.rs` | 记号节点整段 `lhs sym rhs` 一条 hover 行（`record_hover` 的 span 是记号节点 span）；**`resolution` 从 v0.65.3 起不再留空**——记法符号是 `ResolvedTarget::Notation { symbol, span, module }`（T-D15），`span` 是**符号自己**（T-D14 的 `Expr::Notation.symbol_span`） |

### 4.1 编辑器支持（as-built，2026-09-21 线 D 收口）

> 这一节是**用户第 6 条反馈**（"notation 不能跳转 / hover 没有原始类型"）的
> as-built 记录，缺口 **G-23 已关账**。

| 能力 | 实现 | 判据 |
|---|---|---|
| **跳转到定义** | `goto_definition` 在 `definition_at` **之前**先试记法分支：`QueryDoc::notation_at(text, offset)`（闭包记法表，词法精确）+ `module_path(module)` → `Location` | LSP `goto_definition_on_a_notation_symbol_lands_on_its_declaration`；e2e #7；`docs/gaps/repro/G23-notation-navigation.sh` ⇒ exit 1 |
| **hover：展开成什么** | `notation_symbol_hover`：`展开成 \`Set.mem\`` + `\`Set.mem : <签名>\``（签名走内核 `judge_type_of_constant`，自带常量键缓存） | hover 三条（本文件声明 / 内建 / `import` 来的） |
| **hover：精确范围** | `range` = `notation_input::symbol_span_at`（与 `symbol_at` **共用** `symbol_token_at`，不会漂移） | `a_notation_hover_range_covers_only_the_symbol`（`⁻¹'` 中间落点，正好 3 字符） |
| **highlight / rename** | 记法符号**不是名字**：`definition_name_span` 对 `Notation` 返回 `None` ⇒ rename 被拒；`documentHighlight` 在符号上返回空（不误命中**外层 binder**——binder 的 span 覆盖整段类型标注） | `a_notation_symbol_does_not_resolve_to_the_enclosing_binder`（LSP + front 各一条，带"定义点仍可解析"的对照） |
| **`resolution` 不被覆写** | 装配期的"回填顶层声明 span"**只**作用于 `Declaration` 变体 | `a_notation_hover_row_keeps_its_notation_resolution_after_assembly` |

## 5. 影响面（事件计数 / golden）

- 事件种类与计数**不变**（记法命令不是声明，N6）⇒ **双 GOLDEN 不改**：
  `crates/cli/tests/course.rs`、`crates/cli/tests/course_status.rs`。
- 全仓 `.sokonanoda` 里这些符号只出现在注释里（复现件除外）；`infix`/`notation`
  作为标识符 0 命中 ⇒ 词法/命令表的改动**不可能翻动任何现成用例**。
- `playground.sokonanoda` anchor：无符号、无 `infix` ⇒ 不变。
- 唯一 golden 面 = 新增测试自身 + 本文件里写死的优先级表。

## 6. 与 Lean 的已知差异（v1 明说，不假装对齐）

| # | 差异 | 依据 |
|---|---|---|
| 1 | `infix` 族的脱糖是**自定**的 `p/p+1`、`p+1/p` | 待确认 1（无网络，未取证） |
| 2 | 不做「同级混用报错/需括号」的 Lean 诊断；同级左结合 | WO「不做的事」 |
| 3 | `x∈A`（无空格）可用——**我们更宽松** | 待确认 3 |
| 4 | `notation` 不接 `:N`；`infix` 族 `N` 必填 | 待确认 6 |
| 5 | ~~记法**不跨 `import`**（Lean 里全局）~~ **已修（第二刀，0.60.0）**：记法随 `import` 传播，见 §10.3/§11.7 | N5 + 闭包加载顺序 |
| 6 | ~~重复声明同一符号是**错误**（Lean 允许重载）~~ **已升级（第三刀 §14.2）**：同符号、**同形状**（结合性 + 优先级一致）= 记法重载（按期望类型选候选）；**不同形状**仍是错误；重声明 **import 来的**符号仍是错误（§11.8 原样保留） | 待确认 5；v1 自定，第三刀改 |
| 7 | 记号路径**先解操作数、后补类型参数**：操作数未定义时报既有的 `elab-unknown-identifier`，只有"操作数合法但补不出参数"才报 `elab-notation-argument-unsolved` | §2 N4 的 as-built |

## 7. 第二刀（明确不在本轮）——**已落地，见 §10–§12**

> 本节是第一刀时写下的清单，保留原文以便对照；每一项的销账情况见 §12。
> `𝒫`/`ᶜ`/`''`/`⁻¹'`/`×ˢ`、跨 `import`、`prefix`/`postfix` 已在 0.60.0 落地。

- **Mathlib 级 + 其它形状**：`𝒫`（`prefix`，且 `𝒫` 是 Unicode **字母**）、
  `''`/`⁻¹'`（`infixr` + `'` 与今天的标识符续接字符冲突）、`×ˢ`（`infixr`，
  且 `×` U+00D7 不在数学算子区）、`⋃ i,`（`notation3` + binder）、
  `∪`/`∩`/`\`（形状同 `infixl`/`infix`，词法已就位）、`ᶜ`（postfix，U+1D9C
  同样是字母）、`scoped`/`open scoped`、集合字面量 `{a}`/`{a,b}`。
- **跨 `import` 的记法传播**。
- ~~**print-back（源码级 pp）**：goal/hover/错误文本里的类型继续显示点名形式。~~ **⛔ 本条已被用户需求取代（2026-10-15 ✓，不是"以后再说"）**：① **前半句早已不成立**（线 C 从 0.65.0 起就让 goal/hover/错误文本折记法，见 §附 与 `docs/design/notation-aware-printing.md`；本行是 §7 这份第一刀清单的**原文遗留**，一直没回改 ✗）；② **后半句由用户 2026-10-15 15:22 明确推翻**：`#check <裸 def 名>` 现在印**声明卡片** `def <名字> : <类型> := <定义体>`（类型与定义体**都**过 `fold`，类型那一半再过 `lean4_universe_text`），**刻意偏离 Lean 4**（Lean 的 `#check id` 只打 `.signature c`）——用户同日 15:2x 授权：「**`#check` 我是新加需求，偏离 lean4 没问题**」；**边界**：只给 `def`（`theorem`/`axiom`/`inductive`/构造子/递归子仍只打签名 ✓）、`#print` 一个字节未动 ✗、判定路径读的 `inferred_type` 也一个字节未动 ✗；权威条目 `REQUIREMENTS.md` **§9.22**，判据 `crates/cli/tests/check_def_card.rs`。
- **binder 记法**（`∃ x,`、`∀ x ∈ s,`）：台账 `notes` 原话「另立」。
- **一般隐式实参推断**（`mem2 x s` 这类点名省略仍然报错，N4.3 是护城河）。
- **`_` 占位符 / 元变量 / 一般合一**。
- **`macro`/`syntax`/自定义 parsing 框架**：v1 只有「命令 → 算子表」一条硬编码
  路径。

## 8. 测试（三层，TDD）

1. **front 单测**：`token.rs`（`Str`/`Sym` 切分、未闭合字符串、`α'1`/`∀` 回归）、
   `parser.rs`（四条命令形状 + 优先级梯子 + `+` 逐字节不变 + 未声明符号 +
   `infix` 无结合连写报错）、`compile/tests.rs`（两种写法事件一致；点名省 `α`
   仍被拒的护城河；`∅` 在无期望类型处 `elab-notation-argument-unsolved`；
   未知目标；声明之前使用）、`semantic.rs`（声明的符号 → Keyword、未声明不产
   run、`ALL`/`tm_scope` 逐字不变）。
2. **CLI e2e**：`crates/cli/tests/notation.rs` —— 同一命题两种写法各一个文件，
   跑 `--json`，断言五元组 `(decl.checked, exercise.open, expr.reduced,
   expr.typed, diagnostic)` **逐一相等**且 `exit 0`；断言事件种类集合没有新增。
3. **课程用例**：靶子 `courses/set-theory/units/I.1/unit02-subsets-empty.sokonanoda`
   的练习 2 `subset_trans` 与练习 4 `empty_subset`（答案不入库）。做法：把该单元
   连同 `lib/`、`sokonanoda.toml` 复制到临时目录，在**副本**里加记法行、把两条
   声明改成记法版，用绝对路径判卷；断言 `grade` exit 0 且事件计数与原点名版
   逐项相同。**本 WO 课程零改动**由 `python3 courses/set-theory/tools/check.py`
   全绿 + `git status` 里 `courses/` 无改动共同守护。
   > **这一条只对 WO-011 那一轮有效**（它是"记法只是糖"的对照实验）。R2 课程
   > Lean 化之后画布改用记法，契约翻转为"两种写法仍同判"——见 §15。

守护表行（`docs/TESTING.md`）：词法切分 / 优先级 / 两种写法计数一致 /
护城河（点名省 `α` 仍被拒）/ 课程门禁全绿。

## 9. as-built（2026-09-19 落地，第一百〇五轮）

设计里的 N1–N7 全部按上面落地；这一节只记**实现时才暴露出来的事实**。

1. **`∅ ⊆ A` 逼出了"操作数也要吃期望类型"**。第一版只给整条记法一个期望类型，
   于是嵌套的零元记法 `∅` 解不出 `α`（实测 `elab-notation-argument-unsolved`，
   课程用例红）。修法是 `notation_operand_expected`：从被调用者的望远镜里按
   下标取出每个操作数的期望类型（`Set.subset` 的第 1 个参数是 `Set α`），
   逐个传进 `elab_expr` 的 `expected` 槽。**这条是"期望类型传播"在记法里的
   具体形态**，将来做一般隐式实参时应能整段替换掉。
2. **展开必须直接构造内核项，不能"再 elaborate 一遍"**。第一版把补好参数后的
   源级 `Expr::App` 交回 `elab_expr`，结果操作数被 elaborate 两次、且类型在
   `Expr`/`ExprPtr` 之间来回搬（编译错 E0308）。现在 `elab_notation` 直接
   `builder.mk_const` + `builder.mk_app` 逐个挂参数，操作数各 elaborate 一次。
3. **操作数先 elaborate ⇒ 未知操作数报的是 `elab-unknown-identifier`**，不是
   记法专用码。设计初稿曾以为会报 `elab-notation-unknown-target`；实测这条只在
   **目标名写错**（`=> Set.men`）时出现。**这是更准确的诊断**（错的是那个名字，
   不是记法），已记进 §6 的已知差异表第 7 行。
4. **`elab-notation-unknown-target` 在声明行不会触发**——目标名在**使用点**解析。
   所以它的回归测试必须"声明一个拼错的目标 + 真的用一次"，只写声明行是绿的。
5. **`notation` 不带 `:N`**：零元记法走 `starts_atom` 的 `Sym` 分支（只有声明过的
   零元符号才让路），没有优先级可写；`notation:N` 报 `notation-shape`。
6. **`query`/`protocol` 的既有夹具里那条 `infix:50 " e " => mem`** 是"随便写的
   不可解析文本"，记法落地后它变成了**有意义的教学诊断**（`notation-shape`：
   符号 `e` 全是标识符字符）。三处夹具改成 `def p : Prop := (a`（真正的语法错），
   `query.rs` 的偏移量随之从 15/21 改成 19/19。**这不是放宽判据**：改后的夹具
   仍然是不可解析的文件，`query check` 仍然必须报 parse 诊断 + exit 1（G-10）。
7. **`infix`/`infixl`/`infixr`/`notation` 四个拼写进了 `KEYWORDS`**（语义高亮 +
   TM 语法），但**没有**新增 `SemanticKind`：声明过的符号复用 `Keyword`。
   因此 `SemanticKind::ALL`、`tm_scope` 表、`crates/cli/tests/extension.rs` 的两个
   词表锁**全部逐字节不变**——只在 TM 语法里加了一条**数学符号规则**
   （`keyword.operator.sokonanoda`，`U+2200–22FF`/`U+2A00–2AFF`/`\`）。
8. **课程用例用临时副本**：`crates/cli/tests/notation.rs::a_real_course_unit_grades_identically_in_notation`
   把 `courses/set-theory/{lib,sokonanoda.toml}` 复制到 `/tmp`，再写一份改写了两处
   签名的单元②。实测两份都是 `{exercise.open: 10, decl.checked: 1}`、exit 0。
   `the_shipped_course_still_uses_the_pointful_spelling` 把"课程零改动"钉住。
   > **R2 课程 Lean 化轮次已翻转**：画布现在是记法版，两条测试都改了名与方向
   > ——见 §15。

---

# 第二刀（G-04 剩余项，0.60.0）——`prefix` / `postfix` + 声明驱动的词法 + 跨 `import` 记法

> 状态：**已落地（as-built）**。本节是第二刀的设计 + as-built 记录；上面的
> §1–§9 是第一刀（0.59.0）的记录，**语义规则 N1–N7 继续有效**，本节只写增量。
> 第一刀的"第二刀清单"（§7）在本节逐条销账，销不掉的写在 §12。

## 10. 设计（增量）

### 10.1 两条新命令：`prefix:N` / `postfix:N`

与 `infix` 族**同族**：源级糖、零事件、不进声明表、文件内作用域（+ §10.3 的
跨 `import` 传播）、点名形式永久可用、两种写法判卷一致。

```
prefix:N  " sym " => name     -- `sym a` 展开成 `name <前导参数> a`
postfix:N " sym " => name     -- `a sym` 展开成 `name <前导参数> a`
```

`N` 必填、范围 1–1000（与 `infix` 族同一把尺子、同一个诊断
`parse-notation-precedence`）；符号规则、`=>` 目标规则、重复声明规则全部复用
`parse_infix_command` 的三段（`parse_notation_precedence` / `parse_notation_symbol`
/ `expect_notation_arrow`）。

**优先级规则（v1 自定，与 N3 的表并列）**：

| 结合 | 吸收条件 | 操作数怎么解析 |
|---|---|---|
| `prefix:N` | 出现在**原子位**（`parse_app` 的头部），总吸收 | 操作数 = `parse_operators(N)` |
| `postfix:N` | 在爬升循环里 `N >= min_precedence` 才吸收 | 左操作数 = 已经爬好的 `lhs` |

于是 **N 越大绑得越紧**，两条都自洽：

* `prefix:100 " 𝒫 "` ⇒ `𝒫 A ∪ B` = `(𝒫 A) ∪ B`；`prefix:50` ⇒ `𝒫 (A ∪ B)`；
* `postfix:100 " ᶜ "` ⇒ `A ∪ Bᶜ` = `A ∪ (Bᶜ)`；`postfix:50` ⇒ `(A ∪ B)ᶜ`。

AST 复用 `Expr::Notation` 的**两个已有 `Option` 槽**：前缀 = `lhs: None,
rhs: Some(操作数)`，后缀 = `lhs: Some(操作数), rhs: None`。于是
`elab_expr` 的 `[lhs, rhs].flatten()` 直接得到单操作数列表，`elab_notation`
（N4 的补前导参数机器）**一行不改**就支持一元记法。

### 10.2 声明驱动的词法（第二刀的核心词法增量）

第一刀的符号类（`U+2200–22FF`/`U+2A00–2AFF`/`\`）**收不进**卷 I 要的五个符号：

| 符号 | 码点 | 今天的词法 | 问题 |
|---|---|---|---|
| `𝒫` | U+1D4AB | `Ident("𝒫")` | 数学斜体**字母**，`is_ident_start` 为真 |
| `ᶜ` | U+1D9C | `Ident("ᶜ")` | 修饰字母，同上（且是**续接**字符 ⇒ `Aᶜ` 是一个 Ident） |
| `''` | U+0027×2 | **词法错误** | `'` 只是续接字符，不能起头 |
| `⁻¹'` | U+207B U+00B9 U+0027 | `Ident("⁻¹'")` | 上标是标识符字符 |
| `×ˢ` | U+00D7 U+02E2 | `Ident("×ˢ")` | `×` 是标识符字符 |

所以第二刀改用**声明驱动的词法**（第一刀 §3.4 预留的两条路之一）：

1. **预扫描** `token.rs::scan_notation_symbols(src)`：一趟字符扫描（**跳过
   `--` 注释与字符串字面量**）收集源码里所有记法命令声明的符号文本。状态机
   只有三态：`Start` / `Keyword`（刚读完 `infix|infixl|infixr|prefix|postfix|
   notation`）/ 之后的可选 `:N`，紧跟着的字符串字面量就是符号。
2. **带符号表词法** `tokenize_with_symbols(src, &symbols)`：`next_token` 在
   常规分支**之前**先做「声明符号最长匹配」，命中就产出 `Sym(symbol)`；
   `lex_ident` 的续接循环里也在命中处**断开**（于是 `Aᶜ` = `Ident("A") +
   Sym("ᶜ")`）。
3. `parse(src)` = 预扫描 + 带符号表词法（`tokenize(src)` 保持 `symbols = &[]`，
   逐字节等于今天）⇒ **没有记法声明的文件行为零变化**（A1 的守护不变）。

边界（写进 §11）：声明过的符号在**本文件/本闭包**里是保留的——同名标识符
会被读成符号（与第一刀的 `∈` 已经如此，一致）。

### 10.3 跨 `import` 的记法传播

**取舍：改闭包加载顺序（重解析），不是"把记法内联复制到每个单元"。**

理由（实测驱动）：内联复制要求每个用到 `𝒫`/`''` 的单元**自己重写一遍声明行**，
而声明行里的目标名是 `Set.powerset`——它由 `lib/Set.sokonanoda` 提供。复制到
单元里就成了"单元自己声明记法"，于是 ① 每个单元多 6 行样板；② 符号的重载/
遮蔽语义变成"各文件各说各话"，与 Lean「记法是 import 带来的」直接冲突；
③ 更糟的是它把"库定义记法、单元直接用"这条课程叙事变成假的。
重解析只多一趟 parse（教学规模下是微秒级），换来的是**真语义**。

**实现（`project/graph.rs`，闭包加载的最后一步）**：

1. 快速路径：闭包里**没有任何** `Command::Notation` ⇒ 直接返回，闭包逐字节
   不变（A1 与缓存摘要都不受影响）。
2. 否则按**拓扑序**（依赖在前）重解析每个未被阻断的模块：把前面模块累积的
   记法表作为**继承表**传给 `parse_with_notations(src, &inherited)`——它同时
   喂给词法（符号表）与 parser（算子表）。重解析后把本模块自己声明的记法并进
   继承表（**同符号后来者覆盖**：本地声明遮蔽继承来的）。
3. 只重解析**有继承表**的模块；自己声明的记法在第一趟 parse 里已经生效
   （预扫描看得见本文件的声明行），所以"库自己"不会被多解析一遍。

**语义**：被导入模块的记法在入口文件**从文件头就可用**（与 Lean 的 import
一致），而不是"声明之后"——"声明之后"仍然约束**本文件自己**的记法（N5）。
本地重声明同一符号 = **遮蔽**（不再报"本文件已声明"），因为那条错误是给
"同一个文件里写两遍"准备的。点名的护城河（N4.3）在第二刀**原样保留**。

### 10.4 课程库（卷 I）的五个符号

**放 `courses/set-theory/lib/Set.sokonanoda` 末尾**（不新建 `Notation.sokonanoda`）：
它们的目标全是 `Set.*`，拆出去会多一条 import 边却没有任何分层收益；而且
`lib/Set.sokonanoda` 已经是"单元 import 的那一个库"。记法**不是声明**（N6），
所以加它们**不改变任何计数**（课程门禁的 36/329/99 逐项不变）。

| 记法 | 形状 | 目标 | 目标签名（卷 I 的 L2 层） |
|---|---|---|---|
| `𝒫` | `prefix:100` | `Set.powerset` | `(α : Type) → Set α → Set α` |
| `ᶜ` | `postfix:100` | `Set.compl` | `(α : Type) → Set α → Set α` |
| `''` | `infixr:80` | `Set.image` | `(α β : Type) → (α → β) → Set α → Set β` |
| `⁻¹'` | `infixr:80` | `Set.preimage` | `(α β : Type) → (α → β) → Set β → Set α` |
| `×ˢ` | `infixr:80` | `Set.prod` | `(α β : Type) → Set α → Set β → Set (α × β)` |

（`''`/`⁻¹'` 用 `infixr:80` 是 `prior-art-report.md` §1.3 逐字取证的 Lean 声明行；
`𝒫`/`ᶜ` 取 100 = 「贴得比 `∪`/`∩`（65）紧」，`×ˢ` 取 80。这三条是**本子集
自定**，与 N3 的取证状态同级。）

前导类型参数的补全**必须**走 N4 的裸变量匹配：`Set.powerset : (α) → Set α →
Set α` 的第 2 个参数域是 `Set α`，与 `typeof(A) = Set α₀` 头部匹配 ⇒ `α := α₀`；
`Set.image : (α β) → (α → β) → Set α → Set β` 的两个前导参数分别从第 3、第 4
个参数的类型解出。**解不出就报 `elab-notation-argument-unsolved`**，不猜。

## 11. 第二刀 as-built（0.60.0）

设计里的 §10.1–§10.4 全部落地；这一节只记**实现时才暴露出来的事实**，以及
**落地后与设计初稿不同的地方**。

1. **`parse_def` 之外的第一件事：`𝒫` 之类的符号不能再用「全是标识符字符」拒绝**。
   第一刀的 `parse_notation_symbol` 用 `symbol.chars().all(is_ident_start)` 拒掉
   标识符词；`𝒫`（数学斜体字母）正好命中，第二刀当场报 `notation-shape`。改成
   **只拒纯 ASCII 标识符词**（`in`/`e`/`Set`）：它们会把整个文件里的这个名字
   都收走（`in` 还是 `infix` 的前缀）。判据抽成
   `token.rs::{is_ascii_word_symbol, lexer_reserved_symbol_char}`，**预扫描与
   parser 共用同一份**——实测踩过：预扫描若收了 `"in"`，`infix` 会被拆成
   `in` + `fix`，报出来的错完全看不懂。
2. **`''` 从「词法错误」升级为「未声明符号」**：`'` 单独出现时给 `Sym`（第一刀
   把 `\` 从词法错误改成 `Sym` 是同一个理由——诊断更教学）。副作用是好的：
   入口用了 import 来的 `''` 时，parse 报的是 `notation-unknown-symbol`，
   分发逻辑（§11.6）才认得出"这条错可能被 import 治好"。
3. **`elab_notation` 读目标签名必须用新加的 `judge::judge_type_of`**。
   `judge_infer` 那条路要先合成 `fun (binders) => target` 再逐层剥 binder，
   **目标本身是函数**时内核 pp 的多 binder 折叠会让剥离错位——实测
   `Set.image` 的签名被读成
   `(β : Sort 1) -> … -> (α : Sort 1) (β : Sort 1) -> …`，于是 `''` 的
   **两个前导参数一个都解不出**（`elab-notation-argument-unsolved`）。
   `judge_type_of` 直接 `#check <target>`，不合成 lambda、不剥——签名是常量
   自己的，与调用点的 binder 无关。**这条是第一刀就潜伏的**（`Set.mem` 恰好
   没踩到）。
4. **`notation_prefix_args` 的 `j - missing` 会下溢**：第一刀只测过
   `missing == 1`（`Set.mem`）；`Set.image` 有 **2** 个前导参数，`j=1` 时
   `1 - 2` 在 debug 构建下直接 panic（`attempt to subtract with overflow`）。
   修成 `j.checked_sub(missing)`。
5. **`rfl` 候选文本的括号清单漏了 `Notation`**：`by.rs::atom_text` 自己维护过
   一份"哪些形状要补括号"的清单，缺 `Let`/`Match`/`Notation`，于是
   `Eq.refl.{1} (Set α) (Aᶜ) ∪ B` 被读成 `(Eq.refl.{1} (Set α) Aᶜ) ∪ B`。
   现在 `atom_text` 直接调 `proof::render_atom`（**括号规则只允许有一个实现**）。
   顺带把 `rfl` 闭合用的表达式**直接构造成 AST**，不再回读候选文本。
6. **分发要认「未声明记法符号」这一条 parse 错**：入口用了依赖声明的记法时，
   `parse(entry)` 必然失败，而 CLI/LSP/真相层都是"先单独 parse、看有没有
   `import`"来决定走不走闭包——**解析失败 ⇒ 走单文件 ⇒ 永远看不到依赖的记法**。
   修法是 `project::is_project_source`：parse 成功照旧；parse 失败时**只有**
   `notation-unknown-symbol` + 源码里有 `import` 行才改判项目（别的解析错误
   加载多少依赖都还是错，必须原样报——放宽会当场把 `project_features.rs`
   的三条用例判红）。同一份判据被 `check`/`query`/`build`/`course`/真相层共用。
7. **闭包加载的顺序对调：先收 `import` 边、访问依赖，再解析自己**。
   `visit` 原来"先 parse 自己、再从 `Command::Import` 收边"，于是
   "入口 parse 失败 ⇒ 收不到边 ⇒ 依赖不加载 ⇒ 记法传不过来"是**死锁**
   （实测闭包里只剩入口一个模块）。现在用 `token::scan_import_lines`
   （词法级、与 `Lexer::on_import_line` 同款判据）先拿边、先访问依赖，拿到它们
   **导出的记法表**之后再解析自己；解析成功时 `Command::Import` 的边是权威版本。
   记法表**按 import 边合并**（不是"闭包里全局"）：没 import 的模块的记法不泄漏。
8. **重声明继承来的记法是错误，不是遮蔽**。判卷通道会把闭包**首尾相接**成一份
   合成源码（`judge.rs` 的前缀），两个模块各声明一次 `∪` 在那里必然撞车；与其
   让同一个程序在两条通道上得到不同答案，不如在源头说不许。副作用：**记法对照页
   必须自己写 `∈`/`⊆`/`∪`/`∅`**——这正好是第一刀的设计（core 级符号课程库不声明），
   所以页面的四条声明一条都不用改（lib 声明的五个是**另外**五个符号）。
9. **`by` 块目标里的记法现在判得动了**（第一刀遗留边界）。`by` 引擎把目标
   `render_expr` 成文本再 `parse_expr_text` 回读，而回读的片段里没有记法声明。
   判卷通道本来就为合成声明解析了前缀（`parse_prefix`），现在**顺手从那份
   `FolFile` 里收记法声明**（顺序对调：前缀先解析），回读时当继承表喂进去。
   零额外解析开销；前缀里没有记法命令时逐字节等于旧行为。
10. **一元记法在实参位要加括号**（`f (𝒫 A)`、`f (Aᶜ)`、`Eq.{1} (Set α) (Aᶜ) (…)`）：
    `starts_atom` 对前缀/后缀符号都是 `false`（与二元记法一致）。**这是设计选择**：
    `Eq X Aᶜ Y` 报的是响亮的 parse 错，而不是像二元记法那样悄悄按错误的结合性
    读下去。
11. **优先级梯子多了一条"绑得太松就让路"的规则**：`postfix:50 " ᶜ "` 配
    `infixl:65 " ∪ "` 时，`A ∪ Bᶜ` 必须在**外层**（`min_precedence = 0`）吸收成
    `(A ∪ B)ᶜ`。所以"已声明但不是二元算子"的专用诊断只在
    `N >= min_precedence` 时报，否则让爬升照常结束。
12. **课程侧的演示写成 `example`**：单元③/⑧ 各一条记法演示，用 `example` 而不是
   `theorem`（单元⑧ 的"演示 8"本来就这么写）——**课程门禁的 `decl.checked`
   计数因此一个都不动**（`example.checked` 是另一类事件）。实测课程门禁
   **36 目标 · 329 checked · 99 open · 0 判负**，与改前**逐项相同**。

### 11.1 验收（实测）

| 命令 | 结果 |
|---|---|
| `cargo test --workspace --locked` | exit 0（front 611 条、CLI 全绿） |
| `cargo fmt -p sokonanoda-front -p sokonanoda-cli -p sokonanoda-lsp -- --check` | exit 0 |
| `cargo clippy -p sokonanoda-front -p sokonanoda-cli --all-targets --locked` | exit 0 |
| `python3 courses/set-theory/tools/check.py` | exit 0，**36 目标 · 329 checked · 99 open · 0 判负**（与改前逐项相同） |
| `python3 courses/set-theory/tools/check.py --selftest` | exit 0 |
| `python3 scripts/gap.py check` | exit 0 |
| `node editor/vscode/test-extension-host.js` | exit 0 |

五个符号各自的判卷（真二进制 + `--json`，两种写法计数逐一相等）：

| 符号 | 形状 | 目标 | 记法版 | 点名版 |
|---|---|---|---|---|
| `𝒫` | `prefix:100` | `Set.powerset` | exit 0 | exit 0 |
| `ᶜ` | `postfix:100` | `Set.compl` | exit 0 | exit 0 |
| `''` | `infixr:80` | `Set.image` | exit 0 | exit 0 |
| `⁻¹'` | `infixr:80` | `Set.preimage` | exit 0 | exit 0 |
| `×ˢ` | `infixr:80` | `Set.prod` | exit 0 | exit 0 |

跨 `import`：`courses/set-theory/lib/Set.sokonanoda` 声明五个符号，
`crates/cli/tests/notation.rs::a_library_notation_works_in_the_entry_through_import`
把**真课程库**复制到临时目录、写一个**不重声明**任何记法的单元（`𝒫 A` / `Aᶜ` /
`by rfl`）⇒ exit 0、3 条 `decl.checked`、0 诊断。

## 12. 第二刀仍未做 —— **第三刀已落（第三刀 = 本节逐条销账）**

> 本节是第二刀留下的清单（原文与理由**保留**，作为历史）；**第三刀**（0.60.x，
> 设计与 as-built 见 §14）逐条销账，结论写在下面第三列。销不掉的移到 §13。
> 第 5 条（print-back）按任务要求**明确不做**、连理由一起进 §13.1。

| # | 第二刀未做项（原文理由保留） | 第三刀结论 |
|---|---|---|
| 1 | **binder 记法**（`∃ x, …`、`∀ x ∈ s, …`、`notation3`）——"它要动的是 **binder 位置的解析**（`parse_decl_binders`/`forall`/`exists` 的共享路径），与"算子梯子上的糖"不是同一层。第二刀的预扫描/符号表对它一点用都没有；值得单独一刀（台账原话就是「另立」）" | **已落（§14.1）**：新命令 `binder_notation "∃" => Exists`；`∃ (x : α), p` 与两段式 `∃ x ∈ s, p` 落地，`∀ x ∈ s, p` 走**同一条共享 binder 路径**（`parse_binder_prefix`）。`notation3`（dependent binder）仍在 §13.2 |
| 2 | **记法重载**（同一符号多个目标，按期望类型选）——"v1 的重复声明是**错误**……重载要求展开期做候选选择 + 歧义诊断，是**语义**增量；而记法的卖点正是"零语义"。真要做，先想清楚"选错了报什么"" | **已落（§14.2）**：同符号、同形状 = 重载，按**期望类型**选；"选错了报什么"= 两个专用码 `elab-notation-ambiguous`（≥2 个候选都说得通）与 `elab-notation-no-candidate`（一个都对不上），消息列候选与各自结果类型、hint 教点名写法 |
| 3 | **`scoped` / `open scoped`**——"依赖'重载 + 作用域栈'两件都没做的事；课程侧不需要" | **已落（§14.3）**：作用域名 = 声明点所在 `namespace` 的全前缀（复用 G-05 的栈）；`open scoped Foo` **只**开记法、不开名字 |
| 4 | **集合字面量 `{a}` / `{a,b}`**——"这是**新语法**（不是记法）：`{}` 今天是 binder/宇宙参数的定界符，`{a}` 与 `{x : T}` 的消歧要新的 lookahead 规则" | **已落（§14.4）**：`Expr::SetLiteral` + `set_literal_ahead`（`{x : T}` 形状让路给 binder）；展开成点名形式 `Set.singleton α a` / `Set.pair α a b` |
| 5 | **源码级 print-back**（goal/hover 显示 `Aᶜ` 而不是 `Set.compl α A`）——"与第一刀同一条：类型文本由**冻结内核的 pp** 产出，记法不进内核" | **不做，移到 §13.1**（任务明确要求）：内核冻结下销不掉，理由在 §13.1 |
| 6 | **一元记法在实参位免括号**——"§11.10 的设计选择；免括号要求 `parse_app` 与算子梯子合并，收益（少两个括号）不值这个复杂度" | **前缀已落（§14.5）**：`f 𝒫 A` 不再报错（今天它是响亮的 parse 错 ⇒ 纯增量）。**后缀明确不做**，移到 §13.4（`f Aᶜ` 今天读作 `(f A)ᶜ`，改了会**悄悄重分组**既有程序） |
| 7 | **编辑器里 `abbrev`/记法符号的语义高亮**——"`front::semantic::KEYWORDS` 与 `editor/vscode` 的 TM 语法词表必须**同一轮**加……而本轮 `editor/vscode/**` 禁改" | **已落（主线收尾轮）**：新拼写 `prefix`/`postfix`/`binder_notation`/`scoped`（连同 `abbrev`）进 `KEYWORDS` + TM 语法词表**同一轮**同步、两份逐字相等；as-built 见 §13.6 与 `docs/design/abbrev.md` §4 |


## 13. 第三刀仍未做 / 不该做（明确销不掉的）

> 与 §12 同一条纪律：**逐条给理由**，不写"没时间"。**本节的项一律不在第三刀**。

| # | 未做项 | 理由（不是"没时间"） |
|---|---|---|
| 1 | ~~**源码级 print-back**（goal/hover 显示 `∃ x, …` / `{a}` / `Aᶜ` 而不是点名形式）~~ **✅ 已落地（线 C；2026-10-13 订正）** **⛔ 本行的理由已作废（2026-09-21）；方案已立项为线 C（T-C10…T-C41），权威设计 `docs/design/notation-aware-printing.md`** | ~~**内核冻结下销不掉**~~ **作废**：类型文本由**冻结内核的 pp** 产出（硬规则 1：`crates/kernel/**` 一个字节不许动），而记法**不进内核**——内核只看见 `Exists α (fun …)`。要做得二选一：① 改内核 pp（违反硬规则 1）；② 在 elab 保留"源 → 核"的映射、把所有 pp 消费点（goal 面板、hover、错误文本、`#check`、`by` 回读）换成源级渲染——那是**两套真相**，且回读路径（§11.9）会立刻分叉。收益（面板好看一点）不抵成本与风险。**任务明确要求这一项不做**，故记在这里。**⛔ 2026-09-21 作废**：① "内核冻结"这条前提已失效（用户同日解冻内核）；② 而且**根本不需要动内核**——实测内核的记法打印是**死代码**（`ExportFile.notations` 全仓库无一处 insert），`pp_expr` 又同时是 `#check`/`#reduce` 的出口（动它就动 `--json` 字节）。正解是 **front 侧的显示边界重写**（零内核改动、`DisplayText` 护栏让"回读"编译不过），设计见 `docs/design/notation-aware-printing.md` §3，计划见 §6 线 C |
| 2 | **`notation3` / 一般 binder 记法**（`⋃ i, f i`、`∑ i, …`、多 binder 两段式 `∀ x y ∈ s, p`） | 这类 binder 的**类型依赖前一个 binder**（`⋃ i : ι, f i` 里 `f i` 的域随 `i` 变），要求记法命令能声明**依赖 telescope** 并做代换；v1 的 binder 记法只有两个类型来源（**标注** `∃ (x : α), p` 与 **guard** `∃ x ∈ s, p`，§14.1）。课程卷 I 的 `∃`/`∀` 两段式不需要它 ⇒ 留给需要 `⋃ i,` 的那一刀 |
| 3 | **一般隐式实参推断 / 元变量 / 一般合一**（第一刀 §7 的老边界，第三刀没动） | 直接后果：① 一段式 `∃ x, p` 的 x 类型**必须**写出来（`∃ (x : α), p`）或由 guard 给；② `{a, b, c}`（≥3 元素）不做折叠；③ 重载只看**结果类型**（§14.2）。要动它就得引入元变量与合一，那是 elaborate 的架构级增量，且与"记法零语义"的卖点冲突 |
| 4 | **一元后缀记法在实参位免括号**（`f Aᶜ` = `f (Aᶜ)`） | `f Aᶜ` **今天有确定读法**：后置算子在梯子上吸收整个应用 ⇒ `(f A)ᶜ`。改成 `f (Aᶜ)` 是**悄悄重分组既有程序**（违反"只加不删"），而且两者形状完全一样、无法只放行一种。要"少写括号"就写 `f (Aᶜ)`（§11.10 的选择**只对前缀松动**） |
| 5 | **`open scoped` 的子命名空间传播**（`open scoped A` 是否带进 `A.B` 的 scoped 记法） | v1 按**精确名字**匹配（`open scoped Foo` 只开 `Foo`）。理由：静默带进一整个子树的符号与"教学语法要能一眼看出名字从哪来"冲突；Lean 的精确语义**未取证**（无网络），所以先钉最保守的一条 |
| 6 | ~~**编辑器词表同步**（`binder_notation` / `scoped` 进 `front::semantic::KEYWORDS` + TM 语法）~~ **已销（主线收尾轮）** | 原文理由（历史）：两边必须**同一轮**改（`crates/cli/tests/extension.rs::tm_grammar_keywords_follow_the_single_source` 是守护），第三刀禁改 `editor/vscode/package.json` 的版本号 ⇒ 本轮不进 `KEYWORDS`，交给主线同一轮加。**as-built**：主线把 `abbrev` + `prefix`/`postfix`/`binder_notation`/`scoped` 同一轮加进 `KEYWORDS` 与 TM 语法 `keywords` 词表（`declarations` 规则也认 `abbrev`），守护测试绿；落点与验证见 `docs/design/abbrev.md` §4 |

## 14. 第三刀（0.60.x）——设计与 as-built

> 状态：**已落地（as-built）**。落点全部在 `crates/front/**`（+ 课程单元⑧的一条演示
> + `docs/protocol.md` 的错误码表）；**`crates/kernel/**` 一个字节未动**。语义规则
> N1–N7 继续有效，本节只写增量（记 N8–N12）。

### 14.1 binder 记法（N8）

```
binder_notation "∃" => Exists        -- 命令形状与 notation 同族（不写优先级）
```

- **出现位置**：**binder 位置**（表达式开头），与 `∀` 同一层（`parse_expr` 直接分派）；
  它一直吃到表达式结尾。落在算子位上是教学错误（"binder 记法要写在表达式开头"）。
- **一段式**：`∃ (x : α), p` ⇒ `Exists α (fun (x : α) => p)`；`∃ x : α, p` 同义。
  binder 的类型**必须**写出来（或由 guard 给）——记法不引入元变量/一般合一（§13.3），
  解不出报 `elab-binder-notation-unsolved`（hint 教补标注或点名写法）。
- **两段式**：`∃ x ∈ s, p` ⇒ `Exists α (fun (x : α) => And (x ∈ s) p)`。`∈` 不必专门
  声明给 binder：它是**普通的二元记法**（`infix:50 " ∈ " => Set.mem`），binder 名当
  它的左操作数；`∀ x ∈ s, p` ⇒ `∀ x, x ∈ s -> p`（**原生 `∀`**，共享 `parse_binder_prefix`）。
- **binder 类型的来源**（两条，都不做合一）：① 标注；② 两段式由 guard 的关系目标
  （`Set.mem` 的 telescope）**反解**——用 guard 的**其它**操作数解前导参数、取 binder
  那一层的域（`Set.mem` 的第 2 个参数域是 `α` ⇒ `x : α₀`）。
- **零事件**：命令进不了声明表（N6 不变）；点名形式 `Exists α (fun …)` 永久可用，
  两种写法判卷一致（N7）。
- **命名（as-built）**：任务建议的 `notation-binder` **在本语言的词法下拼不出来**
  ——`-` 不是标识符字符（`is_ident_continue` 只收字母/`_`/数字/`'`/`!`/`?`/`.`），
  `notation-binder` 会被切成 `Ident("notation")` + `-` + `Ident("binder")`（实测：
  词法报 `expected -> or --, found -`）。定形为 **`binder_notation`**（单标识符，
  与语言里 `Set.mem_singleton_iff` 的 `_` 命名一致）。

### 14.2 记法重载（N9）

- **判据**：同符号、**同形状**（结合性 + 优先级都相同）的重复声明 = **重载**；
  不同形状仍是 `notation-shape` 错（`a ⊕ b` 与 `⊕ a` 在同一个符号上没法同时成立）。
- **重声明 import 来的符号**仍是错误（§11.8 原样保留）：判卷通道把闭包首尾相接，
  两个模块各声明一次会在那里撞车；同文件内的重载则两条通道看到同一组候选。
- **选择**：按**期望类型**筛候选——读每个候选目标签名的**结果类型**，与期望类型做
  **头部匹配**（头同名 + 实参个数相同；模板是裸变量算通配）。恰好一个 ⇒ 选它；
  ≥2 个（或没有期望类型却有多个候选）⇒ `elab-notation-ambiguous`；一个都不匹配 ⇒
  `elab-notation-no-candidate`（消息列候选与各自的结果类型）。**"选错了报什么"**：
  两个码都带人话 hint——先写点名形式消歧，或把表达式放到带类型标注的位置。
- **单候选 = 第二刀行为逐字节**：`Expr::Notation` 只**新增** `alternatives: Vec<String>`
  字段（单候选时为空向量），展开路径一行不改。

### 14.3 `scoped` / `open scoped`（N10）

- **作用域名 = 声明点所在 `namespace` 的累积全前缀**（复用 G-05 的栈）；
  `scoped` 写在 `namespace` 外是 parse 错（专用 hint 教包一层 namespace）。
- `scoped <记法命令>` 默认**不生效**（在 `open scoped` 之前用该符号报
  `notation-unknown-symbol`，与"声明之前使用"同码）；`open scoped Foo` 把 `Foo`
  作用域下**已声明**的 scoped 记法搬进生效表，之后在同作用域里声明的也直接生效。
- `open scoped` **只**开记法，**不**开名字前缀（`Foo.bar` 仍不能写成 `bar`）——
  与 Lean 一致；接线在 `compile/check/walk.rs`（`scoped: true` 不进 `ns.open`）。
- **跨 `import`**：scoped 记法随继承表传播，但**挂起**（`Parser::scoped_pending`），
  入口文件要自己 `open scoped <作用域名>`；判卷通道（`judge.rs` 收前缀记法表）按
  "前缀里有没有 `open scoped`"过滤，与主通道同口径。

### 14.4 集合字面量 `{a}` / `{a, b}`（N11）

- **新语法**（不是记法）：`Expr::SetLiteral { elements }`，**内建糖**——展开成点名形式
  `Set.singleton α a` / `Set.pair α a b`（与 `+` → `Nat.add` 同族，目标名写死在 elab 里）。
- **消歧**：`{` 后面是 binder 形状（`{x : T}` / `{x y : T}`，判据 `brace_binder_ahead`）
  就**不是**字面量（照旧走 binder 路径）；否则是字面量。因此 `starts_atom` 对 `{`
  返回 true 只在字面量形状上（`f {a}` 合法，`f {x : T}` 的报错一字未变）。
- **1–2 个元素**；空 `{}` 与 ≥3 元素给专用 parse 码 `set-literal-shape`（hint 教
  `Set.empty α` / `Set.pair` 点名嵌套）。
- **展开**复用记法路径（前导参数补全 + 操作数期望类型传播），多一条**回退解**：
  期望类型 `Set α₀` ⇒ `α := α₀`（`{∅}` 这类"元素自己的类型也只能从期望类型解"的嵌套）。
- 目标不存在（没 import 卷 I 的 `lib/Set`）⇒ `elab-set-literal-unknown-target`（hint 教
  import 或点名），不是"未知标识符"。

### 14.5 一元前缀记法在实参位免括号（N12）

- `f 𝒫 A` 现在读作 `f (𝒫 A)`（实参 = 前缀记法 + 它自己的操作数，优先级仍按 §10.1 的
  表：操作数走 `parse_operators(N)`）。
- **纯增量**：这一形状今天报**响亮的 parse 错**（"前缀记法不能夹在两个操作数中间"），
  没有任何既有程序依赖它。
- **代价（明说）**：`A 𝒫 B` 与 `f 𝒫 A` 形状完全一样，无法只放行后者 ⇒ `A 𝒫 B` 也从
  报错变成 `A (𝒫 B)`。**后缀不动**（§13.4）。
- 括号形式 `f (𝒫 A)` 逐字照旧可用（两种写法同判）。

### 14.6 as-built（实现时才暴露出来的事实）

1. **`unify_extract` 只认 `Arrow` 会漏掉内核 pp 的 `forall`**：`infer_type_text` 对
   `fun (n : Nat) => Eq n n` 返回 **`forall (n : Nat), Eq n n`**（pp 的写法），而签名里
   的 `A -> Prop` 解析成 `Expr::Arrow` ⇒ 前导参数 `A` 一个都解不出（实测
   `elab-notation-argument-unsolved`）。修法：剥层改用 `spine::peel_pi`（`Forall` 与
   `Arrow` 的**唯一**共用剥层，多 binder 折叠也归它）。**这条是第一/二刀就潜伏的**。
2. **集合字面量的元素类型回退**：`{∅}` 里 `∅` 自己的类型解不出（judge 没有期望类型），
   而既有路径的结构化匹配够不着"结果类型 vs 期望类型"（`rest` 是折叠后的 Arrow 望远镜）
   ⇒ 给 `elab_notation` 加一个**只增不改**的 `fallback_prefix_args` 参数（既有调用点
   全传 `None`，行为逐字节不变）。
3. **`scoped` 的两处接线**：`walk.rs`（`open scoped` 不进 `ns.open`）与 `judge.rs`
   （按前缀里的 `open scoped` 过滤继承记法）——两处都只加分支，既有路径不变。
4. **`judge_cache` 容量是 FIFO 的 128**：第三刀新增的记法测试把缓存填到上限，
   `judge::tests::judge_cache_returns_identical_results_and_stores_entries` 里
   "长度变大 ⇒ 键进去了"的判据**假红**（第二刀也踩过同一条，当时靠拆出 `type_cache`
   缓解）。改成**直接问键在不在**（新增 `#[cfg(test)] judge_cache_contains`），
   与容量无关——判据更准，不是放宽。
5. **`∃` 与 `∀` 的**不对称是设计**：`∀` 是语言关键字（`TokenKind::Forall`，原生 Pi），
   `∃` 是**库里的归纳**（`lib/Exists`），所以 `∃` 必须由 `binder_notation` 说出目标名；
   两者在 binder 位置上共享同一条解析路径（`parse_binder_prefix`）。
6. **课程侧演示写成 `example`**（与第二刀 §11.12 同款）：单元⑧ 的 `∃ (x : α), …` 演示
   不产生 `decl.checked` ⇒ 课程门禁计数**逐项不动**（实测见 §14.7）。
7. **`semantic::KEYWORDS` 在第三刀一字未改**（§13.6）：新拼写当时不进编辑器词表，
   `SemanticKind::ALL`、`tm_scope` 表、TM 语法词表锁全部**逐字节不变**；声明过的符号
   仍按 `Keyword` 着色。**主线收尾轮已销**：`abbrev` 与 `prefix`/`postfix`/
   `binder_notation`/`scoped` 同一轮进 `KEYWORDS` + TM 语法（`docs/design/abbrev.md` §4），
   第三刀当时的 as-built 结论本身不变。

### 14.7 验收（实测）

| 命令 | 结果 |
|---|---|
| `DEVELOPER_DIR=… cargo test --workspace --locked` | **exit 0**（front lib 627 条、CLI 全绿） |
| `cargo fmt -p sokonanoda-front -p sokonanoda-cli -p sokonanoda-lsp -- --check` | **exit 0** |
| `cargo clippy -p sokonanoda-front -p sokonanoda-cli --all-targets --locked` | **exit 0** |
| `python3 courses/set-theory/tools/check.py` | **exit 0**，**36 目标 · 329 checked · 99 open · 0 判负**（改前/改后逐项相同） |
| `python3 courses/set-theory/tools/check.py --selftest` | **exit 0** |
| `python3 scripts/gap.py check` | **exit 0** |
| `node editor/vscode/test-extension-host.js` | **exit 0** |

五项各自的判卷（真二进制 + `--json`，两种写法五元计数逐一相等）：

| 项 | 记法写法 | 点名写法 | 结论 |
|---|---|---|---|
| §14.1 binder | `∃ (n : Nat), Eq.{1} Nat n n` | `Exists Nat (fun (n : Nat) => Eq.{1} Nat n n)` | exit 0，计数相等（`crates/cli/tests/notation.rs::binder_notation_grades_like_the_pointful_exists`） |
| §14.1 两段式 | `∀ x ∈ s, p x` / `∃ x ∈ s, p x` | `forall (x : α), Set.mem α x s -> p x` / `Exists α (fun (x : α) => And (Set.mem α x s) (p x))` | exit 0，计数相等（`two_stage_binders_grade_like_the_pointful_guard`） |
| §14.2 重载 | `prefix:100 " ι "` 两条 + 期望类型 | —— | exit 0（选得对）；歧义 ⇒ `elab-notation-ambiguous` + exit 1（`an_overload_grades_by_expected_type_and_reports_ambiguity`） |
| §14.3 scoped | `namespace Foo` + `scoped infix…` + `open scoped Foo` | 同命题点名版 | 未 open ⇒ `notation-unknown-symbol` + exit 1；open 后 exit 0、计数相等（`a_scoped_notation_grades_only_after_open_scoped`） |
| §14.4 集合字面量 | `{a}` / `{a, b}` | `Set.singleton α a` / `Set.pair α a b` | exit 0，计数相等（`set_literals_grade_like_the_pointful_singleton_and_pair`） |
| §14.5 实参位免括号 | `f α 𝒫 A` | `f α (𝒫 A)` | exit 0（`a_prefix_notation_argument_keeps_the_parenthesised_spelling_working`） |

课程侧：单元⑧ 加一条**演示**（`binder_notation "∃" => Exists` + `example … := ∃ (x : α), …`），
练习数量与题意一字未动 ⇒ 门禁的 36/329/99/0 **逐项相同**；
`crates/cli/tests/notation.rs::the_shipped_course_demos_the_binder_notation` 把这条钉住。

---

## 15. R2 课程 Lean 化之后：契约翻转与 `≠` 的层级提示（2026-09-21）

R2（课程全面 Lean 化，设计 `docs/design/course-lean-style.md（**已删** ⇒ 原文 `git log --all -- docs/design/course-lean-style.md`）`）把**卷 I 单元②**
画布与解答都改成了记法版，于是本节 §8/§14.7 里两条"课程仍用点名"的记录
**到此为止**。翻转后的契约（测试名与方向都改了）：

| 旧 | 新 | 现在钉住什么 |
|---|---|---|
| `a_real_course_unit_grades_identically_in_notation`（§8 第 8 条、§14.7） | `a_real_course_unit_grades_identically_in_either_spelling` | 方向反转：画布是**记法版**，夹具 `pointful_variant` 造**点名版**；两份仍必须 `exit 0` 且五元计数相等（N7 契约不变） |
| `the_shipped_course_still_uses_the_pointful_spelling` | `the_shipped_course_uses_the_library_notation` | ① 单元**不出现** `infix`/`notation` 行（符号由 `lib/Set` 统一声明、随 `import` 传播）；② 六条记法签名真的在（含 `{a}`/`{a, b}` 字面量与 `≠`）；③ 画布**零点名残留**；④ 每条 `theorem` 的值位都是 `by`（tactic 风格） |

**`≠` 的 delta 展开必须带层级**（同一轮修的判卷器缺口）：`Ne` 是
`def Ne {u} (α : Sort u) (a b : α) : Prop := Eq.{u} α a b -> False`，
而 `≠` 的两条路**都不带 `.{u}`**——源 AST 是记法节点，过一遍内核 pp 是裸名
`Ne`（pp 省掉隐式宇宙参数）⇒ `intro h` 展开出来的 `h` 是 `@Eq.{u} …`（悬空
变量），回读报 `unknown universe level u`（报错点离根因很远）。
修法：`by` 引擎按**操作数的 sort** 算层级提示（与 `elab_notation` 给记法求层级
**同一条规则**），两档算法不同且都必须对：

| 形态 | 例 | 首实参是 | 层级 |
|---|---|---|---|
| 点名（实参 ≥ 形参） | `Ne (Set α) A B` | 那个类型参数自己 | `sort(首实参)`（**一步**；两步会得 `2`） |
| 记法（实参 < 形参） | `A ≠ B` | 该项的项 | `sort(type(首实参))`（**两步**；一步会得 `0`） |

回归：`crates/cli/tests/notation.rs::inequality_delta_unfolding_carries_the_right_universe_level`
（四条：点名对照 / `intro` 记法形态 / `apply` 点名形态 / `Prop` 档）。
判定仍在内核——层级错一条都过不了，所以"这些证明能过"本身就是判据。

## 附：渲染（记法进 goal / 类型行）

N1–N7 讲的是**语言**（怎么解析、怎么消解、怎么判卷）；这一节只记**显示**——
**它不改变 N1–N7 的任何一条**。

**0.65.0 起，goal / 假设 / 声明类型第一次显示记法**：内核 pp 与
`render_expr` 打出来的是点名形式（`Set.subset α A B`），而用户看的是
`A ⊆ B`。做法是**显示出口的折叠**（`front::display::print_back`）——把 pp 文本
解析回来、认出记法实例、**只替换那几段**。

### 边界（N7 的"教学契约"在显示侧的样子）

**折不了就原样，不猜**：

| 形态 | 例（课程库里的真实写法） | 显示 |
|---|---|---|
| 二元 infix 族 | `infix:50 " ∈ " => Set.mem` | **折** |
| 一元前缀 | `prefix:100 " 𝒫 " => Set.powerset` | 点名 |
| 一元后缀 | `postfix:100 " ᶜ " => Set.compl` | 点名 |
| 零元常量 | `notation "∅" => Set.empty` | 点名 |
| binder 位 | `binder_notation "∃" => Exists` | 点名 |
| 元数对不上（部分应用） | `Set.mem α a` | 点名 |
| `scoped` 未 `open` | — | 点名 |

**`scoped` 的判据是"这段文本结束时生效"**（两遍扫描：先收齐 `open scoped`，
再按声明顺序过滤）——读回通道只有一段前缀、不关心"用在哪一行"，位置精确是
**编译期**的关切（parser 已经做对了）。

**重载**：同一符号 N 个 target **不是歧义**（反向折叠的判据是 head 名字）；
同一 target 两个符号才要选 ⇒ **取声明顺序第一个**。

**权威设计**：[`notation-aware-printing.md`](notation-aware-printing.md)（含
"为什么不走内核 pp"、arity 口径、损失护栏三层、性能账）。

## 16. E01（0.74.0）：课程库补 `•` / `∘` 两条**复合记法**（2026-09-27）

**做**：卷 I 的两个复合算子补上记法，各声明进**自己的库**——同一个符号在一个闭包里
只能有一个目标（§10.3 的遮蔽规则），所以两条不能都叫 `∘`：

| 记法 | 形状 | 目标 | 声明点 | 取证 |
|---|---|---|---|---|
| `g ∘ f` | `infixr:90` | `Function.comp` | `courses/set-theory/lib/Fun.sokonanoda` | **Lean 4 core 逐字**：`src/Init/Notation.lean:274` 的 `@[inherit_doc] infixr:90 " ∘ "  => Function.comp` |
| `r • s` | `infixr:80` | `Rel.comp` | `courses/set-theory/lib/Rel.sokonanoda` | **本课自定**：Mathlib 的 `Relation.Comp` 用的是 `local infixr:80 " ∘r "`（`Mathlib/Logic/Relation.lean:158`）；取 `•` 是为了与函数复合的 `∘` 区分，优先级沿用 Mathlib 那一档 80 |

**⚠ 顺带更正一处引用错误**：`lib/Rel.sokonanoda` 头部原来写"`r • s` 是 Mathlib 的记法"
——**不准确**（Mathlib 是 `∘r`，而且是 `local`）。已改，取证行号写在库里。

**两条边界（都实测过）**：
1. **符号与目标成对、不可互换**：`∘` 只给 `Function.comp`、`•` 只给 `Rel.comp`；
2. **应用到参数上要加括号**：`(g ∘ f) x` / `(r • s) a c`——函数应用比 90 还紧，
   `g ∘ f x` 读作 `g ∘ (f x)`。**这是 Lean 的读法，不是本课的怪癖**。

**判据（三层，各钉一段）**：
* **真相层** `crates/front/tests/prelude_shape.rs::the_course_libraries_declare_the_composition_notations`
  ——入口闭包的记法表里 `•`→`Rel.comp`（module `lib.Rel`、80、`Infixr`）、
  `∘`→`Function.comp`（module `lib.Fun`、90、`Infixr`），且声明点文本逐字是那一行；
* **契约层** `crates/cli/tests/notation.rs::the_course_composition_notations_grade_like_the_pointful_forms`
  ——把**真课程库**拷进临时模块根、入口只 `import` ⇒ 记法版与点名版 `grade` 都 exit 0、
  **五元计数逐项相等**（N7 教学契约 + §10.3 跨 `import` 传播）；
* **课程层** `python3 scripts/notation-lint.py` **零残留**——新声明**自动**派生点形式
  判据（脚本 `derived_pointful`）⇒「涉及单元改用记法」这条由 lint 判红，不靠人眼。

**反向验证**：撤掉两条声明 ⇒ 真相层与契约层**都红**，内核报
`符号 '∘' 在本文件里还没有声明过记法`（`•` 更早一步：未声明时它连符号都不是，
被读成 `Ident("•")` ⇒ `unknown identifier`）。

## 17. E03（0.74.0）：课程库补 `r ⁻¹` / `A ≈ B` 两条记法（2026-09-27）

**做**：把速查表里「Mathlib 有记法、本课程没声明（**写不了，别抄**）」那批的最后两条
补上（`r • s` / `g ∘ f` 由 E01 补）：

| 记法 | 形状 | 目标 | 声明点 | 取证 |
|---|---|---|---|---|
| `r ⁻¹` | `postfix:100` | `Rel.inv` | `courses/set-theory/lib/Rel.sokonanoda` | **本课自定**：mathlib4 master 的 `Mathlib/Logic/Relation.lean` **既没有 `Relation.inv` 也没有 `⁻¹`**（只有 `local infixr:80 " ∘r " => Relation.Comp`） |
| `A ≈ B` | `infix:50` | `Set.Equiv` | `courses/set-theory/lib/Equiv.sokonanoda` | **本课自定**：`Mathlib/Logic/Equiv/Defs.lean:80` 的 `infixl:25 " ≃ " => Equiv` 是**等价的类型**、不是集合等势；`Mathlib/SetTheory/Cardinal/Basic.lean` 无 `≈` |

**⚠ 又更正一处引用错误**：`lib/Rel` / `lib/Equiv` 的文件头原来都写"这是 **Mathlib 的**记法"
——两处都**不准确**（与 E01 的 `•` 同一个毛病）。已改，取证行号写在库里。

**三条边界（都实测过）**：
1. **`⁻¹` 与 `⁻¹'` 是两个符号**：词法按声明**最长匹配** ⇒ 单元⑧⑫ 里 `f ⁻¹' B` 仍读作原像
   （闭包记法表里两条并存，判据钉住 ✓）；
2. **`r ⁻¹` 应用到参数上要加括号**：`(r ⁻¹) b a`（**不是** `r ⁻¹ b a`）；
3. ⚠ **`≈` 的两侧不能都是零元糖**（**G-48；2026-10-01 `v0.79.0` 起已修 ✓**）：`∅ ≈ {b}` 曾经补不出论域
   （`∅`/`{b}` 自己也要靠期望类型才能定论域 ⇒ 鸡生蛋），报 `elab-notation-argument-unsolved`；
   E19 甲案（求解器**待定参数**）落地后它**默认判绿**（论域跟**同形的已解兄弟** ⇒ `Set.Equiv β β ∅ {b}`），
   逃生门 `SOKO_NOTATION_METAVAR=0` 回到旧行为；单元⑨ 练习 5 的点名 + `soko:notation-ok` 是**旧 workaround**（撤掉属课程内容改动，未做）。as-built（**已归档**）⇒ `docs/archive/docs-diet-2026-10-15/e19-baseline.md.gz` §6/§7/§9 ✓。

**判据（两层 + 课程层）**：
* **真相层** `crates/front/tests/prelude_shape.rs::the_course_libraries_declare_the_inverse_and_equinumerous_notations`
  ——`⁻¹`→`Rel.inv`（lib.Rel、100、`Postfix`）· `≈`→`Set.Equiv`（lib.Equiv、50、`Infix`）·
  且 `⁻¹'`→`Set.preimage`（lib.Set）**同时可见**；
* **契约层** `crates/cli/tests/notation.rs::the_course_inverse_and_equinumerous_notations_grade_like_the_pointful_forms`
  ——真课程库上记法版与点名版 `grade` 都 exit 0、**五元计数逐项相等**，并含 `f ⁻¹' B` 共存用例；
* **课程层** `python3 scripts/notation-lint.py` 零残留（新声明**自动**派生点形式判据）。

**反向验证**：撤掉两条声明 ⇒ 两层判据都红，内核报 `符号 '≈' 在本文件里还没有声明过记法`
与 `unknown identifier '⁻¹'`（与判红时逐字一致 ✓）。

**台账**：G-47（记法缺失，fixed）· **G-48（零元糖操作数，open）** · G-49（类型错误报
裸 de Bruijn 编号 `期望 $4，实际是 $5`，open——写复现件时实测到的诊断质量问题）。

## 18. E04（0.74.0）：hover 的类型面接上折叠（2026-09-27）

**做**：`crates/front/src/compile/check/mod.rs::resolve_hovers` 的文本从
`pp.pp_expr(ty)` **直出** ✗ 改成 `display.fold(&name_loose_bvars(…))` ✓
（`$N` 还原在前、折叠在后 —— 折叠是纯文本改写，与松散变量名无关 ✓），
并把 `&DisplayNotations` 从调用点（`check/kernel_phase.rs`，那里本来就有 `display` ✓）传进去。

**为什么这条以前没人发现**：同一份报告里另外三处显示面（声明 `ty_text`、Infoview `⊢`、
`by` 步进的 goals）都过 `fold` ✓，只有 hover 这条漏 ✗；而
`docs/design/notation-paths-audit.md` 的「用户可见面」表里那一行早先写的是
「**已迁 ✓**」——**不准确的结论把缺口盖住了** ✗（已更正，见该文件 §5）。
⇒ 教训与 AGENTS.md 的「真相与显示是两条路」同源：**结论也要有判据**，
「某面已迁」这种话必须能指到**调用点**或**一条会判红的测试**。

**用户看得见的变化**：编辑器/Infoview 里悬停**子表达式或假设**时，类型面从
`Set.subset α A B` / `Not a` / `forall …` 变成 `A ⊆ B` / `¬ a` / `∀ …` ✓
（**悬停声明名**那条走 `ty_text`，本来就折 ✓ —— 所以 e2e 里那条老断言一直绿 ✗，
它测不到这条缝 ✓）。

**判据三层**：
* **真相层** `crates/front/src/compile/tests.rs::hover_types_are_folded_like_the_other_display_surfaces`
  （新写，**修前判红**：文本里没有 `⊆`、却有 `Set.subset `）；
* **wire 契约层** `crates/lsp/src/tests/hover_brackets.rs::hover_on_brackets_of_and_right_group_shows_step_type`
  （`… h : ¬ a` + **反向**断言类型面不许出现 `: Not `）；
* **用户可见层** e2e `editor/vscode/src/test/extension.test.js` 的记法 hover 那条
  **补了子表达式 hover**（夹具 `units/u01.sokonanoda:11` 的假设使用处 `h`）。

**反向验证**（不改代码 ✓）：`SOKO_NO_NOTATION_FOLD=1 cargo test -p sokonanoda-front
--lib hover_types_are_folded_like_the_other_display_surfaces` ⇒ **判红** ✓（实测 exit 101）。

**同步更新的旧判据**（它们钉的是修前的点形式 ⇒ 必须一起改，否则"改了行为没动测试" ✗）：
front 5 条（`Prop -> Prop`→`Prop → Prop`、`Nat -> Nat`→`Nat → Nat`、
`b -> a -> And b a`→`b → a → b ∧ a`、`And a b`→`a ∧ b`、
`Not a`→`¬ a` 等 4 处期望值**按实测文本**写，含 `a ∧ (¬ a)` 的括号）+ LSP 1 条。
**实测数字**：front 全量 **748 passed / 0 failed** · LSP 全量 **164 passed** ·
CLI 全量 **25 target / 0 FAILED** · 完整 `scripts/soko gate` **exit 0** ✓。

**台账**：**G-50**（fixed）。

## 19. G-60（0.83.0）：集合建构式 `{x : α | P x}` / `{x ∈ A | P x}`（N13）

> 状态：**已落地（as-built）**。落点 = `parser.rs`（+ prelude 登记区 + 测试 + 课程侧）+ 一处
> **配套修复** `proof::render_binder`（见下）；**`crates/kernel/**` 与 `elab.rs` 一个字节未动** ——
> 脱糖在 **parser** 里完成，产出的就是既有 AST（`Expr::Lambda` / `Expr::App`）⇒ 显示面、`by`
> 步进、语义高亮、spine/goals 全部**零改动**。

**形状**（`{` 之后的 lookahead = `set_builder_ahead`，判据是**括号深度 0 处出现 `|`**）：

| 写法 | 脱糖目标 | 类型来源 |
|---|---|---|
| `{x : α \| P x}` | `Expr::Lambda`（`fun (x : α) => P x`）| **标注** ✓ **纯内核**，不依赖任何库 |
| `{x ∈ A \| P x}` | `Set.sep A (fun x => P x)` | **`A`**（`Set.sep` 的 telescope 解出 `α`）|
| `{x \| P x}` | **拒绝**（`set-builder-shape`）| 无 —— 本语言没有元变量（N4.2）|

- **为什么 `{x ∈ A | P x}` 落到 `Set.sep`**：没有元变量 ⇒ Lean 的 `setOf fun x => x ∈ A ∧ P x` 里 binder 的类型只能从**期望类型**解（`#check` 那类位置写不出来 ✗）；落到 `Set.sep` 则 **α 从 `A` 来** ✓，且与点名 `Set.sep A P` **同头常量** ⇒ `mem_sep_iff` / `sep_subset` 直接 `rw` 得上（落成 lambda 要先展开 ✗）。**代价（明说）**：依赖 `Set.sep` 在作用域内（与 Lean/Mathlib 的 `{x ∈ s | p x}` 同款）；缺库报 `elab-unknown-identifier`（点名 `Set.sep`）， **不另造码**（`{a}` 那条在 elab 期展开才有落点）。`∈` 若指向别的目标报**类型错**（不静默）。
- **边界**：变量名一个（Lean 的 `extBinder` 同款，`{x y ∈ A | …}` 不支持）；binder 谓词只认 `∈` （`∉`/`⊆`/`≤` 那几种 Lean 支持而我们不做）—— 两者都留给依赖 binder 那一刀（§13.2）。
- **与 `binder_notation` 的关系**：两条**各自独立**、都不引入元变量，类型都只从**标注**或 **关系式的其它操作数**来；差别在落点：`binder_notation` 的目标是**声明里给的名字**（用户可 自定义），集合建构式的目标是**内建写死**的（`Set.sep`，与 `{a}` → `Set.singleton` 同族）。 `{x ∈ A | P x}` 的 guard 走**与两段式 binder 同一条** `parse_operators_from` 梯子 ⇒ 读法一致 ✓。
- **诊断口径**：`{x | P x}` 报**专用码 `set-builder-shape`**（原来掉进 `set-literal-shape` 「集合字面量要写成 {a} 或 {a, b}」—— **指错路** ✗）；文案指路：「请写 `{x : α | P x}`（自己给 类型）或 `{x ∈ A | P x}`（类型从 `A` 来）」。
- **登记**：`{x ∈ A | P x}` 进 prelude 的 **`builtin-sugar` 登记区**（E11 同款），目标 `Set.sep`
  逐字守卫（`prelude_mirror.rs`）；`{x : α | P x}` **如实登记**「脱糖成函数 `fun (x : α) => P x`，
  无目标常量」（与 `⟨a, b⟩` 同款，**不许**编一个目标名 ✗）。
- **配套修复（同轮，`proof::render_binder`）**：无类型的 binder 改打**裸名字**（`fun x => …`）而
  不是 `(x)` —— `render_expr` 的产物是**回读通道的输入**，而 `(x)` **回读不了**（`parse_binder`
  的 `(` 分支要求 `x : T`）⇒ 含「无类型 binder 的 λ」的目标在 `by` 通道里一律判
  `elab-tactic-failed` ✗（**修前实测**：`{x ∈ A | P x} ⊆ A` 的 `by exact …`；基线二进制**同错**
  ⇒ 既有缺陷）。`render_binder_notation` 早就是这么做的 ⇒ 与它对齐，**只改无类型那一档** ✓。
- **不破坏既有形状**：`{a}` / `{a, b}` / `{}` / `{a, b, c}` 与 binder 组 `{x : T}` 逐字不变 —— lookahead 只在新形状上分派：`{x : T}` 里没有 `|` ⇒ 仍走字面量/binder 老路 ✓。

## 20. G-55（0.83.0）：`documentHighlight` 在记法**目标名**上的语义（N14）

> 状态：**已落地**（2026-10-07 用户授权"本轮做"）。落点 = `crates/lsp/src/{lib,render}.rs`
> + `notation_input::declared_notations`（薄封装，交出的就是 parser 共用的那份词法扫描）；
> **内核与判定零改动**（这是编辑器层）。复现件 `docs/gaps/repro/G55-notation-target-highlight.sh`。

- **设计问题**（台账 G-55）「目标名的『同一个定义』包含哪些位置？」⇒ **①+②+③ 累积式**，因为**目标名是"引用"、不是"引入处"**（记法声明引入的是**符号**）：① 光标处那个名字 —— **地板**：永不为 `null`、必含**用户实际点的位置**，目标在闭包外时这就是全部答案 ⇒ **不依赖 G-54** ✓；② 本文件里**展开到这个目标的记法符号的每一处**（`𝒫 A` 与 `Set.powerset α A` 指同一个定义，只是写法不同）；③ 目标**在本文件内**可解析时：**定义名**那一处 + **点名使用处**（`documentHighlight` 的 range 只属于被请求的那份文档 ⇒ 跨文件的位置不进结果，那是 `definition`/`references` 的事）。
- **用户语义**：点这个名字 ⇒ 看到"**这个词（连同它的各种写法）指向同一个定义的所有位置**"。**为什么不是只答 ①**（用户 2026-10-07 的倾向）：LS 的非 `null` 结果会**取代**编辑器自己的文本级兜底高亮（VS Code 1.138 的 `*` provider + `first non-null` 合并，本仓 `.vscode-test` bundle 实测）⇒ 只答一个词等于把今天那行上 `def powerset` 那一处**灭掉**（可见退化 ✗）；且"引用"当"引入处"说不通。**对齐 Lean 4**（`Server/FileWorker/RequestHandling.lean::handleDocumentHighlight`）：`info.definition?` 的 range + `info.usages` = 定义处 + 所有引用 ✓。
- **同类清单**（`AGENTS.md` 验证纪律第 0 条 (b)；守卫 `crates/lsp/src/tests/navigation.rs::non_use_positions_are_pinned_as_a_class`）：① 记法**目标名** = **本条 ✓**；② 记法声明**字符串里的符号**（符号的引入处）✗ **另一条** —— 符号语义已由 T-D24 定在**使用处**，答引入处是另一个问题；③ **0 使用处的声明名**（`def unused` / `axiom ax`）✗ **另一条** —— 定义名没有 hover 行，反查要先有一个使用处；④ `inductive` / `ctor` 名 = **答得上**但 range 混入类型位/返回位 ✗ **另一条**（精度，不是"答不上"）。
- **已知限制**：记法**重载**（同符号多候选）时词法表只留**主候选** ⇒ 符号的每一处都算到这个目标上（与 T-D24 的符号高亮**同粒度**）。**顺带修（同类坐标口径）**：本分支的 range 按 **byte offset** 重算 **UTF-16**（`render::range_of_in`）—— 全局 `range_of` 按 char 列算，含 `𝒫` 的行上会偏一格，而它与 hover/definition/诊断**共用** ⇒ **不在本条**（另一条）。
