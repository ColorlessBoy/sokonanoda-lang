## 2026-09-07 更新：新增层与总量

- **semantic tokens 层**：`crates/front/src/semantic.rs`（分类单测 10 个）+
  `crates/lsp`（capability/编码/端到端 4 个，UTF-16 增补平面用例）。
- **session/delta 层**：`crates/front/src/session.rs`（solved/failed/opened、
  零重编译、parse 错误恢复，2 个）。
- **check-then-add**：`kernel_failed_declaration_frees_its_name`（双趟语义）。
- **watch（L1 CLI 形态）**：初始手动三版本冒烟（file.changed → exercise.solved →
  零重编译）；现已有自动化集成套件 `crates/cli/tests/watch.rs`（握手
  `service.hello`、规范名 `file.didChange`、`--doc` 别名、`--workspace`
  每文件独立版本与 `file` 字段、闭词汇与 protocol.md 列名；client→service
  命令集：`ping`→`pong`、`subscribe` 过滤 workspace 文件、`unsubscribe`
  停止事件、坏命令回 `error` 且流不崩；等待用 `recv_timeout` 轮询，无固定
  sleep；同文件单测守护订阅白名单语义）。
- 测试总量（2026-09-07 第四轮）：**203**（kernel 43 / front 103 / cli 38 / lsp 20，
  cli 含 26+3+1+8 四个套件）。
- 内核 iota 规则教学注意：`inductive` 块现在被 kernel 判定，iota 规则的递归
  调用必须写 `Rec.{u}`（宇宙参数显式），规则值必须是 `ms n (Rec.{u} ...)`。

## 2026-09-07 更新（第五轮：I8 真增量 + I9 judge + 内核 soundness）

- **I8 增量层**（`crates/front/src/session.rs`，5 个新测试）：
  `session_rechecks_only_the_affected_suffix`（改第 4/5 个声明 →
  `stats.kernel_checks == 2/1`，插入/删除对齐）、
  `session_zero_recompile_keeps_prefix_results`（注释编辑零重编译 + hover
  span 平移 + 事件缓存）、`session_whitespace_between_commands_zero_recompiles_with_remap`、
  `session_prefix_failure_keeps_name_free_for_suffix`、
  `session_prelude_directive_change_rebuilds`。
- **I9 judge 层**（`crates/front/src/judge.rs`，8 个）：kernel 判定匹配/不匹配
  （含期望与实际）、依赖 binder、binder 缺类型标注报错、defeq-不同文本
  （`a -> False` ≡ `Not a`）、elab 错误透传、check-then-add 下前缀失败声明的
  名字释放、Bare 模式、宇宙参数。`proof.rs` 5 个（exact_kernel /
  assumption_kernel 正反两面）。
- **goal 视图协议层**（`crates/lsp`，3 个新测试）：`soko/goals` 结构与 hole
  range、`soko/nextHole` 三向导航、defeq-exact 端到端（文本比对给不出、
  kernel 判定能给出）。LSP 全部测试切换到带自定义方法注册的 `test_service`。
- **内核 conv soundness**（`crates/kernel/tests/memory_api.rs`，2 个）：
  `dependent_codomain_is_not_inhabited_by_identity_lambda`（修复前通过、
  修复后拒绝）+ `identity_over_sort_still_checks`（对照不过度拒绝）；
  CLI e2e 两条（`cli_rejects_uninhabited_dependent_codomain` /
  `cli_accepts_identity_over_sort`）。
- **lint 门禁即测试**：教学 crates `[lints.rust] warnings = "deny"`（clippy
  违规 = 编译失败），CI fmt 门禁覆盖教学 crates（kernel rustfmt.toml 需
  nightly，见 ci.yml 注释）。
- 测试总量（2026-09-07 第五轮）：**229**（kernel 43+2 新回归 / front 121 /
  cli 40（28 cli + 8 protocol + 3 course + 1 examples）/ lsp 23）。
  `cargo clippy --workspace` exit-0（kernel 冻结快照保持 warning 级）。

## 2026-09-07 更新（第六/七轮：skills + 逻辑先行课程）

- **skill 套件**（`crates/cli/tests/skill.rs`，4 个）：frontmatter（name=目录、
  description 长度）、引用路径存在性、事件/方法词汇封闭且 protocol.md 记载
  （词汇表移至 `tests/common/mod.rs` 与 protocol.rs 共用）、course.json 单元/
  钥匙孪生存在性。
- **宇宙参数携带**（第七轮）：`open_exercise_carries_universe_params`、
  `judge_uses_carried_universe_for_sort_u_goals`（front）。
- **课程 golden 重测**（course.rs，刻意变更）：新单元序 ①命题与证明
  (12,5,1) / ②等式与 rfl (2,5,2) / ③函数与箭头 (1,4,1) / ④宇宙 (0,3,0) /
  ⑤归纳 (4,3,1)；playground 重排后 checked=14 / open=12 / diagnostics=0。
- 测试总量（2026-09-07 第七轮）：**235**。

## 2026-09-07 更新（第八轮：goal 面板 + 客户端契约）

- **扩展契约套件**（`crates/cli/tests/extension.rs`，4 个）：命令注册一致性
  （package.json ↔ extension.js）、goal 视图协议消费（soko/goals + nextHole）
  且客户端禁止文本扫洞、运行时依赖在 dependencies（VSIX P0 回归守护）、
  打包元数据齐全。CI 无需 Electron 即可守护客户端。
- editor/vscode：练习树（soko/goals）+ 状态栏计数 + alt+n/alt+shift+n 跳洞
  （环绕）；AGENTS.md 作为 agent 项目指令入口（薄层，细节在 skills/）。
- 测试总量（2026-09-07 第八轮）：**239**。

## 2026-09-07 更新（第九轮：多洞/refine + 内核错误分类学 + 发布流水线）

- **多洞/refine**（front 4 + LSP 3）：spine 走查 Open 状态、子目标实例化
  （参数位=目标实参、证明位=字段类型）、refine 骨架（参数自动填充）、
  无模板回退、混合实参；LSP refine action、soko/goals holes/sub_goals、
  nextHole 跨子洞。
- **内核错误分类学**（front 5 + cli 3 e2e + kernel 消息增强）：8 个新
  kernel 错误码各有实测触发样例（见 subagent 报告/protocol.md）。
- **稳定性**：#check/#reduce panic 守卫（`cli_classifies_check_apply_to_non_function`）、
  .vscodeignore 回归守护（`runtime_dependency_is_packaged`）。
- 测试总量（2026-09-07 第九轮）：**245**。

## 2026-09-07 更新（第十轮：导航基线 + undo）

- **completions/folding**（lsp 2）：关键词/宇宙/prelude/声明全集（内部名
  不外泄）、多行声明折叠；`cli_prints_its_version`（cli）。
- **go-to-definition/documentHighlight**（lsp 3 + front 解析映射测试）：
  use→binder/use→声明（shadowing 用例）、同定义高亮、binder 补全。
- **REPL undo**（front 4 + cli e2e）：快照栈、失败不入栈、恢复全等。
- 测试总量（2026-09-07 第十轮）：**273**。

## 2026-09-07 更新（第十一轮：提示阶梯 + 建议 + rename/references + inlay）

- **提示阶梯**：front `compile/hints.rs`（指令解析/挂接 6 测试：独占行、
  挂下一条声明、跳过非声明命令、最后声明后丢弃）+ session 集成
  （`session_attaches_hints_and_refreshes_on_comment_edit`：hint 编辑零重编译
  但阶梯刷新）+ lsp `soko/hints`（阶梯返回/声明外为空）。
- **下一步建议**（front judge 5 + suggest 9 + lsp actions 4）：judge_hole_fill
  正反两面与 parse 失败不 panic；suggest 排序（exact→refine→intro）、
  rfl 仅 Eq goal 且 kernel 验证、多洞逐洞 exact 回归
  （`spine_holes_get_per_hole_exact_not_outer_goal_matches`）、
  is_preferred 恰一条、≤3 条截断。
- **rename/references**（front references 5 + lsp render 12）：references
  四向（use/含声明/def 点/无 target）、prepare 三态、rename 成功（版本化
  documentChanges、shadowing 内层、注释不误伤）、非法名/无 target
  ResponseError（测试内联原始调用助手断言 error）。
- **inlay**（lsp 5）：单洞/多洞子类型/checked 无/partial tooltip/无洞空。
- **VS Code 契约**（cli extension.rs）：`sokonanoda.revealHint` 声明/注册/
  workspaceState/禁「还剩 N 条」；`common/mod.rs` 词汇 + soko/hints（skill
  conformance 同步）。
- **lsp lib 化**：`cargo test -p sokonanoda-lsp` 语义不变；`sokonanoda lsp`
  子命令编译期覆盖（cli e2e 无 Electron 冒烟，stdio 交互不进 CI）。
- 测试总量（2026-09-07 第十一轮）：**327**（front 171 / lsp 56 / cli 55 /
  kernel 45）。

## 2026-09-07 更新（第十二轮：课程地图 + REPL 历史 + course 阶梯）

- **course 聚合**（`crates/cli/tests/course_status.rs`，4 个）：manifest 聚合
  逐单元 pinned（12/2/1/0/4 · 5/5/4/3/3，summary 19/20/0）、人类视图片段、
  坏单元带 error 且 exit 0、manifest 缺失 exit 非零；词汇表 +2
  （`course.unit`/`course.summary`，protocol.rs 与 skill.rs 共用同一封闭表）。
- **课程树契约**（extension.rs，+1）：package.json 声明视图/命令 ↔
  extension.js 注册、CLI 子进程调用 + `course.unit` 解析、**负断言**禁止
  客户端引用 soko/courseStatus（服务器单文档是方向性取舍）、子进程超时
  纪律（setTimeout + kill）。
- **REPL 历史**（cli e2e，3 个）：临时 HOME 注入（既有 repl 测试从此不污染
  真实家目录）、非空输入追加、HOME 缺失静默禁用、跨会话累积。
- **course 阶梯内容**：5 单元 × 20 练习 × 3 条 `-- soko:hint`（60 条）；
  golden 逐单元计数不变 + solutions 零诊断（注释不产事件）。
- 测试总量（2026-09-07 第十二轮）：**335**（front 171 / lsp 56 / cli 63 /
  kernel 45）。

## 2026-09-07 更新（第十三轮：内核分类学 + 建议 + 基准/fuzz）

- **内核冷路径分诊**（kernel memory_api 3 新 + front 分类 5 + cli e2e 2）：
  `accepts_iota_rules_in_constructor_order`（对照）/`rejects_iota_rules_out_of_constructor_order`/
  `rejects_iota_rule_count_short_of_constructors`；front
  `pipeline_classifies_iota_rules_out_of_order`/`pipeline_classifies_missing_iota_rule`
  （断言精确 code + hint）；`refine_kernel_kind` 家族样例 +9 组；
  CLI `cli_classifies_iota_rules_out_of_order`/`cli_classifies_missing_iota_rule`。
- **非递归归纳块**（front 2 + cli 2）：`non_recursive_inductive_block_compiles_and_reduces`
  （kernel 语义层）、`inductive_block_without_rec_is_a_clean_elab_error`、
  `cli_accepts_non_recursive_inductive_block`、`cli_classifies_missing_inductive_rec`。
- **失败声明 Restart 建议**（front suggest 6 + lsp actions 4）：骨架形状/
  重启闭环（落回后 kernel 重查回 Open）/binder 防撞/≤3 层/隐式风格/非 Pi 无建议；
  LSP 值位整体替换/多行/摘要截断。
- **criterion 基准**（不进 cargo test 计数）：`cargo bench -p
  sokonanoda-front --bench pipeline`（多 target 必须 `--bench pipeline`）；
  语料校验 OnceLock 先行。
- **fuzz**：`fuzz/` 独立 crate（脱离 workspace）；`cd fuzz && cargo check`
  守编译；CI 不跑。
- 测试总量（2026-09-07 第十三轮）：**356**。

## 2026-09-07 更新（第十四轮：hole_id + auto-derivation）

- **hole_id wire**（lsp 2 + extension 契约 1）：`goals_request_ids_holes_by_decl_and_order`
  （命名 `<name>:0` / 匿名 `example@<行>:0`）、sub_holes 测试补对象形状与
  区间对齐；`goals_holes_carry_ids`（客户端读 `hole.range`、负断言禁止裸
  Range 传参）；nextHole 测试不动（仍裸 Range）。
- **recursor 自动派生**（front 3 + cli 2 改写）：
  `auto_derived_recursor_non_recursive_compiles`（Unit→`1`）、
  `auto_derived_recursor_bool_computes`（`not tt⇒ff`/`not ff⇒tt`）、
  `auto_derived_recursor_recursive_nat_adds`（无 rec 的 Nat 块 + add 闭环）、
  `cli_accepts_bool_with_auto_derived_recursor`；显式 rec 回归锚点
  （py-nat/course5/memory_api iota）全部不动。
- **字段望远镜契约修正**：`num_fields`/`ctor_telescope_size_wo_params` 按
  完整 Pi 望远镜计（result 链字段计入）——内核 `check_declared_metadata`
  一致性要求；既有块数值不变（括号字段构造子的两种计法相同）。
- 测试总量（2026-09-07 第十四轮）：**360**。

## 2026-09-07 更新（第十五轮：spine meta B′ + 失败声明建议升级）

- **深度替换**（front 2）：`sub_goal_field_types_substitute_compound_binders`
  （复合字段 `And a b` → goal 实参实例化）、
  `sub_goal_field_types_respect_binder_shadowing`（innermost wins）；
  裸 Ident 路径旧断言零改动。
- **失败声明建议梯子**（front judge 4 + suggest 10 + lsp 4）：
  judge_value_replace 正反两面（rfl 接受/拒绝丢弃/宇宙携带/解析失败不
  panic）；rfl 验证项 → Reset（lambda 前缀保留）→ Restart 排序与
  is_preferred 恰一；保守形态识别（多 binder 单 fun 不识别）；两个既有
  重启锚点更新到新梯子，lib.rs 锚点不动。
- 测试总量（2026-09-07 第十五轮）：**380**。

## 2026-09-10 更新（第二十轮：soko/stateAt 光标处 goal 视图）

- **front `by_steps` 层**（compile/tests.rs + session.rs，3 个）：
  `partial_by_block_records_per_step_states`（逐步 goal/上下文/源码 span）、
  `checked_by_block_records_closed_final_step`（尾步 `goal=None`）、
  `session_remaps_by_step_spans_on_comment_edit`（零重编译后 span 平移）。
- **LSP 协议层**（lib.rs，5 个）：`state_at_inside_a_tactic_shows_the_entering_state`
  （Lean `goalsAt?`：光标在 tactic 上显示执行前状态）、
  `state_at_after_the_last_tactic_shows_the_remaining_goal`、
  `state_at_on_the_by_keyword_returns_the_root_goal`、
  `state_at_without_by_steps_returns_the_declaration_goal`、
  `state_at_outside_any_declaration_is_empty`。
- **词汇表**：`common/mod.rs::LSP_CUSTOM_METHODS` +`soko/stateAt`（skill
  conformance 与 protocol.md 三向一致）。
- **VS Code 契约**（extension.rs）：`entry_script_speaks_the_goal_view_protocol`
  增两断言（消费 `soko/stateAt`、挂 `onDidChangeTextEditorSelection`）。
- 测试总量（第二十轮）：**437 + 8 ignored**（front 229 / lsp 89 / cli 71 /
  kernel 48）；playground 锚点 20/9/0、course 32/25/0 不变。

## 2026-09-10 更新（第二十一轮：插件自带 LSP——bundled VSIX）

- **纯 Node 单测**（`editor/vscode/test-server.js`，15 个）：平台→target 映射、
  bundled 路径/exec 位修复（缺位 chmod、只读降级）、解析顺序（setting/env/
  bundled/workspace/缓存）、**下载 URL 锁定 `v${version}` 且不含 `/latest/`**、
  不支持平台报错；`test-download.js` 改为 require `server.js` 真实现（去重）。
- **打包冒烟**（ci.yml `Package host VSIX`）：每次 CI 对 host 打平台包并断言
  `bin/linux-x64/sokonanoda-lsp` 大小 >1MB、exec 位、`TargetPlatform`。
- **静态契约**（extension.rs，+5）：bundled 解析/latest 禁令/版本锁定 URL、
  scripts 齐全 + `.vscodeignore` 不排 bin、`Cargo.toml` ↔ `package.json`
  版本一致、release.yml per-target 打包 + universal、ci.yml test:unit + stage。
- **集成测试**：CI 先 `stage-lsp.js --profile debug` 把服务器放进
  `bin/linux-x64/`，集成测试因此走的正是用户安装平台包后的 bundled 路径。
- **本机验收**：`npm run package:host` → 1.96MB VSIX（zip mode 755、
  `TargetPlatform="darwin-arm64"`）；`package:universal` → 0.47MB 无 bin。
- 总量：workspace **440 passed + 8 ignored**；node 单测 22。

## 2026-09-10 更新（第二十二轮：平台矩阵扩展 4 → 8）

- **node 单测**（test-server.js，16 个）：新增 linux-arm64 / win32-arm64 /
  alpine-x64 / alpine-arm64 的 `platformTarget`/`rustTarget`/`bundledServerPath`
  映射、musl 下载 URL、`isAlpineLinux`（`/etc/alpine-release`，仅 linux）。
- **静态契约**（extension.rs，12 个）：server.js 必须含 8 个 target 与 Alpine
  检测；release.yml 必须含 4 个新 rust target + `cargo zigbuild` + `.2.28`。
- **release dry-run**：8 平台构建（Linux 为 Zig 交叉：gnu 目标 readelf 断言
  GLIBC ≤ 2.28、musl 断言静态；win32-arm64 原生）→ 9 个 VSIX zipfile 冒烟
  （8 平台 + universal）→ GitHub Release 17 资产（8 tarball + 9 VSIX）。
- **版本** 0.7.0 → 0.8.0；扩展 README 平台列表、CHANGELOG、RELEASE.md、
  vscode-dev-guide（zigbuild/glibc 坑）、ci skill 同步。

## 2026-09-10 更新（第二十二轮续：opencode launcher）

- **opencode 配置契约**（`crates/cli/tests/opencode.rs`，4 个）：
  1）`opencode.json` 必须启动仓库 launcher（`bash -c exec …` 单行），禁止
  `cargo run`；2）无 cargo 的 PATH 下命中 **VS Code 扩展自带 bin**；
  3）无 VS Code、无 cargo 时用 fake `curl` 断言 **按仓库版本锁定**的
  Release 下载（URL 含 `/download/v9.9.9/`、不含 `/latest/`）并运行解出的
  二进制；4）离线（`SOKONANODA_LSP_OFFLINE=1`）且一无所有时给可行动错误。
  launcher 解析顺序：`SOKONANODA_LSP_BIN` → 仓库 target → VS Code 扩展
  bin → 下载缓存 → 版本锁定下载 → `cargo build`。

## 2026-09-10 更新（第二十二轮续：CLI 零工具链化）

- **CLI 解析**（test-server.js，+2）：`resolveCliCommand` 的 bundled →
  workspace → PATH 顺序、Windows `.exe` 名称。
- **静态契约**（extension.rs）：server.js 必须含 `resolveCliCommand` 与
  `sokonanoda.exe`；release.yml 必须含 `--cli-binary` 与
  `sokonanoda-cli-` 资产名。
- **打包冒烟**：CI host VSIX 与 release 的 8 平台包均断言 **LSP + CLI 两个
  二进制**入包、大小 >1MB、linux/darwin exec 位；Release 资产 = 8 LSP
  tarball + 8 CLI tarball + 9 VSIX = 25。

## 2026-09-10 更新（第二十三轮：环境配置单一入口）

- **opencode/onboarding 契约**（`crates/cli/tests/opencode.rs`，8 个；含插件直连原生二进制、不许 `"bash"`、opencode.json 不写 lsp 的契约）：
  `sokonanoda doctor --json` 退出码契约（空缓存 3 → 伪造 marker 后
  0）、`setup` 离线可行动（exit 3 + 提示）、`grade` 直 exec 缓存 CLI、
  launcher 命中 VS Code 扩展自带 bin（无 cargo）、fake-curl 版本锁定下载
  （URL 含 `/download/v9.9.9/`、无 `/latest/`）、一无所有 exit 3、
  命名空间命令/插件/shim 契约（命令禁源码构建命令）。
- **发布资产属性断言**：release job tar 前 chmod + `tar tzvf | grep '^-rwx'`
  （v0.8/v0.9 曾发布 0644 二进制；见 CI-FAILURES 2026-09-10）。
- **本机冒烟**：`sokonanoda setup && sokonanoda doctor`（READY）+
  `grade playground.sokonanoda`（事件流）+ opencode LSP 诊断。

## 2026-09-11 更新（第二十八轮：内核已定义名字的声明 warning）

- **触发**：画布 `axiom Prop : Sort 1`——内核接受但名字永不被引用；用户
  要在 VS Code 里给出 warning。设计见 `docs/design/reserved-decl-warning.md`。
- **front**（`compile::warning`）：`collect_warnings` 纯语法扫描顶层声明名，
  命中 `Prop`/`Sort`/`Type` 产出 `reserved-declaration-name`（span 用
  `decl_name_span` 收窄到名字 token）；`CompileOutput.warnings` 与
  `DocumentReport.warnings` 双通道；会话零重编译路径现算。
  测试：`reserved_declaration_name_produces_a_warning`、
  `ordinary_declaration_names_have_no_warning`、
  `session_keeps_warnings_on_zero_recompile`（front 243，+3）。
- **CLI**：新事件 `warning`（`{type, human, code, message, hint, span}`），
  人类视图 stderr `line:col: warning[code]: message`；不改退出码。
  测试：`reserved_declaration_name_warns_but_stays_successful`（CLI protocol 9，+1）。
- **LSP**：`update.report.warnings` → `DiagnosticSeverity::WARNING`。
  测试：`reserved_declaration_name_is_a_warning_not_an_error`（LSP 93，+1）。
- **锚点**：`playground.sokonanoda` 现为 checked=14 / open=5 / warning=1 /
  0 诊断（第 79 行的 `axiom Prop : Sort 1`）。
- **`Type n` 记法**（同轮，用户要求）：`Type n` = `Sort (n + 1)` 解析糖。
  测试：parser `type_with_level_parses_as_sort_succ`、front
  `type_with_level_is_lean_sort_succ`、CLI `cli_accepts_type_with_level_as_sort_succ`；
  课程单元④ zh/en 各加一条 `#check (Type 0)`（事件计数仍相等）。

## 2026-09-11 更新（第二十九轮：环境能力进二进制，删除 `soko.sh`）

- **触发**：用户要求环境能力做成二进制 CLI，拒绝 `scripts/soko.sh`（Windows
  不可用、维护面大）。设计见 `docs/design/binary-cli.md`。
- **CLI 子命令**（`crates/cli/src/env/`）：`version`/`doctor`/`setup`/
  `update`/`grade`/`gate`；`setup`/`update` 用**内嵌下载器**
  （`ureq`(rustls/ring) + `flate2` + `tar`，无 shell/外部工具）按
  `build.rs` 钉死的 `TARGET` 拉取 `<pkg>-<triple>.tar.gz`；
  `SOKONANODA_RELEASE_BASE` 供测试/自托管覆盖；标记与 VSIX/插件一致
  （`<version> <vsce-target>`）。
- **去脚本**：删除 `scripts/soko.sh`；`.opencode/command/sokonanoda/*` 改调
  `sokonanoda <sub>`；插件 `findRepoRoot` 改用官方目录
  `.opencode/plugins/sokonanoda.ts` 作仓库标记；LSP shim 改为解析二进制并
  exec `sokonanoda lsp`。
- **测试**（`crates/cli/tests/opencode.rs`，8 个，重写）：`version` 三态标记、
  `doctor` 退出码、`setup` 离线可行动、`update` 用本地 HTTP 服务器验证
  版本锁定下载（无 `/latest/`）、shim 解析/失败可行动、插件/命令契约。
- **发布注意**：二进制新增 TLS（rustls/ring）+ tar/gzip 依赖，需 release
  `workflow_dispatch` 干跑验证 8 平台交叉构建。

## 2026-09-17 更新（第八十九轮：内核真相查询通道 H6-A/H6-B/H6-C，0.56.0）

- **`redundant-sorry`（第九十一轮续）**：分层见 §1 新行。设计与那 5 分钟实验
  （真根因 = `EnvLimit::ByName(探针名)` → `NO_DECL` → cutoff 0 → 空环境，不是
  `NamePtr` 身份）见 `docs/design/redundant-sorry.md` §8。
- **新增真相层 + 两条通道 + 一致性契约**：`front::query`（唯一语义源）→
  `sokonanoda query <op>`（单 JSON 对象）→ `dsh/mcp/server.js`（七工具）。
  分层守护见 §1 的三行新条目（内核真相查询 / `query` 子命令 + 两视图一致性 /
  MCP 桥），排查入口见 §3 第 6–7 条。
- **两条一致性契约**（防两套真相，本轮的核心资产）：
  `crates/cli/tests/query.rs::query_check_counts_match_the_json_event_stream`
  （`query check` 计数 ≡ `--json` 事件计数）与
  `query_state_agrees_with_the_lsp_state_at_request` /
  `query_state_and_lsp_agree_without_a_by_block`（**spawn 真实
  `target/<profile>/sokonanoda-lsp`** 逐字段对拍 `soko/stateAt`，含无 `by` 两分支）。
  跑法：`cargo build --workspace && cargo test -p sokonanoda-cli --test query`。
- **H6-C 的三层**：front 单测（箭头字段派生 / 具名孪生 / 真 iota 归约 / 单构造子
  `Prop` / K 目标两个判别性反例）+ CLI e2e（3 条）+ 课程语料 9 个文件简化后
  `examples`/`course`/`course_status` 全绿（golden 计数不变）。
- **LSP 结构债清零：`lib.rs` 4256 → 3988（删重复）→ 1105 行**（0.56.0：两个测试模块
  移出文件 + 抽出 `protocol.rs` 159 行 wire 类型、`tokens.rs` 107 行 semantic token
  辅助；0.56.1：`tests.rs` 2567 行拆成 `tests/` 一目录，最大文件 399 行）。
  每一步都零断言改动（220 条 assert 记账相等、95/95 测试名一致、规范化行流只差
  plumbing），117/117 全程保持全绿。测试文件位置见 §1 的 LSP 行。
- **总量（2026-09-17，两条并行线各自的快照）**：合并前本线 **756**、0.56.2 线
  **772**（多了 `redundant-sorry` 的 8 条、摘掉 2 条 `#[ignore]`）；合并后的真数以
  本文件第九十八轮与 `STATUS.md` 为准。两边共同的底数：kernel 43 + arena 1 +
  memory_api = 51；front lib 406 + perf 3 = 409；cli 单元 5 + 集成 190；lsp lib 117；
  doc-tests 6 ignored（内核既有）。

## 2026-09-18 更新（第九十五轮：批次 3 拆分 `run_pass` + 「二进制对拍」验收手段）

- **拆分落点**（只动位置不动语义，三刀三次提交）：`front/src/compile/check.rs`
  → 目录模块 `check/{mod,walk,kernel_phase}.rs`，加上先前的 `compile/units.rs`。
  现状 `check/mod.rs` 791 + `walk.rs` 951 + `kernel_phase.rs` 413（原 1918 行单文件、
  ≈1174 行单函数）。`run_pass` 现在只剩闭包装配 + 前缀合成 + 两段调用。
- **二进制对拍（位置搬移类改动的首选验收，比 golden 覆盖面大）**：
  ```bash
  git worktree add --detach /tmp/soko-base HEAD      # 改动前的树
  (cd /tmp/soko-base && cargo build -p sokonanoda-cli --bin sokonanoda --locked)
  cargo build -p sokonanoda-cli --bin sokonanoda --locked
  # 对全部语料 + 项目/模式开关 + stdin + query 逐字节比对 stdout
  ```
  本次输入 = `git ls-files '*.sokonanoda'`（58 个）+ `--root course/shared` +
  `--no-project` + `playground` 走 stdin + `query check|goals|holes`；`fail=0`。
  三个注意点：① `cargo fmt` 会重排搬过去的代码，**文本级**对拍先归一化空白；
  ② **两个 worktree 不要共用 `CARGO_TARGET_DIR`**（cargo 按包路径分键做 fresh 判定
  但输出同名，后建的树会静默覆盖前者的二进制 → `touch` 源文件强制重建再比）；
  ③ 顺手删死代码（如只写状态 `built_inductives`、推空 `CmdHover` 的空操作）同样
  过一遍对拍——这类改动**没有**测试会红。
- **总量（2026-09-18，`cargo test --workspace --locked`，全绿）**：**862** 个测试 ——
  kernel 51（lib 43 + arena 1 + memory_api 7）；front 462（lib 453 + perf 3 +
  perf_project 6）；cli 214（单元 5 + 集成 16 个目标 209：cli 80 / extension 33 /
  imports 13 / query 12 / project_features 11 / watch 10 / protocol 9 / dsh 8 /
  opencode 8 / course 6 / course_shared 4 / course_status 4 / skill 4 /
  single_file_vs_project 4 / perf_project 2 / examples 1）；lsp 135（lib）。
  测试目标 26 个（+ doc-tests 3 个目标，6 ignored 属内核既有）。

## 2026-09-18 更新（第九十六轮：项目状态视图 —— `query project` / `soko/project` / 项目树）

- **新增一层只读视图**（批次 4）：`front::query::project_view()` 从**已编译的**
  闭包报告派生 `ProjectView`；`project::ModuleReport::status`
  （`compiled`/`load-failed`/`blocked`）让"根因"与"受害者"可区分。三个传输同一
  份真相：CLI `query project`、MCP `project`、LSP `soko/project`（回显 uri/version）。
  §1 新增「项目状态视图」一行；扩展宿主层补项目树三例（§1 的宿主行）。
- **测试构成（2026-09-18，`cargo test --workspace --locked`，全绿）**：**871** 个测试
  —— kernel 51（lib 43 + arena 1 + memory_api 7）；front 466（lib 457 + perf 3 +
  perf_project 6）；cli 217（单元 5 + 集成 16 个目标 212：cli 80 / extension 33 /
  project_features 14 / imports 13 / query 12 / watch 10 / protocol 9 / dsh 8 /
  opencode 8 / course 6 / course_shared 4 / course_status 4 / skill 4 /
  single_file_vs_project 4 / perf_project 2 / examples 1）；lsp 137（lib）。
  另有四个纯 Node 套件：server 18 / download 7 / webview 10 / extension-host 11。
- **版本 0.58.0**（Rust 与扩展同步 bump；`cargo_and_extension_versions_match` 守着）。

## 2026-09-18 更新（第九十八轮：合并 0.56.2 线 + 跨模块 warning 归因修复）

- **合并**：`origin/main`（0.56.2 = `redundant-sorry`）与本线（I16 项目管理 +
  批次 1–4，0.58.0）在 scratch worktree 里合并，19 个文件冲突手心合并；0.56.2
  写在旧 `check.rs` 的探针代码手工搬进本线的 `check/{walk,kernel_phase}.rs`。
  §1 的「多余的 `sorry`」一行仍然成立（正 2 + 反 3、会话快照、两视图一致）。
- **合并暴露并修掉一个真 bug**：内核终审的 warning 在**项目模式**下会丢归因
  （`split_report` 原先只按单元重算语法级 warning）。修法 = `CompileOutput` 增
  平行数组 `warning_cmds` + `push_warning(cmd, w)`，`split_report` 按命令下标归因；
  §1 新增一行守护（`warnings_are_attributed_to_the_unit_that_produced_them`）。
- **测试构成（2026-09-18 合并树，`cargo test --workspace --locked`，全绿）**：
  **888** 个测试 / 0 failed / 6 ignored（内核既有）—— kernel 52（lib 43 + arena 1 +
  memory_api 8）；front 475（lib 466 + perf 3 + perf_project 6）；cli 223（单元 5 +
  集成 17 个目标 218：cli 81 / extension 33 / project_features 14 / imports 13 /
  query 13 / protocol 10 / watch 10 / dsh 8 / opencode 8 / course 6 / course_shared 4 /
  course_status 4 / skill 4 / single_file_vs_project 4 / launcher 3 / perf_project 2 /
  examples 1）；lsp 138（lib）。测试目标 27 个 + 3 个 doc-test 目标。
  另有四个纯 Node 套件：server 18 / download 7 / webview 10 / extension-host 11；
  真 VS Code 例行化（`scripts/vscode-e2e.sh`）在 1.138.0 与 1.106.0 上各 14/14
  （台账 `docs/e2e/ledger.jsonl`）。
- **版本 0.58.0**：合并后 push `main` → auto-tag `v0.58.0` → release（0.56.2 的
  `v0.56.2` 与其功能都在历史里；CHANGELOG 的 0.58.0 条目补记 `redundant-sorry`）。

### 内核 pp 的文本契约（T-K32，2026-09-21）

`crates/kernel/tests/pretty_printer.rs`（5 条）钉住 **`pp_expr` 的文本输出**：
`->` vs `forall` 的选择、`{}` 隐式、binder 没被用到就折成箭头、匿名 Pi 套具名 Pi
要括号、`Prop`/`Type 0`、应用左结合与参数括号、匿名 binder 的空转义 `«»`、
层级实参默认不打印（`E` 而不是 `E.{0}`）。

**为什么需要它**（线 C 的前置）：内核 pp 同时是 `#check`/`#reduce`/`#print` 的出口
⇒ 直接进 `--json` 的 `expr.typed`/`expr.reduced`/`decl.printed`，而线 C（goal /
类型行用记法）要在**它的出口之后**做重写。没有这组钉子，"重写改坏了 pp"与
"重写本身写错了"分不开。

**它们是特征化测试**（断言的是**今天**的输出，不是"正确的"输出）：输出变了必须是
有意的，改 pp 的 diff 里看得见。**变异检查**做过：把 `f (g x)` 期望改成 `f g x`
必须红（实测红了）。

两个建夹具的坑（都写在文件注释里）：`Config::default()` 的 `proofs = false` 会让 pp
对**开项**跑 `is_proof` 推断 ⇒ `infer: loose bvar` panic（要按前端那样设
`pp_options.proofs = true`）；表达式里用到的常量**必须真的声明**，否则
`const_head_type: unknown const` panic。
